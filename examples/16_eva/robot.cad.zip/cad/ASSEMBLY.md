# Assembly — eva

Start from **base_link**.

1. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (left_motor) in **base_link** with its case screws.
2. Fit **left_wheel** on the output of the motor in **base_link** (driven joint `left_wheel_joint`).
3. Bolt **left_bracket** to **base_link**.
4. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (right_motor) in **base_link** with its case screws.
5. Fit **right_wheel** on the output of the motor in **base_link** (driven joint `right_wheel_joint`).
6. Bolt **right_bracket** to **base_link**.
7. Bolt **front_caster_post** to **base_link**.
8. Mount the **Pololu ball caster, 1" POM ball on ball bearings (#2692)** (front_caster) in **base_link** with its case screws.
9. Fit **front_caster_gimbal** on the output of the motor in **base_link** (free-running joint `front_caster_roll`).
10. Fit **front_caster_ball** on the output of the motor in **front_caster_gimbal** (free-running joint `front_caster_spin`).
11. Bolt **rear_caster_post** to **base_link**.
12. Mount the **Pololu ball caster, 1" POM ball on ball bearings (#2692)** (rear_caster) in **base_link** with its case screws.
13. Fit **rear_caster_gimbal** on the output of the motor in **base_link** (free-running joint `rear_caster_roll`).
14. Fit **rear_caster_ball** on the output of the motor in **rear_caster_gimbal** (free-running joint `rear_caster_spin`).
15. Bolt **skirt_left_front** to **base_link**.
16. Bolt **skirt_left_rear** to **base_link**.
17. Bolt **skirt_right_front** to **base_link**.
18. Bolt **skirt_right_rear** to **base_link**.
19. Mount the **LiPo 3S 2200 mAh 25C, XT60 (Gens Ace G-Tech)** (battery) in **base_link** with its case screws.
20. Bolt **battery_tray** to **base_link**.
21. Mount the **Waveshare Bus Servo Adapter (A)** (servo_bus) in **base_link** with its case screws.
22. Bolt **servo_bus_tray** to **base_link**.
23. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **base_link** with its case screws.
24. Bolt **imu_tray** to **base_link**.
25. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **base_link** with its case screws.
26. Bolt **regulator_5v_tray** to **base_link**.
27. Mount the **KCD4 double-pole rocker switch, 16 A 250 VAC / 20 A 125 VAC** (main_switch) in **base_link** with its case screws.
28. Bolt **electronics_enclosure** to **base_link**.
29. Bolt **electronics_lid** to **base_link**.
30. Bolt **spine** to **base_link**.
31. Bolt **rib_mid_left** to **spine**.
32. Bolt **rib_mid_right** to **spine**.
33. Bolt **rib_top_left** to **spine**.
34. Bolt **rib_top_right** to **spine**.
35. Mount the **Raspberry Pi 5 (4 GB)** (computer) in **spine** with its case screws.
36. Bolt **computer_tray** to **spine**.
37. Mount the **Cytron MDD10A dual-channel 10 A DC motor driver (5-30 V)** (motor_driver_1) in **spine** with its case screws.
38. Bolt **motor_driver_1_tray** to **spine**.
39. Bolt **shell_lower_left** to **spine**.
40. Bolt **shell_lower_right** to **spine**.
41. Bolt **shell_upper_left** to **spine**.
42. Bolt **shell_upper_right** to **spine**.
43. Bolt **neck_mount** to **spine**.
44. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (head_pan_actuator) in **spine** with its case screws.
45. Set joint `head_pan` to zero (centre the servo first), then screw **head** to the actuator output in **spine**; it moves -149° … 149°.
46. Bolt **visor** to **head**.
47. Bolt **left_eye** to **head**.
48. Bolt **right_eye** to **head**.
49. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (head_camera) in **head** with its case screws.
50. Bolt **camera_bracket** to **head**.
51. Bolt **left_arm_base_link** to **spine**.
52. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (left_arm_shoulder_pitch_actuator) in **left_arm_base_link** with its case screws.
53. Set joint `left_arm_shoulder_pitch` to zero (centre the servo first), then screw **left_arm_upper_arm** to the actuator output in **left_arm_base_link**; it moves -63° … 63°.
54. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (left_arm_elbow_pitch_actuator) in **left_arm_upper_arm** with its case screws.
55. Set joint `left_arm_elbow_pitch` to zero (centre the servo first), then screw **left_arm_tool_link** to the actuator output in **left_arm_upper_arm**; it moves -132° … 132°.
56. Bolt **left_arm_shoulder** to **spine**.
57. Bolt **right_arm_base_link** to **spine**.
58. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (right_arm_shoulder_pitch_actuator) in **right_arm_base_link** with its case screws.
59. Set joint `right_arm_shoulder_pitch` to zero (centre the servo first), then screw **right_arm_upper_arm** to the actuator output in **right_arm_base_link**; it moves -63° … 63°.
60. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (right_arm_elbow_pitch_actuator) in **right_arm_upper_arm** with its case screws.
61. Set joint `right_arm_elbow_pitch` to zero (centre the servo first), then screw **right_arm_tool_link** to the actuator output in **right_arm_upper_arm**; it moves -132° … 132°.
62. Bolt **right_arm_shoulder** to **spine**.
63. Bolt **spine_foot** to **base_link**.

## Fasteners

- 12 × M3 x 8 socket head (motor face)
- 4 × M3 x 10 socket head + nut (bracket to deck)
- 6 × M3 x 6 socket head (caster)
- 8 × M3 x 8 (skirt arcs to the deck edge)
- 1 × 20 mm hook-and-loop battery strap
- 12 × M3 x 8 socket head (tray to deck)
- 19 × M2.5 x 6 screws (board to standoffs)
- 4 × M3 x 10 self-tapping (enclosure lid)
- 4 × M3 x 8 + nut (enclosure tabs to deck; drill 3.4 mm through the deck at the tabs)
- 16 × M3 x 8 + heat-set inserts (shell to ribs)
- 20 × horn screws
- 8 × M5 x 12 socket head (base to bench)
- 16 × M2 x 6 case screws
- 4 × M5 x 16 socket head + M5 washer + M5 heat-set insert (clevis bearing axle)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
