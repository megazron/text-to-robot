// concept part: neck_support (support)
// units: mm. Mesh with: openscad -o neck_support.stl neck_support.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 880], [0, 0, 0, 1]])
  cylinder(h=60, r=22, center=true, $fn=48);
