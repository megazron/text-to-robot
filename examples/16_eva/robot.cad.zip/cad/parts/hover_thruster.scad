// concept part: hover_thruster (sensor)
// units: mm. Mesh with: openscad -o hover_thruster.stl hover_thruster.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=30, r=100, center=true, $fn=48);
