// concept part: head (link)
// units: mm. Mesh with: openscad -o head.stl head.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  hull() { translate([0,0,50]) sphere(r=110, $fn=32); translate([0,0,-50]) sphere(r=110, $fn=32); }
