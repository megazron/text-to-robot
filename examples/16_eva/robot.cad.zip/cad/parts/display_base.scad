// concept part: display_base (support)
// units: mm. Mesh with: openscad -o display_base.stl display_base.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 12.5], [0, 0, 0, 1]])
  cube([360, 300, 25], center=true);
