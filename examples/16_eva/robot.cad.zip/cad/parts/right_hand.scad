// concept part: right_hand (gripper)
// units: mm. Mesh with: openscad -o right_hand.stl right_hand.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  sphere(r=70, $fn=48);
