// concept part: left_hand (gripper)
// units: mm. Mesh with: openscad -o left_hand.stl left_hand.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  sphere(r=70, $fn=48);
