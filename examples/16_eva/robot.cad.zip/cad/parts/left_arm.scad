// concept part: left_arm (upper_arm)
// units: mm. Mesh with: openscad -o left_arm.stl left_arm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -140], [0, 0, 0, 1]])
  hull() { translate([0,0,140]) sphere(r=60, $fn=32); translate([0,0,-140]) sphere(r=60, $fn=32); }
