// concept part: support_column (support)
// units: mm. Mesh with: openscad -o support_column.stl support_column.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 132.5], [0, 0, 0, 1]])
  cylinder(h=215, r=18, center=true, $fn=48);
