// concept part: left_shoulder_support (support)
// units: mm. Mesh with: openscad -o left_shoulder_support.stl left_shoulder_support.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 200], [0, 1, 0, 650], [0, 0, 0, 1]])
  cylinder(h=90, r=19, center=true, $fn=48);
