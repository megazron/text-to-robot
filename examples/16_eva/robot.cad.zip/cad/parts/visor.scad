// concept part: visor (sensor)
// units: mm. Mesh with: openscad -o visor.stl visor.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cube([20, 140, 60], center=true);
