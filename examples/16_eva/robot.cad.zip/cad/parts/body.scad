// concept part: body (base)
// units: mm. Mesh with: openscad -o body.stl body.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 550], [0, 0, 0, 1]])
  hull() { translate([0,0,150]) sphere(r=160, $fn=32); translate([0,0,-150]) sphere(r=160, $fn=32); }
