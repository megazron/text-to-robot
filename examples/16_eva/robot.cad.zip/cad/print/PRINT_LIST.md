# Print list — eva

35 parts, about 1797 g of PETG and 163.8 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| rear_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| skirt_left | 249 × 113.1 × 82 | 50 | 4.5 | yes |
| skirt_right | 249 × 113.1 × 82 | 50 | 4.5 | yes |
| battery_tray | 110.6 × 40.7 × 16.2 | 17 | 1.5 | yes |
| servo_bus_tray | 42.4 × 33.4 × 7 | 3 | 0.3 | yes |
| imu_tray | 26.9 × 24 × 7 | 2 | 0.1 | yes |
| regulator_5v_tray | 26.7 × 26.7 × 7 | 2 | 0.1 | yes |
| spine_foot | 52 × 52 × 40 | 21 | 1.9 | yes |
| rib_mid_left | 223 × 111.5 × 18 | 109 | 9.9 | yes |
| rib_mid_right | 223 × 111.5 × 18 | 109 | 9.9 | yes |
| rib_top_left | 167.3 × 83.6 × 18 | 54 | 4.9 | yes |
| rib_top_right | 167.3 × 83.6 × 18 | 54 | 4.9 | yes |
| computer_tray | 85.7 × 55.4 × 7 | 13 | 1.1 | yes |
| motor_driver_1_tray | 84.4 × 61.4 × 7 | 13 | 1.2 | yes |
| shell_lower_left | 230.8 × 115.4 × 205 | 128 | 11.7 | yes |
| shell_lower_right | 230.8 × 115.4 × 205 | 128 | 11.7 | yes |
| shell_upper_left | 244 × 122 × 199.9 | 173 | 15.8 | yes |
| shell_upper_right | 244 × 122 × 199.9 | 173 | 15.8 | yes |
| neck_mount | 62.2 × 48 × 40.9 | 23 | 2.0 | yes |
| head | 201.5 × 224 × 156 | 240 | 21.9 | yes |
| visor | 63 × 211 × 86 | 31 | 2.8 | yes |
| left_eye | 8.7 × 31.9 × 18 | 1 | 0.1 | yes |
| right_eye | 8.7 × 31.9 × 18 | 1 | 0.1 | yes |
| camera_bracket | 34 × 32 × 32 | 7 | 0.7 | yes |
| left_arm_base_link | 46 × 51.1 × 58.4 | 32 | 2.9 | yes |
| left_arm_upper_arm | 126.7 × 30.8 × 62.3 | 63 | 5.7 | yes |
| left_arm_tool_link | 113.5 × 40 × 44.5 | 23 | 2.1 | yes |
| left_arm_shoulder | 101 × 187.8 × 24 | 31 | 2.9 | yes |
| right_arm_base_link | 46 × 51.1 × 58.4 | 32 | 2.9 | yes |
| right_arm_upper_arm | 126.7 × 30.8 × 62.3 | 63 | 5.7 | yes |
| right_arm_tool_link | 113.5 × 40 × 44.5 | 23 | 2.1 | yes |
| right_arm_shoulder | 101 × 187.8 × 24 | 31 | 2.9 | yes |
