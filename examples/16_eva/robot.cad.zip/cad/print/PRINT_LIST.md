# Print list: eva

38 parts, about 1873 g of PETG and 170.7 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| rear_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| skirt_left_front | 72.5 × 113.1 × 82 | 25 | 2.3 | yes |
| skirt_left_rear | 72.5 × 113.1 × 82 | 25 | 2.3 | yes |
| skirt_right_front | 72.5 × 113.1 × 82 | 25 | 2.3 | yes |
| skirt_right_rear | 72.5 × 113.1 × 82 | 25 | 2.3 | yes |
| battery_tray | 125.6 × 40.7 × 16.2 | 18 | 1.7 | yes |
| servo_bus_tray | 44 × 35 × 7 | 5 | 0.4 | yes |
| imu_tray | 27.6 × 24.7 × 7 | 2 | 0.2 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| electronics_enclosure | 190.8 × 180.4 × 45.1 | 76 | 6.9 | yes |
| electronics_lid | 164.8 × 162.3 × 5.4 | 43 | 4.0 | yes |
| spine_foot | 39 × 39 × 40 | 16 | 1.4 | yes |
| rib_mid_left | 223 × 111.5 × 18 | 108 | 9.9 | yes |
| rib_mid_right | 223 × 111.5 × 18 | 109 | 9.9 | yes |
| rib_top_left | 167.3 × 83.6 × 18 | 52 | 4.8 | yes |
| rib_top_right | 167.3 × 83.6 × 18 | 53 | 4.8 | yes |
| computer_tray | 90 × 59.2 × 7 | 15 | 1.4 | yes |
| motor_driver_1_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| shell_lower_left | 230.8 × 115.4 × 205 | 128 | 11.6 | yes |
| shell_lower_right | 230.8 × 115.4 × 205 | 128 | 11.7 | yes |
| shell_upper_left | 244 × 122 × 199.9 | 169 | 15.4 | yes |
| shell_upper_right | 244 × 122 × 199.9 | 168 | 15.3 | yes |
| neck_mount | 62.2 × 48 × 40.9 | 21 | 1.9 | yes |
| head | 201.5 × 224 × 156 | 239 | 21.8 | yes |
| left_eye | 8.7 × 31.9 × 18 | 1 | 0.1 | yes |
| right_eye | 8.7 × 31.9 × 18 | 1 | 0.1 | yes |
| camera_bracket | 36.2 × 45.3 × 33.5 | 8 | 0.7 | yes |
| left_arm_base_link | 46 × 51.1 × 58.4 | 31 | 2.8 | yes |
| left_arm_upper_arm | 127.8 × 30.8 × 62.3 | 64 | 5.8 | yes |
| left_arm_tool_link | 114.6 × 40 × 44.5 | 23 | 2.1 | yes |
| left_arm_shoulder | 101 × 187.8 × 24 | 31 | 2.8 | yes |
| right_arm_base_link | 46 × 51.1 × 58.4 | 31 | 2.8 | yes |
| right_arm_upper_arm | 127.8 × 30.8 × 62.3 | 64 | 5.8 | yes |
| right_arm_tool_link | 114.6 × 40 × 44.5 | 23 | 2.1 | yes |
| right_arm_shoulder | 101 × 187.8 × 24 | 31 | 2.8 | yes |
