# Printability — eva

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| body | 320 × 320 × 620 | ❌ |
| head | 220 × 220 × 320 | ❌ |
| visor | 20 × 140 × 60 | ✅ |
| left_arm | 120 × 120 × 400 | ❌ |
| left_hand | 140 × 140 × 140 | ✅ |
| right_arm | 120 × 120 × 400 | ❌ |
| right_hand | 140 × 140 × 140 | ✅ |
| hover_thruster | 200 × 200 × 30 | ✅ |

## Notes
- ⚠️ **body**: longest dimension 620 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **head**: longest dimension 320 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_arm**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **left_hand**: sphere needs supports or a flat-cut base to print
- ⚠️ **right_arm**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **right_hand**: sphere needs supports or a flat-cut base to print
