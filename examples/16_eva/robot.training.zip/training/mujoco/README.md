# eva in MuJoCo

Test, render and train this exact robot in MuJoCo with the text-to-robot Python layer:

```bash
pip install -r requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cpu    # CPU torch on GPU-less machines

python -m ttr_mujoco test   ../eva.urdf --self-collision                       # settle / hold / actuator sweep / disturbance
python -m ttr_mujoco render ../eva.urdf -o eva.gif --motion sweep
python -m ttr_mujoco train  ../eva.urdf --self-collision --task reach --tip-body YOUR_TOOL_LINK --steps 400000
```

Or from Python:

```python
from ttr_mujoco import urdf_to_mjcf, run_tests, render_gif
from ttr_mujoco.env import MujocoRobotEnv
report = run_tests("../eva.urdf")              # dict with per-test pass/fail + metrics
env = MujocoRobotEnv("../eva.urdf", task="reach", tip_body="YOUR_TOOL_LINK")
```
