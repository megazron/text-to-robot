# Train hexapod

Auto-generated training suite. Robot class: **locomotion**. Physics: PyBullet (loads the URDF directly with a motor per joint). No ROS required.

```bash
cd training
pip install -r requirements.txt
```

## Tasks available
  - `walk`: Walk forward without falling
  - `balance`: Stand and balance in place
  - `turn`: Turn in place to a heading

## MuJoCo (recommended)
See `mujoco/README.md`: the same URDF converted to an actuated MuJoCo scene, with a test battery, renderer and PPO trainer.

## Reinforcement learning in PyBullet (PPO / SAC)
```bash
python train_rl.py --task walk --algo ppo --steps 200000
python train_rl.py --task walk --play          # watch it
```

## Imitation learning (behaviour cloning)
```bash
python collect_demos.py --task walk --episodes 50   # scripted expert -> demos.npz
python train_bc.py --epochs 50                                     # clone the expert
```

## Evaluate
```bash
python evaluate.py --task walk --rl hexapod_ppo_walk
python evaluate.py --task walk --bc bc_hexapod.pt
```

Add your own task by dropping a reward function into `tasks.py`; it is picked up automatically.
Classical motion planning is available via the exported ROS 2 / MoveIt 2 package.

## Reference motions
`reference_motions/` holds `gait.csv`, `tour.csv`: the motions the website plays, as joint positions at 30 Hz (one column per joint, `time_s` first; `<motion>_base.csv` is the base path when the whole robot moves). Use them as targets for motion imitation or as a tracking reward:

```python
from reference_motion import ReferenceMotion
ref = ReferenceMotion("reference_motions/gait.csv")
target = ref.at(t)            # {joint: position} at time t (seconds), interpolated, looped
```
