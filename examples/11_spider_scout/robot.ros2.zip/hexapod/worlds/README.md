# Gazebo — hexapod

```bash
sudo apt install ros-${ROS_DISTRO}-ros-gz
ros2 launch hexapod gazebo.launch.py
```

Spawns the robot from `robot_description` into `worlds/hexapod.sdf` (ground plane + sun) with a /clock bridge.
Add `gz_ros2_control` to drive the joints from ros2_control.
