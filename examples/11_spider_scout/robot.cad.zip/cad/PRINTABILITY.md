# Printability — hexapod

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 320 × 320 × 60 | ❌ |
| front_left_coxa | 40 × 40 × 50 | ✅ |
| front_left_femur | 32 × 32 × 100 | ✅ |
| front_left_tibia | 26 × 26 × 120 | ✅ |
| mid_left_coxa | 40 × 40 × 50 | ✅ |
| mid_left_femur | 32 × 32 × 100 | ✅ |
| mid_left_tibia | 26 × 26 × 120 | ✅ |
| rear_left_coxa | 40 × 40 × 50 | ✅ |
| rear_left_femur | 32 × 32 × 100 | ✅ |
| rear_left_tibia | 26 × 26 × 120 | ✅ |
| front_right_coxa | 40 × 40 × 50 | ✅ |
| front_right_femur | 32 × 32 × 100 | ✅ |
| front_right_tibia | 26 × 26 × 120 | ✅ |
| mid_right_coxa | 40 × 40 × 50 | ✅ |
| mid_right_femur | 32 × 32 × 100 | ✅ |
| mid_right_tibia | 26 × 26 × 120 | ✅ |
| rear_right_coxa | 40 × 40 × 50 | ✅ |
| rear_right_femur | 32 × 32 × 100 | ✅ |
| rear_right_tibia | 26 × 26 × 120 | ✅ |
| lidar_1_link | 60 × 60 × 50 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 320 mm exceeds the 220 mm build volume — split the part or print diagonally
