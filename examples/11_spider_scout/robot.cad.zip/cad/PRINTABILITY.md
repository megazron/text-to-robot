# Printability — hexapod

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 260 × 260 × 3 | ❌ |
| base_link_service_lid | 260 × 260 × 3 | ❌ |
| base_link_rear_panel | 3 × 260 × 54 | ❌ |
| base_link_right_panel | 254 × 3 × 54 | ❌ |
| base_link_front_panel | 3 × 260 × 54 | ❌ |
| base_link_left_panel | 254 × 3 × 54 | ❌ |
| base_link_standoff_rr | 8 × 8 × 54 | ✅ |
| base_link_standoff_rl | 8 × 8 × 54 | ✅ |
| base_link_standoff_fr | 8 × 8 × 54 | ✅ |
| base_link_standoff_fl | 8 × 8 × 54 | ✅ |
| front_left_coxa | 40 × 40 × 50 | ✅ |
| front_left_femur | 32 × 32 × 100 | ✅ |
| front_left_tibia | 26 × 26 × 120 | ✅ |
| mid_left_coxa | 40 × 40 × 50 | ✅ |
| mid_left_femur | 32 × 32 × 100 | ✅ |
| mid_left_tibia | 26 × 26 × 120 | ✅ |
| rear_left_coxa | 40 × 40 × 50 | ✅ |
| rear_left_femur | 32 × 32 × 100 | ✅ |
| rear_left_tibia | 26 × 26 × 120 | ✅ |
| front_right_coxa | 40 × 40 × 50 | ✅ |
| front_right_femur | 32 × 32 × 100 | ✅ |
| front_right_tibia | 26 × 26 × 120 | ✅ |
| mid_right_coxa | 40 × 40 × 50 | ✅ |
| mid_right_femur | 32 × 32 × 100 | ✅ |
| mid_right_tibia | 26 × 26 × 120 | ✅ |
| rear_right_coxa | 40 × 40 × 50 | ✅ |
| rear_right_femur | 32 × 32 × 100 | ✅ |
| rear_right_tibia | 26 × 26 × 120 | ✅ |
| front_left_foot | 30 × 30 × 30 | ✅ |
| mid_left_foot | 30 × 30 × 30 | ✅ |
| rear_left_foot | 30 × 30 × 30 | ✅ |
| front_right_foot | 30 × 30 × 30 | ✅ |
| mid_right_foot | 30 × 30 × 30 | ✅ |
| rear_right_foot | 30 × 30 × 30 | ✅ |
| lidar_1_link | 60 × 60 × 50 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 260 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_service_lid**: longest dimension 260 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_rear_panel**: longest dimension 260 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_right_panel**: longest dimension 254 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_front_panel**: longest dimension 260 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_left_panel**: longest dimension 254 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **front_left_foot**: sphere needs supports or a flat-cut base to print
- ℹ️ **mid_left_foot**: sphere needs supports or a flat-cut base to print
- ℹ️ **rear_left_foot**: sphere needs supports or a flat-cut base to print
- ℹ️ **front_right_foot**: sphere needs supports or a flat-cut base to print
- ℹ️ **mid_right_foot**: sphere needs supports or a flat-cut base to print
- ℹ️ **rear_right_foot**: sphere needs supports or a flat-cut base to print
