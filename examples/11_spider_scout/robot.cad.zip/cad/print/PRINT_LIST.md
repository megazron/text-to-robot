# Print list: hexapod

26 parts, about 806 g of PETG and 73.5 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 208.8 × 208.8 × 64.3 | 223 | 20.3 | yes |
| deck_pillar_1 | 10 × 10 × 83.9 | 6 | 0.5 | yes |
| deck_pillar_2 | 10 × 10 × 83.9 | 6 | 0.5 | yes |
| deck_pillar_3 | 10 × 10 × 83.9 | 6 | 0.5 | yes |
| top_deck | 129.6 × 129.6 × 29 | 37 | 3.4 | yes |
| lf_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| lf_femur_link | 113.2 × 32.8 × 40.1 | 23 | 2.1 | yes |
| lf_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| lm_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| lm_femur_link | 113.2 × 32.8 × 40.1 | 23 | 2.1 | yes |
| lm_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| lr_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| lr_femur_link | 113.2 × 32.8 × 40.1 | 23 | 2.1 | yes |
| lr_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| rr_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| rr_femur_link | 113.2 × 32.8 × 40.1 | 23 | 2.1 | yes |
| rr_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| rm_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| rm_femur_link | 113.2 × 32.8 × 40.1 | 23 | 2.1 | yes |
| rm_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| rf_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| rf_femur_link | 113.2 × 32.8 × 40.1 | 23 | 2.1 | yes |
| rf_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| computer_hood | 119.4 × 125.4 × 54.6 | 67 | 6.1 | yes |
| board_hood | 107.4 × 80.4 × 74.9 | 63 | 5.8 | yes |
| battery_tray | 207.4 × 63.7 × 31 | 60 | 5.4 | yes |
