# Print list — hexapod

20 parts, about 672 g of PETG and 61.2 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 215.1 × 208.8 × 64.3 | 234 | 21.4 | yes |
| top_deck | 129.6 × 129.6 × 132.7 | 91 | 8.3 | yes |
| lf_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| lf_femur_link | 113.2 × 32.8 × 40.1 | 24 | 2.2 | yes |
| lf_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| lm_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| lm_femur_link | 113.2 × 32.8 × 40.1 | 24 | 2.2 | yes |
| lm_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| lr_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| lr_femur_link | 113.2 × 32.8 × 40.1 | 24 | 2.2 | yes |
| lr_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| rr_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| rr_femur_link | 113.2 × 32.8 × 40.1 | 24 | 2.2 | yes |
| rr_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| rm_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| rm_femur_link | 113.2 × 32.8 × 40.1 | 24 | 2.2 | yes |
| rm_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
| rf_coxa_link | 53.4 × 41.1 × 36.8 | 20 | 1.8 | yes |
| rf_femur_link | 113.2 × 32.8 × 40.1 | 24 | 2.2 | yes |
| rf_tibia_link | 174 × 28 × 5 | 14 | 1.2 | yes |
