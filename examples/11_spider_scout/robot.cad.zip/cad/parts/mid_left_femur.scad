// concept part: mid_left_femur (link)
// units: mm. Mesh with: openscad -o mid_left_femur.stl mid_left_femur.scad
multmatrix([[0, 0, 1, 50], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=100, r=16, center=true, $fn=48);
