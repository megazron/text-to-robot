// concept part: front_left_coxa (link)
// units: mm. Mesh with: openscad -o front_left_coxa.stl front_left_coxa.scad
multmatrix([[0, 0, 1, 25], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=50, r=20, center=true, $fn=48);
