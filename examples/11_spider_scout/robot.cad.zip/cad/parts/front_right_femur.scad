// concept part: front_right_femur (link)
// units: mm. Mesh with: openscad -o front_right_femur.stl front_right_femur.scad
multmatrix([[0, 0, 1, 50], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=100, r=16, center=true, $fn=48);
