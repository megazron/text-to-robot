// concept part: mid_left_tibia (link)
// units: mm. Mesh with: openscad -o mid_left_tibia.stl mid_left_tibia.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -60], [0, 0, 0, 1]])
  cylinder(h=120, r=13, center=true, $fn=48);
