// concept part: front_left_foot (contact_pad)
// units: mm. Mesh with: openscad -o front_left_foot.stl front_left_foot.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  sphere(r=15, $fn=48);
