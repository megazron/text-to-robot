// concept part: base_link_left_panel (housing)
// units: mm. Mesh with: openscad -o base_link_left_panel.stl base_link_left_panel.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 128.5], [0, 0, 1, 135], [0, 0, 0, 1]])
  cube([254, 3, 54], center=true);
