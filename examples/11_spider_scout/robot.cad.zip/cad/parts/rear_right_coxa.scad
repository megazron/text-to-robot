// concept part: rear_right_coxa (link)
// units: mm. Mesh with: openscad -o rear_right_coxa.stl rear_right_coxa.scad
multmatrix([[0, 0, 1, 25], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=50, r=20, center=true, $fn=48);
