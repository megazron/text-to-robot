// concept part: base_link (base)
// units: mm. Mesh with: openscad -o base_link.stl base_link.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 180], [0, 0, 0, 1]])
  cylinder(h=60, r=160, center=true, $fn=48);
