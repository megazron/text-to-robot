// concept part: lidar_1_link (sensor)
// units: mm. Mesh with: openscad -o lidar_1_link.stl lidar_1_link.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 25], [0, 0, 0, 1]])
  cylinder(h=50, r=30, center=true, $fn=48);
