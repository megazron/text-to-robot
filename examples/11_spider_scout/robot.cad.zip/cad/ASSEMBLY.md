# Assembly — hexapod

Start from **base_link**.

1. Mount the **LiPo 3S 5000 mAh 60C, XT60 (Gens Ace G-Tech)** (battery) in **base_link** with its case screws.
2. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **base_link** with its case screws.
3. Mount the **Waveshare Bus Servo Adapter (A)** (actuator_bus) in **base_link** with its case screws.
4. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **base_link** with its case screws.
5. Bolt **top_deck** to **base_link**.
6. Mount the **NVIDIA Jetson Orin Nano Super Developer Kit** (computer) in **top_deck** with its case screws.
7. Mount the **Slamtec RPLIDAR C1 (DTOF 360 deg, 12 m)** (lidar) in **top_deck** with its case screws.
8. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (camera) in **top_deck** with its case screws.
9. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lf_coxa_actuator) in **base_link** with its case screws.
10. Set joint `lf_coxa` to zero (centre the servo first), then screw **lf_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
11. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (lf_femur_actuator) in **lf_coxa_link** with its case screws.
12. Set joint `lf_femur` to zero (centre the servo first), then screw **lf_femur_link** to the actuator output in **lf_coxa_link**; it moves -69° … 69°.
13. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lf_tibia_actuator) in **lf_femur_link** with its case screws.
14. Set joint `lf_tibia` to zero (centre the servo first), then screw **lf_tibia_link** to the actuator output in **lf_femur_link**; it moves -49° … 69°.
15. Bolt **lf_foot** to **lf_tibia_link**.
16. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lm_coxa_actuator) in **base_link** with its case screws.
17. Set joint `lm_coxa` to zero (centre the servo first), then screw **lm_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
18. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (lm_femur_actuator) in **lm_coxa_link** with its case screws.
19. Set joint `lm_femur` to zero (centre the servo first), then screw **lm_femur_link** to the actuator output in **lm_coxa_link**; it moves -69° … 69°.
20. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lm_tibia_actuator) in **lm_femur_link** with its case screws.
21. Set joint `lm_tibia` to zero (centre the servo first), then screw **lm_tibia_link** to the actuator output in **lm_femur_link**; it moves -51° … 69°.
22. Bolt **lm_foot** to **lm_tibia_link**.
23. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lr_coxa_actuator) in **base_link** with its case screws.
24. Set joint `lr_coxa` to zero (centre the servo first), then screw **lr_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
25. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (lr_femur_actuator) in **lr_coxa_link** with its case screws.
26. Set joint `lr_femur` to zero (centre the servo first), then screw **lr_femur_link** to the actuator output in **lr_coxa_link**; it moves -69° … 69°.
27. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lr_tibia_actuator) in **lr_femur_link** with its case screws.
28. Set joint `lr_tibia` to zero (centre the servo first), then screw **lr_tibia_link** to the actuator output in **lr_femur_link**; it moves -51° … 69°.
29. Bolt **lr_foot** to **lr_tibia_link**.
30. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rr_coxa_actuator) in **base_link** with its case screws.
31. Set joint `rr_coxa` to zero (centre the servo first), then screw **rr_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
32. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (rr_femur_actuator) in **rr_coxa_link** with its case screws.
33. Set joint `rr_femur` to zero (centre the servo first), then screw **rr_femur_link** to the actuator output in **rr_coxa_link**; it moves -69° … 69°.
34. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rr_tibia_actuator) in **rr_femur_link** with its case screws.
35. Set joint `rr_tibia` to zero (centre the servo first), then screw **rr_tibia_link** to the actuator output in **rr_femur_link**; it moves -49° … 69°.
36. Bolt **rr_foot** to **rr_tibia_link**.
37. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rm_coxa_actuator) in **base_link** with its case screws.
38. Set joint `rm_coxa` to zero (centre the servo first), then screw **rm_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
39. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (rm_femur_actuator) in **rm_coxa_link** with its case screws.
40. Set joint `rm_femur` to zero (centre the servo first), then screw **rm_femur_link** to the actuator output in **rm_coxa_link**; it moves -69° … 69°.
41. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rm_tibia_actuator) in **rm_femur_link** with its case screws.
42. Set joint `rm_tibia` to zero (centre the servo first), then screw **rm_tibia_link** to the actuator output in **rm_femur_link**; it moves -51° … 69°.
43. Bolt **rm_foot** to **rm_tibia_link**.
44. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rf_coxa_actuator) in **base_link** with its case screws.
45. Set joint `rf_coxa` to zero (centre the servo first), then screw **rf_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
46. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (rf_femur_actuator) in **rf_coxa_link** with its case screws.
47. Set joint `rf_femur` to zero (centre the servo first), then screw **rf_femur_link** to the actuator output in **rf_coxa_link**; it moves -69° … 69°.
48. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rf_tibia_actuator) in **rf_femur_link** with its case screws.
49. Set joint `rf_tibia` to zero (centre the servo first), then screw **rf_tibia_link** to the actuator output in **rf_femur_link**; it moves -51° … 69°.
50. Bolt **rf_foot** to **rf_tibia_link**.

## Fasteners

- 3 × M3 x 12 deck pillar screws
- 72 × M2 x 6 case screws
- 72 × horn screws

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
