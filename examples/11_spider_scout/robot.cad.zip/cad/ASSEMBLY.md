# Assembly: hexapod

Start from **base_link**.

1. Mount the **LiPo 3S 5000 mAh 60C, XT60 (Gens Ace G-Tech)** (battery) in **base_link** with its case screws.
2. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **base_link** with its case screws.
3. Mount the **Waveshare Bus Servo Adapter (A)** (actuator_bus) in **base_link** with its case screws.
4. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **base_link** with its case screws.
5. Bolt **deck_pillar_1** to **base_link**.
6. Bolt **deck_pillar_2** to **base_link**.
7. Bolt **deck_pillar_3** to **base_link**.
8. Bolt **top_deck** to **base_link**.
9. Mount the **NVIDIA Jetson Orin Nano Super Developer Kit** (computer) in **top_deck** with its case screws.
10. Mount the **Slamtec RPLIDAR C1 (DTOF 360 deg, 12 m)** (lidar) in **top_deck** with its case screws.
11. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (camera) in **top_deck** with its case screws.
12. Bolt **computer_hood** to **top_deck**.
13. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lf_coxa_actuator) in **base_link** with its case screws.
14. Set joint `lf_coxa` to zero (centre the servo first), then screw **lf_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
15. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (lf_femur_actuator) in **lf_coxa_link** with its case screws.
16. Set joint `lf_femur` to zero (centre the servo first), then screw **lf_femur_link** to the actuator output in **lf_coxa_link**; it moves -69° … 69°.
17. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lf_tibia_actuator) in **lf_femur_link** with its case screws.
18. Set joint `lf_tibia` to zero (centre the servo first), then screw **lf_tibia_link** to the actuator output in **lf_femur_link**; it moves -46° … 69°.
19. Bolt **lf_foot** to **lf_tibia_link**.
20. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lm_coxa_actuator) in **base_link** with its case screws.
21. Set joint `lm_coxa` to zero (centre the servo first), then screw **lm_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
22. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (lm_femur_actuator) in **lm_coxa_link** with its case screws.
23. Set joint `lm_femur` to zero (centre the servo first), then screw **lm_femur_link** to the actuator output in **lm_coxa_link**; it moves -69° … 69°.
24. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lm_tibia_actuator) in **lm_femur_link** with its case screws.
25. Set joint `lm_tibia` to zero (centre the servo first), then screw **lm_tibia_link** to the actuator output in **lm_femur_link**; it moves -51° … 69°.
26. Bolt **lm_foot** to **lm_tibia_link**.
27. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lr_coxa_actuator) in **base_link** with its case screws.
28. Set joint `lr_coxa` to zero (centre the servo first), then screw **lr_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
29. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (lr_femur_actuator) in **lr_coxa_link** with its case screws.
30. Set joint `lr_femur` to zero (centre the servo first), then screw **lr_femur_link** to the actuator output in **lr_coxa_link**; it moves -69° … 69°.
31. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (lr_tibia_actuator) in **lr_femur_link** with its case screws.
32. Set joint `lr_tibia` to zero (centre the servo first), then screw **lr_tibia_link** to the actuator output in **lr_femur_link**; it moves -51° … 69°.
33. Bolt **lr_foot** to **lr_tibia_link**.
34. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rr_coxa_actuator) in **base_link** with its case screws.
35. Set joint `rr_coxa` to zero (centre the servo first), then screw **rr_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
36. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (rr_femur_actuator) in **rr_coxa_link** with its case screws.
37. Set joint `rr_femur` to zero (centre the servo first), then screw **rr_femur_link** to the actuator output in **rr_coxa_link**; it moves -69° … 69°.
38. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rr_tibia_actuator) in **rr_femur_link** with its case screws.
39. Set joint `rr_tibia` to zero (centre the servo first), then screw **rr_tibia_link** to the actuator output in **rr_femur_link**; it moves -46° … 69°.
40. Bolt **rr_foot** to **rr_tibia_link**.
41. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rm_coxa_actuator) in **base_link** with its case screws.
42. Set joint `rm_coxa` to zero (centre the servo first), then screw **rm_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
43. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (rm_femur_actuator) in **rm_coxa_link** with its case screws.
44. Set joint `rm_femur` to zero (centre the servo first), then screw **rm_femur_link** to the actuator output in **rm_coxa_link**; it moves -69° … 69°.
45. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rm_tibia_actuator) in **rm_femur_link** with its case screws.
46. Set joint `rm_tibia` to zero (centre the servo first), then screw **rm_tibia_link** to the actuator output in **rm_femur_link**; it moves -51° … 69°.
47. Bolt **rm_foot** to **rm_tibia_link**.
48. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rf_coxa_actuator) in **base_link** with its case screws.
49. Set joint `rf_coxa` to zero (centre the servo first), then screw **rf_coxa_link** to the actuator output in **base_link**; it moves -34° … 34°.
50. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (rf_femur_actuator) in **rf_coxa_link** with its case screws.
51. Set joint `rf_femur` to zero (centre the servo first), then screw **rf_femur_link** to the actuator output in **rf_coxa_link**; it moves -69° … 69°.
52. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rf_tibia_actuator) in **rf_femur_link** with its case screws.
53. Set joint `rf_tibia` to zero (centre the servo first), then screw **rf_tibia_link** to the actuator output in **rf_femur_link**; it moves -51° … 69°.
54. Bolt **rf_foot** to **rf_tibia_link**.
55. Bolt **board_hood** to **base_link**.
56. Mount the **KCD4 double-pole rocker switch, 16 A 250 VAC / 20 A 125 VAC** (main_switch) in **board_hood** with its case screws.
57. Bolt **battery_tray** to **base_link**.

## Fasteners

- 3 × M3 x 12 deck pillar screws
- 72 × M2 x 6 case screws
- 72 × horn screws
- 12 × M3 x 12 self-tapping (hood to deck)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
