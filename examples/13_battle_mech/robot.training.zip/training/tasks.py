"""Task catalogue (auto-generated). Each task returns (reward, terminated)."""
import numpy as np
import pybullet as p

def walk(self, action):
    pos, orn = self.p.getBasePositionAndOrientation(self.robot)
    vel, _ = self.p.getBaseVelocity(self.robot)
    up = p.getMatrixFromQuaternion(orn)[8]
    reward = float(vel[0]) + 0.5 * up - 0.001 * float(np.square(action).sum())
    terminated = pos[2] < self.fall_height
    return float(reward), bool(terminated)

def balance(self, action):
    pos, orn = self.p.getBasePositionAndOrientation(self.robot)
    up = p.getMatrixFromQuaternion(orn)[8]
    reward = up - 0.5 * float(np.linalg.norm(self.p.getBaseVelocity(self.robot)[0]))
    terminated = pos[2] < self.fall_height
    return float(reward), bool(terminated)

def turn(self, action):
    _, orn = self.p.getBasePositionAndOrientation(self.robot)
    yaw = p.getEulerFromQuaternion(orn)[2]
    reward = -abs(yaw - float(self.target[2]))
    terminated = False
    return float(reward), bool(terminated)

TASKS = {
    "walk": ("Walk forward without falling", walk),
    "balance": ("Stand and balance in place", balance),
    "turn": ("Turn in place to a heading", turn),
}
DEFAULT_TASK = "walk"
