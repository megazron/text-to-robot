# Assembly — battle_mech

Start from **base_link**.

1. Bolt **base_link_b** to **base_link**.
2. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **base_link** with its case screws.
3. Bolt **torso** to **base_link**.
4. Mount the **LiPo 6S 10000 mAh 30C, EC5 (Tattu)** (battery) in **torso** with its case screws.
5. Mount the **LiPo 6S 10000 mAh 30C, EC5 (Tattu)** (battery_2) in **torso** with its case screws.
6. Mount the **NVIDIA Jetson Orin Nano Super Developer Kit** (computer) in **torso** with its case screws.
7. Mount the **EYOU Robotics CANable PRO isolated USB-CAN adapter** (leg_bus) in **torso** with its case screws.
8. Mount the **ROBOTIS U2D2 USB to TTL/RS-485 interface** (arm_bus) in **torso** with its case screws.
9. Mount the **EYOU Robotics CANable PRO isolated USB-CAN adapter** (leg_bus_2) in **torso** with its case screws.
10. Mount the **Mean Well SD-50C-12 enclosed DC-DC converter, 36-72 V in, 12 V 4.2 A (50 W)** (dcdc_12v) in **torso** with its case screws.
11. Mount the **Mean Well SD-50C-12 enclosed DC-DC converter, 36-72 V in, 12 V 4.2 A (50 W)** (dcdc_12v_2) in **torso** with its case screws.
12. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **torso** with its case screws.
13. Mount the **CubeMars AK70-10 KV100** (l_shoulder_pitch_actuator) in **torso** with its case screws.
14. Set joint `l_shoulder_pitch` to zero (centre the servo first), then screw **l_shoulder_pitch_link** to the actuator output in **torso**; it moves -172° … 172°.
15. Mount the **CubeMars AK70-10 KV100** (l_shoulder_roll_actuator) in **l_shoulder_pitch_link** with its case screws.
16. Set joint `l_shoulder_roll` to zero (centre the servo first), then screw **l_shoulder_roll_link** to the actuator output in **l_shoulder_pitch_link**; it moves -2° … 92°.
17. Mount the **DYNAMIXEL XM430-W350-T(R)** (l_upper_arm_yaw_actuator) in **l_shoulder_roll_link** with its case screws.
18. Set joint `l_upper_arm_yaw` to zero (centre the servo first), then screw **l_upper_arm_yaw_link** to the actuator output in **l_shoulder_roll_link**; it moves -115° … 115°.
19. Mount the **DYNAMIXEL XH540-W270-T(R)** (l_elbow_actuator) in **l_upper_arm_yaw_link** with its case screws.
20. Set joint `l_elbow` to zero (centre the servo first), then screw **l_elbow_link** to the actuator output in **l_upper_arm_yaw_link**; it moves -132° … 125°.
21. Mount the **DYNAMIXEL XM430-W350-T(R)** (l_wrist_yaw_actuator) in **l_elbow_link** with its case screws.
22. Set joint `l_wrist_yaw` to zero (centre the servo first), then screw **l_wrist_yaw_link** to the actuator output in **l_elbow_link**; it moves -149° … 149°.
23. Mount the **DYNAMIXEL XH540-W270-T(R)** (l_wrist_pitch_actuator) in **l_wrist_yaw_link** with its case screws.
24. Set joint `l_wrist_pitch` to zero (centre the servo first), then screw **l_wrist_pitch_link** to the actuator output in **l_wrist_yaw_link**; it moves -92° … 73°.
25. Mount the **DYNAMIXEL XM430-W350-T(R)** (l_wrist_roll_actuator) in **l_wrist_pitch_link** with its case screws.
26. Set joint `l_wrist_roll` to zero (centre the servo first), then screw **l_wrist_roll_link** to the actuator output in **l_wrist_pitch_link**; it moves -160° … 160°.
27. Mount the **DYNAMIXEL XM430-W350-T(R)** (l_gripper_actuator) in **l_wrist_roll_link** with its case screws.
28. Set joint `l_gripper` to zero (centre the servo first), then screw **l_gripper_jaw** to the actuator output in **l_wrist_roll_link**; it moves -20° … 17°.
29. Bolt **l_shoulder_roll_armour_out** to **l_shoulder_roll_link**.
30. Mount the **CubeMars AK70-10 KV100** (r_shoulder_pitch_actuator) in **torso** with its case screws.
31. Set joint `r_shoulder_pitch` to zero (centre the servo first), then screw **r_shoulder_pitch_link** to the actuator output in **torso**; it moves -172° … 172°.
32. Mount the **CubeMars AK70-10 KV100** (r_shoulder_roll_actuator) in **r_shoulder_pitch_link** with its case screws.
33. Set joint `r_shoulder_roll` to zero (centre the servo first), then screw **r_shoulder_roll_link** to the actuator output in **r_shoulder_pitch_link**; it moves -92° … 2°.
34. Mount the **DYNAMIXEL XM430-W350-T(R)** (r_upper_arm_yaw_actuator) in **r_shoulder_roll_link** with its case screws.
35. Set joint `r_upper_arm_yaw` to zero (centre the servo first), then screw **r_upper_arm_yaw_link** to the actuator output in **r_shoulder_roll_link**; it moves -115° … 115°.
36. Mount the **DYNAMIXEL XH540-W270-T(R)** (r_elbow_actuator) in **r_upper_arm_yaw_link** with its case screws.
37. Set joint `r_elbow` to zero (centre the servo first), then screw **r_elbow_link** to the actuator output in **r_upper_arm_yaw_link**; it moves -125° … 132°.
38. Mount the **DYNAMIXEL XM430-W350-T(R)** (r_wrist_yaw_actuator) in **r_elbow_link** with its case screws.
39. Set joint `r_wrist_yaw` to zero (centre the servo first), then screw **r_wrist_yaw_link** to the actuator output in **r_elbow_link**; it moves -149° … 149°.
40. Mount the **DYNAMIXEL XH540-W270-T(R)** (r_wrist_pitch_actuator) in **r_wrist_yaw_link** with its case screws.
41. Set joint `r_wrist_pitch` to zero (centre the servo first), then screw **r_wrist_pitch_link** to the actuator output in **r_wrist_yaw_link**; it moves -73° … 92°.
42. Mount the **DYNAMIXEL XM430-W350-T(R)** (r_wrist_roll_actuator) in **r_wrist_pitch_link** with its case screws.
43. Set joint `r_wrist_roll` to zero (centre the servo first), then screw **r_wrist_roll_link** to the actuator output in **r_wrist_pitch_link**; it moves -160° … 160°.
44. Mount the **DYNAMIXEL XM430-W350-T(R)** (r_gripper_actuator) in **r_wrist_roll_link** with its case screws.
45. Set joint `r_gripper` to zero (centre the servo first), then screw **r_gripper_jaw** to the actuator output in **r_wrist_roll_link**; it moves -20° … 17°.
46. Bolt **r_shoulder_roll_armour_out** to **r_shoulder_roll_link**.
47. Mount the **DYNAMIXEL XL430-W250-T** (neck_pan_actuator) in **torso** with its case screws.
48. Set joint `neck_pan` to zero (centre the servo first), then screw **neck_pan_link** to the actuator output in **torso**; it moves -92° … 92°.
49. Mount the **DYNAMIXEL XM430-W350-T(R)** (neck_tilt_actuator) in **neck_pan_link** with its case screws.
50. Set joint `neck_tilt` to zero (centre the servo first), then screw **neck_tilt_link** to the actuator output in **neck_pan_link**; it moves -40° … 33°.
51. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (head_camera) in **neck_tilt_link** with its case screws.
52. Bolt **torso_armour_front** to **torso**.
53. Bolt **side_panel_left** to **torso**.
54. Bolt **side_panel_right** to **torso**.
55. Bolt **chest_panel** to **torso**.
56. Bolt **backpack_hood** to **torso**.
57. Bolt **switch_case** to **backpack_hood**.
58. Mount the **Blue Sea 6006 m-Series battery switch, ON-OFF, 48 VDC** (main_switch) in **switch_case** with its case screws.
59. Bolt **torso_b** to **base_link**.
60. Mount the **CubeMars AK60-6 V3.0 KV80** (l_hip_yaw_actuator) in **base_link** with its case screws.
61. Set joint `l_hip_yaw` to zero (centre the servo first), then screw **l_hip_yaw_link** to the actuator output in **base_link**; it moves -34° … 34°.
62. Mount the **CubeMars AK80-64 KV80** (l_hip_roll_actuator) in **l_hip_yaw_link** with its case screws.
63. Set joint `l_hip_roll` to zero (centre the servo first), then screw **l_hip_roll_link** to the actuator output in **l_hip_yaw_link**; it moves -4° … 26°.
64. Mount the **CubeMars AK80-64 KV80** (l_hip_pitch_actuator) in **l_hip_roll_link** with its case screws.
65. Set joint `l_hip_pitch` to zero (centre the servo first), then screw **l_hip_pitch_link** to the actuator output in **l_hip_roll_link**; it moves -48° … 92°.
66. Bolt **l_hip_pitch_link_b** to **l_hip_pitch_link**.
67. Mount the **CubeMars AK80-64 KV80** (l_knee_actuator) in **l_hip_pitch_link** with its case screws.
68. Set joint `l_knee` to zero (centre the servo first), then screw **l_knee_link** to the actuator output in **l_hip_pitch_link**; it moves -117° … 19°.
69. Bolt **l_knee_link_b** to **l_knee_link**.
70. Mount the **CubeMars AK80-64 KV80** (l_ankle_pitch_actuator) in **l_knee_link** with its case screws.
71. Set joint `l_ankle_pitch` to zero (centre the servo first), then screw **l_ankle_pitch_link** to the actuator output in **l_knee_link**; it moves -69° … 69°.
72. Mount the **CubeMars AK70-10 KV100** (l_ankle_roll_actuator) in **l_ankle_pitch_link** with its case screws.
73. Set joint `l_ankle_roll` to zero (centre the servo first), then screw **l_ankle_roll_link** to the actuator output in **l_ankle_pitch_link**; it moves -29° … 29°.
74. Bolt **l_sole_pad** to **l_ankle_roll_link**.
75. Bolt **l_knee_armour_front** to **l_knee_link**.
76. Bolt **l_hip_pitch_armour_front** to **l_hip_pitch_link**.
77. Mount the **CubeMars AK60-6 V3.0 KV80** (r_hip_yaw_actuator) in **base_link** with its case screws.
78. Set joint `r_hip_yaw` to zero (centre the servo first), then screw **r_hip_yaw_link** to the actuator output in **base_link**; it moves -34° … 34°.
79. Mount the **CubeMars AK80-64 KV80** (r_hip_roll_actuator) in **r_hip_yaw_link** with its case screws.
80. Set joint `r_hip_roll` to zero (centre the servo first), then screw **r_hip_roll_link** to the actuator output in **r_hip_yaw_link**; it moves -26° … 4°.
81. Mount the **CubeMars AK80-64 KV80** (r_hip_pitch_actuator) in **r_hip_roll_link** with its case screws.
82. Set joint `r_hip_pitch` to zero (centre the servo first), then screw **r_hip_pitch_link** to the actuator output in **r_hip_roll_link**; it moves -92° … 48°.
83. Bolt **r_hip_pitch_link_b** to **r_hip_pitch_link**.
84. Mount the **CubeMars AK80-64 KV80** (r_knee_actuator) in **r_hip_pitch_link** with its case screws.
85. Set joint `r_knee` to zero (centre the servo first), then screw **r_knee_link** to the actuator output in **r_hip_pitch_link**; it moves -19° … 117°.
86. Bolt **r_knee_link_b** to **r_knee_link**.
87. Mount the **CubeMars AK80-64 KV80** (r_ankle_pitch_actuator) in **r_knee_link** with its case screws.
88. Set joint `r_ankle_pitch` to zero (centre the servo first), then screw **r_ankle_pitch_link** to the actuator output in **r_knee_link**; it moves -69° … 69°.
89. Mount the **CubeMars AK70-10 KV100** (r_ankle_roll_actuator) in **r_ankle_pitch_link** with its case screws.
90. Set joint `r_ankle_roll` to zero (centre the servo first), then screw **r_ankle_roll_link** to the actuator output in **r_ankle_pitch_link**; it moves -29° … 29°.
91. Bolt **r_sole_pad** to **r_ankle_roll_link**.
92. Bolt **r_knee_armour_front** to **r_knee_link**.
93. Bolt **r_hip_pitch_armour_front** to **r_hip_pitch_link**.
94. Bolt **imu_hood** to **base_link**.

## Fasteners

- 36 × M3 x 16 split-joint bolts + nuts
- 4 × M3 x 12 torso-to-pelvis bolts
- 96 × M3 x 8 housing screws
- 112 × horn / hub screws
- 48 × M2/M2.5 x 6 case screws
- 28 × M3 x 10 armour screws + printed standoffs
- 4 × M3 x 8 self-tapping (side_panel_left)
- 4 × M3 x 8 self-tapping (side_panel_right)
- 4 × M3 x 8 self-tapping (chest_panel)
- 12 × M3 x 12 self-tapping (hood to deck)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
