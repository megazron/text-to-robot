# Assembly — battle_mech

Start from **base_link**.

1. Bolt **base_link_b** to **base_link**.
2. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **base_link** with its case screws.
3. Bolt **torso** to **base_link**.
4. Mount the **LiPo 6S 10000 mAh 30C, EC5 (Tattu)** (battery) in **torso** with its case screws.
5. Mount the **LiPo 6S 10000 mAh 30C, EC5 (Tattu)** (battery_2) in **torso** with its case screws.
6. Mount the **NVIDIA Jetson Orin Nano Super Developer Kit** (computer) in **torso** with its case screws.
7. Mount the **EYOU Robotics CANable PRO isolated USB-CAN adapter** (leg_bus) in **torso** with its case screws.
8. Mount the **ROBOTIS U2D2 USB to TTL/RS-485 interface** (arm_bus) in **torso** with its case screws.
9. Mount the **EYOU Robotics CANable PRO isolated USB-CAN adapter** (leg_bus_2) in **torso** with its case screws.
10. Mount the **Mean Well SD-50C-12 enclosed DC-DC converter, 36-72 V in, 12 V 4.2 A (50 W)** (dcdc_12v) in **torso** with its case screws.
11. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **torso** with its case screws.
12. Mount the **CubeMars AK70-10 KV100** (l_shoulder_pitch_actuator) in **torso** with its case screws.
13. Set joint `l_shoulder_pitch` to zero (centre the servo first), then screw **l_shoulder_pitch_link** to the actuator output in **torso**; it moves -172° … 172°.
14. Mount the **CubeMars AK70-10 KV100** (l_shoulder_roll_actuator) in **l_shoulder_pitch_link** with its case screws.
15. Set joint `l_shoulder_roll` to zero (centre the servo first), then screw **l_shoulder_roll_link** to the actuator output in **l_shoulder_pitch_link**; it moves -2° … 92°.
16. Mount the **DYNAMIXEL XM430-W350-T(R)** (l_upper_arm_yaw_actuator) in **l_shoulder_roll_link** with its case screws.
17. Set joint `l_upper_arm_yaw` to zero (centre the servo first), then screw **l_upper_arm_yaw_link** to the actuator output in **l_shoulder_roll_link**; it moves -115° … 115°.
18. Mount the **DYNAMIXEL XH540-W270-T(R)** (l_elbow_actuator) in **l_upper_arm_yaw_link** with its case screws.
19. Set joint `l_elbow` to zero (centre the servo first), then screw **l_elbow_link** to the actuator output in **l_upper_arm_yaw_link**; it moves -132° … 125°.
20. Mount the **DYNAMIXEL XM430-W350-T(R)** (l_wrist_yaw_actuator) in **l_elbow_link** with its case screws.
21. Set joint `l_wrist_yaw` to zero (centre the servo first), then screw **l_wrist_yaw_link** to the actuator output in **l_elbow_link**; it moves -149° … 149°.
22. Mount the **DYNAMIXEL XH540-W270-T(R)** (l_wrist_pitch_actuator) in **l_wrist_yaw_link** with its case screws.
23. Set joint `l_wrist_pitch` to zero (centre the servo first), then screw **l_wrist_pitch_link** to the actuator output in **l_wrist_yaw_link**; it moves -92° … 73°.
24. Mount the **DYNAMIXEL XM430-W350-T(R)** (l_wrist_roll_actuator) in **l_wrist_pitch_link** with its case screws.
25. Set joint `l_wrist_roll` to zero (centre the servo first), then screw **l_wrist_roll_link** to the actuator output in **l_wrist_pitch_link**; it moves -160° … 160°.
26. Mount the **DYNAMIXEL XM430-W350-T(R)** (l_gripper_actuator) in **l_wrist_roll_link** with its case screws.
27. Set joint `l_gripper` to zero (centre the servo first), then screw **l_gripper_jaw** to the actuator output in **l_wrist_roll_link**; it moves -20° … 17°.
28. Bolt **l_shoulder_roll_armour_out** to **l_shoulder_roll_link**.
29. Mount the **CubeMars AK70-10 KV100** (r_shoulder_pitch_actuator) in **torso** with its case screws.
30. Set joint `r_shoulder_pitch` to zero (centre the servo first), then screw **r_shoulder_pitch_link** to the actuator output in **torso**; it moves -172° … 172°.
31. Mount the **CubeMars AK70-10 KV100** (r_shoulder_roll_actuator) in **r_shoulder_pitch_link** with its case screws.
32. Set joint `r_shoulder_roll` to zero (centre the servo first), then screw **r_shoulder_roll_link** to the actuator output in **r_shoulder_pitch_link**; it moves -92° … 2°.
33. Mount the **DYNAMIXEL XM430-W350-T(R)** (r_upper_arm_yaw_actuator) in **r_shoulder_roll_link** with its case screws.
34. Set joint `r_upper_arm_yaw` to zero (centre the servo first), then screw **r_upper_arm_yaw_link** to the actuator output in **r_shoulder_roll_link**; it moves -115° … 115°.
35. Mount the **DYNAMIXEL XH540-W270-T(R)** (r_elbow_actuator) in **r_upper_arm_yaw_link** with its case screws.
36. Set joint `r_elbow` to zero (centre the servo first), then screw **r_elbow_link** to the actuator output in **r_upper_arm_yaw_link**; it moves -125° … 132°.
37. Mount the **DYNAMIXEL XM430-W350-T(R)** (r_wrist_yaw_actuator) in **r_elbow_link** with its case screws.
38. Set joint `r_wrist_yaw` to zero (centre the servo first), then screw **r_wrist_yaw_link** to the actuator output in **r_elbow_link**; it moves -149° … 149°.
39. Mount the **DYNAMIXEL XH540-W270-T(R)** (r_wrist_pitch_actuator) in **r_wrist_yaw_link** with its case screws.
40. Set joint `r_wrist_pitch` to zero (centre the servo first), then screw **r_wrist_pitch_link** to the actuator output in **r_wrist_yaw_link**; it moves -73° … 92°.
41. Mount the **DYNAMIXEL XM430-W350-T(R)** (r_wrist_roll_actuator) in **r_wrist_pitch_link** with its case screws.
42. Set joint `r_wrist_roll` to zero (centre the servo first), then screw **r_wrist_roll_link** to the actuator output in **r_wrist_pitch_link**; it moves -160° … 160°.
43. Mount the **DYNAMIXEL XM430-W350-T(R)** (r_gripper_actuator) in **r_wrist_roll_link** with its case screws.
44. Set joint `r_gripper` to zero (centre the servo first), then screw **r_gripper_jaw** to the actuator output in **r_wrist_roll_link**; it moves -20° … 17°.
45. Bolt **r_shoulder_roll_armour_out** to **r_shoulder_roll_link**.
46. Mount the **DYNAMIXEL XL430-W250-T** (neck_pan_actuator) in **torso** with its case screws.
47. Set joint `neck_pan` to zero (centre the servo first), then screw **neck_pan_link** to the actuator output in **torso**; it moves -92° … 92°.
48. Mount the **DYNAMIXEL XM430-W350-T(R)** (neck_tilt_actuator) in **neck_pan_link** with its case screws.
49. Set joint `neck_tilt` to zero (centre the servo first), then screw **neck_tilt_link** to the actuator output in **neck_pan_link**; it moves -40° … 33°.
50. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (head_camera) in **neck_tilt_link** with its case screws.
51. Bolt **torso_armour_front** to **torso**.
52. Bolt **torso_b** to **base_link**.
53. Mount the **CubeMars AK60-6 V3.0 KV80** (l_hip_yaw_actuator) in **base_link** with its case screws.
54. Set joint `l_hip_yaw` to zero (centre the servo first), then screw **l_hip_yaw_link** to the actuator output in **base_link**; it moves -34° … 34°.
55. Mount the **CubeMars AK80-64 KV80** (l_hip_roll_actuator) in **l_hip_yaw_link** with its case screws.
56. Set joint `l_hip_roll` to zero (centre the servo first), then screw **l_hip_roll_link** to the actuator output in **l_hip_yaw_link**; it moves -4° … 26°.
57. Mount the **CubeMars AK80-64 KV80** (l_hip_pitch_actuator) in **l_hip_roll_link** with its case screws.
58. Set joint `l_hip_pitch` to zero (centre the servo first), then screw **l_hip_pitch_link** to the actuator output in **l_hip_roll_link**; it moves -48° … 92°.
59. Bolt **l_hip_pitch_link_b** to **l_hip_pitch_link**.
60. Mount the **CubeMars AK80-64 KV80** (l_knee_actuator) in **l_hip_pitch_link** with its case screws.
61. Set joint `l_knee` to zero (centre the servo first), then screw **l_knee_link** to the actuator output in **l_hip_pitch_link**; it moves -117° … 19°.
62. Bolt **l_knee_link_b** to **l_knee_link**.
63. Mount the **CubeMars AK80-64 KV80** (l_ankle_pitch_actuator) in **l_knee_link** with its case screws.
64. Set joint `l_ankle_pitch` to zero (centre the servo first), then screw **l_ankle_pitch_link** to the actuator output in **l_knee_link**; it moves -69° … 69°.
65. Mount the **CubeMars AK70-10 KV100** (l_ankle_roll_actuator) in **l_ankle_pitch_link** with its case screws.
66. Set joint `l_ankle_roll` to zero (centre the servo first), then screw **l_ankle_roll_link** to the actuator output in **l_ankle_pitch_link**; it moves -29° … 29°.
67. Bolt **l_sole_pad** to **l_ankle_roll_link**.
68. Bolt **l_knee_armour_front** to **l_knee_link**.
69. Bolt **l_hip_pitch_armour_front** to **l_hip_pitch_link**.
70. Mount the **CubeMars AK60-6 V3.0 KV80** (r_hip_yaw_actuator) in **base_link** with its case screws.
71. Set joint `r_hip_yaw` to zero (centre the servo first), then screw **r_hip_yaw_link** to the actuator output in **base_link**; it moves -34° … 34°.
72. Mount the **CubeMars AK80-64 KV80** (r_hip_roll_actuator) in **r_hip_yaw_link** with its case screws.
73. Set joint `r_hip_roll` to zero (centre the servo first), then screw **r_hip_roll_link** to the actuator output in **r_hip_yaw_link**; it moves -26° … 4°.
74. Mount the **CubeMars AK80-64 KV80** (r_hip_pitch_actuator) in **r_hip_roll_link** with its case screws.
75. Set joint `r_hip_pitch` to zero (centre the servo first), then screw **r_hip_pitch_link** to the actuator output in **r_hip_roll_link**; it moves -92° … 48°.
76. Bolt **r_hip_pitch_link_b** to **r_hip_pitch_link**.
77. Mount the **CubeMars AK80-64 KV80** (r_knee_actuator) in **r_hip_pitch_link** with its case screws.
78. Set joint `r_knee` to zero (centre the servo first), then screw **r_knee_link** to the actuator output in **r_hip_pitch_link**; it moves -19° … 117°.
79. Bolt **r_knee_link_b** to **r_knee_link**.
80. Mount the **CubeMars AK80-64 KV80** (r_ankle_pitch_actuator) in **r_knee_link** with its case screws.
81. Set joint `r_ankle_pitch` to zero (centre the servo first), then screw **r_ankle_pitch_link** to the actuator output in **r_knee_link**; it moves -69° … 69°.
82. Mount the **CubeMars AK70-10 KV100** (r_ankle_roll_actuator) in **r_ankle_pitch_link** with its case screws.
83. Set joint `r_ankle_roll` to zero (centre the servo first), then screw **r_ankle_roll_link** to the actuator output in **r_ankle_pitch_link**; it moves -29° … 29°.
84. Bolt **r_sole_pad** to **r_ankle_roll_link**.
85. Bolt **r_knee_armour_front** to **r_knee_link**.
86. Bolt **r_hip_pitch_armour_front** to **r_hip_pitch_link**.

## Fasteners

- 36 × M3 x 16 split-joint bolts + nuts
- 4 × M3 x 12 torso-to-pelvis bolts
- 96 × M3 x 8 housing screws
- 112 × horn / hub screws
- 48 × M2/M2.5 x 6 case screws
- 28 × M3 x 10 armour screws + printed standoffs

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
