# Printability — battle_mech

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| torso | 160 × 280 × 3 | ❌ |
| torso_service_lid | 160 × 280 × 3 | ❌ |
| torso_rear_panel | 3 × 280 × 354 | ❌ |
| torso_right_panel | 154 × 3 × 354 | ❌ |
| torso_front_panel | 3 × 280 × 354 | ❌ |
| torso_left_panel | 154 × 3 × 354 | ❌ |
| torso_standoff_rr | 8 × 8 × 354 | ❌ |
| torso_standoff_rl | 8 × 8 × 354 | ❌ |
| torso_standoff_fr | 8 × 8 × 354 | ❌ |
| torso_standoff_fl | 8 × 8 × 354 | ❌ |
| head | 180 × 180 × 180 | ✅ |
| left_shoulder | 70 × 70 × 60 | ✅ |
| left_upper_arm | 94.5 × 94.5 × 220 | ✅ |
| left_elbow | 70 × 70 × 60 | ✅ |
| left_forearm | 94.5 × 94.5 × 220 | ✅ |
| left_wrist_1 | 70 × 70 × 60 | ✅ |
| left_wrist_2 | 70 × 70 × 60 | ✅ |
| left_wrist_3 | 70 × 70 × 60 | ✅ |
| right_shoulder | 70 × 70 × 60 | ✅ |
| right_upper_arm | 94.5 × 94.5 × 220 | ✅ |
| right_elbow | 70 × 70 × 60 | ✅ |
| right_forearm | 94.5 × 94.5 × 220 | ✅ |
| right_wrist_1 | 70 × 70 × 60 | ✅ |
| right_wrist_2 | 70 × 70 × 60 | ✅ |
| right_wrist_3 | 70 × 70 × 60 | ✅ |
| left_hip_yaw_carrier | 46 × 46 × 16 | ✅ |
| left_hip_roll_carrier | 40 × 40 × 18 | ✅ |
| left_thigh | 121.5 × 121.5 × 197 | ✅ |
| left_shin | 108 × 108 × 197 | ✅ |
| left_foot | 160 × 80 × 40 | ✅ |
| left_ankle_pitch_carrier | 30 × 30 × 22 | ✅ |
| right_hip_yaw_carrier | 46 × 46 × 16 | ✅ |
| right_hip_roll_carrier | 40 × 40 × 18 | ✅ |
| right_thigh | 121.5 × 121.5 × 197 | ✅ |
| right_shin | 108 × 108 × 197 | ✅ |
| right_foot | 160 × 80 × 40 | ✅ |
| right_ankle_pitch_carrier | 30 × 30 × 22 | ✅ |
| arc_reactor | 70 × 70 × 15 | ✅ |
| left_palm_repulsor | 60 × 60 × 20 | ✅ |
| right_palm_repulsor | 60 × 60 × 20 | ✅ |
| left_boot_thruster | 60 × 60 × 20 | ✅ |
| right_boot_thruster | 60 × 60 × 20 | ✅ |

## Notes
- ⚠️ **torso**: longest dimension 280 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_service_lid**: longest dimension 280 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_rear_panel**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_right_panel**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_front_panel**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_left_panel**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_rr**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_rl**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_fr**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_fl**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **head**: sphere needs supports or a flat-cut base to print
