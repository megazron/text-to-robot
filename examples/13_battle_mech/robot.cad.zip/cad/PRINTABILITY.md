# Printability — battle_mech

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| torso | 160 × 280 × 360 | ❌ |
| head | 180 × 180 × 180 | ✅ |
| left_shoulder | 70 × 70 × 60 | ✅ |
| left_upper_arm | 94.5 × 94.5 × 220 | ✅ |
| left_elbow | 70 × 70 × 60 | ✅ |
| left_forearm | 94.5 × 94.5 × 220 | ✅ |
| left_wrist_1 | 70 × 70 × 60 | ✅ |
| left_wrist_2 | 70 × 70 × 60 | ✅ |
| left_wrist_3 | 70 × 70 × 60 | ✅ |
| right_shoulder | 70 × 70 × 60 | ✅ |
| right_upper_arm | 94.5 × 94.5 × 220 | ✅ |
| right_elbow | 70 × 70 × 60 | ✅ |
| right_forearm | 94.5 × 94.5 × 220 | ✅ |
| right_wrist_1 | 70 × 70 × 60 | ✅ |
| right_wrist_2 | 70 × 70 × 60 | ✅ |
| right_wrist_3 | 70 × 70 × 60 | ✅ |
| left_thigh | 121.5 × 121.5 × 200 | ✅ |
| left_shin | 108 × 108 × 200 | ✅ |
| left_foot | 160 × 80 × 40 | ✅ |
| right_thigh | 121.5 × 121.5 × 200 | ✅ |
| right_shin | 108 × 108 × 200 | ✅ |
| right_foot | 160 × 80 × 40 | ✅ |
| arc_reactor | 70 × 70 × 15 | ✅ |
| left_palm_repulsor | 60 × 60 × 20 | ✅ |
| right_palm_repulsor | 60 × 60 × 20 | ✅ |
| left_boot_thruster | 60 × 60 × 20 | ✅ |
| right_boot_thruster | 60 × 60 × 20 | ✅ |

## Notes
- ⚠️ **torso**: longest dimension 360 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **head**: sphere needs supports or a flat-cut base to print
