# Print list — battle_mech

45 parts, about 6136 g of PETG and 559.2 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 89 × 141.5 × 51.5 | 123 | 11.2 | yes |
| base_link_b | 89 × 141.5 × 51.5 | 123 | 11.2 | yes |
| torso | 180.5 × 240 × 211.8 | 645 | 58.8 | yes |
| torso_b | 180.5 × 240 × 211.8 | 981 | 89.4 | yes |
| l_hip_yaw_link | 64.9 × 105.3 × 109 | 116 | 10.6 | yes |
| l_hip_roll_link | 205.5 × 64.8 × 115 | 111 | 10.1 | yes |
| l_hip_pitch_link | 140.1 × 126.7 × 67.9 | 150 | 13.7 | yes |
| l_hip_pitch_link_b | 137 × 97.4 × 8 | 60 | 5.5 | yes |
| l_knee_link | 138 × 116.8 × 67.9 | 150 | 13.6 | yes |
| l_knee_link_b | 133.7 × 94 × 8 | 57 | 5.2 | yes |
| l_ankle_pitch_link | 192.1 × 53.3 × 95 | 95 | 8.6 | yes |
| l_ankle_roll_link | 96.4 × 120 × 220 | 216 | 19.7 | yes |
| r_hip_yaw_link | 64.9 × 105.3 × 109 | 116 | 10.6 | yes |
| r_hip_roll_link | 205.5 × 64.8 × 115 | 111 | 10.1 | yes |
| r_hip_pitch_link | 140.1 × 126.7 × 67.9 | 150 | 13.7 | yes |
| r_hip_pitch_link_b | 137 × 97.4 × 8 | 60 | 5.5 | yes |
| r_knee_link | 138 × 116.8 × 67.9 | 150 | 13.6 | yes |
| r_knee_link_b | 133.7 × 94 × 8 | 57 | 5.2 | yes |
| r_ankle_pitch_link | 192.1 × 53.3 × 95 | 95 | 8.6 | yes |
| r_ankle_roll_link | 96.4 × 120 × 220 | 216 | 19.7 | yes |
| l_shoulder_pitch_link | 95 × 51.3 × 148.4 | 172 | 15.6 | yes |
| l_shoulder_roll_link | 128.3 × 41 × 72.4 | 65 | 5.9 | yes |
| l_upper_arm_yaw_link | 39.5 × 49 × 159 | 115 | 10.4 | yes |
| l_elbow_link | 108.8 × 56.3 × 49.3 | 67 | 6.1 | yes |
| l_wrist_yaw_link | 41.4 × 50.6 × 70.5 | 38 | 3.5 | yes |
| l_wrist_pitch_link | 108.8 × 56.3 × 49.3 | 67 | 6.1 | yes |
| l_wrist_roll_link | 50.2 × 43.1 × 155.3 | 39 | 3.6 | yes |
| l_gripper_jaw | 124.3 × 39.3 × 8.5 | 14 | 1.3 | yes |
| r_shoulder_pitch_link | 95 × 51.3 × 148.4 | 173 | 15.8 | yes |
| r_shoulder_roll_link | 128.3 × 41 × 72.4 | 65 | 5.9 | yes |
| r_upper_arm_yaw_link | 39.5 × 49 × 159 | 115 | 10.4 | yes |
| r_elbow_link | 108.8 × 56.3 × 49.3 | 65 | 5.9 | yes |
| r_wrist_yaw_link | 41.4 × 50.6 × 70.5 | 38 | 3.5 | yes |
| r_wrist_pitch_link | 108.8 × 56.3 × 49.3 | 65 | 5.9 | yes |
| r_wrist_roll_link | 50.2 × 43.1 × 155.3 | 39 | 3.6 | yes |
| r_gripper_jaw | 124.3 × 39.3 × 8.5 | 14 | 1.3 | yes |
| neck_pan_link | 34.5 × 38.9 × 129.3 | 66 | 6.0 | yes |
| neck_tilt_link | 118.3 × 135.2 × 144 | 918 | 83.7 | yes |
| torso_armour_front | 2.5 × 228 × 199.8 | 104 | 9.5 | yes |
| l_hip_pitch_armour_front | 245.6 × 32.1 × 57.9 | 32 | 3.0 | yes |
| l_knee_armour_front | 157.1 × 21.3 × 57.9 | 21 | 1.9 | yes |
| l_shoulder_roll_armour_out | 38.1 × 2.5 × 60.4 | 5 | 0.5 | yes |
| r_hip_pitch_armour_front | 245.6 × 32.1 × 57.9 | 32 | 3.0 | yes |
| r_knee_armour_front | 157.1 × 21.3 × 57.9 | 21 | 1.9 | yes |
| r_shoulder_roll_armour_out | 38.1 × 2.5 × 60.4 | 5 | 0.5 | yes |
