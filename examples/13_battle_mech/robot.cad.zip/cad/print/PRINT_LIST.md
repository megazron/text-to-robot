# Print list: battle_mech

52 parts, about 6550 g of PETG and 596.9 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 89 × 141.5 × 51.5 | 114 | 10.4 | yes |
| base_link_b | 89 × 141.5 × 65.3 | 115 | 10.5 | yes |
| torso | 200.5 × 230 × 43 | 364 | 33.2 | yes |
| torso_b | 200.5 × 120 × 236.4 | 694 | 63.2 | yes |
| torso_b_b | 200.5 × 120 × 233.8 | 693 | 63.1 | yes |
| l_hip_yaw_link | 64.9 × 105.3 × 109 | 114 | 10.4 | yes |
| l_hip_roll_link | 205.5 × 64.8 × 115 | 109 | 10.0 | yes |
| l_hip_pitch_link | 140.1 × 126.7 × 67.9 | 144 | 13.1 | yes |
| l_hip_pitch_link_b | 137 × 97.4 × 22.3 | 61 | 5.6 | yes |
| l_knee_link | 138 × 116.8 × 67.9 | 144 | 13.1 | yes |
| l_knee_link_b | 133.7 × 94 × 8 | 57 | 5.2 | yes |
| l_ankle_pitch_link | 192.1 × 53.3 × 95 | 93 | 8.4 | yes |
| l_ankle_roll_link | 96.4 × 120 × 220 | 216 | 19.7 | yes |
| r_hip_yaw_link | 64.9 × 105.3 × 109 | 114 | 10.4 | yes |
| r_hip_roll_link | 205.5 × 64.8 × 115 | 109 | 10.0 | yes |
| r_hip_pitch_link | 140.1 × 126.7 × 67.9 | 144 | 13.1 | yes |
| r_hip_pitch_link_b | 137 × 97.4 × 20.3 | 60 | 5.5 | yes |
| r_knee_link | 138 × 116.8 × 67.9 | 144 | 13.1 | yes |
| r_knee_link_b | 133.7 × 94 × 8 | 57 | 5.2 | yes |
| r_ankle_pitch_link | 192.1 × 53.3 × 95 | 93 | 8.4 | yes |
| r_ankle_roll_link | 96.4 × 120 × 220 | 216 | 19.7 | yes |
| l_shoulder_pitch_link | 95 × 51.3 × 148.4 | 169 | 15.4 | yes |
| l_shoulder_roll_link | 128.3 × 41 × 72.4 | 65 | 5.9 | yes |
| l_upper_arm_yaw_link | 52.6 × 49.4 × 159 | 114 | 10.4 | yes |
| l_elbow_link | 108.8 × 56.3 × 49.3 | 64 | 5.8 | yes |
| l_wrist_yaw_link | 41.4 × 50.6 × 70.5 | 38 | 3.4 | yes |
| l_wrist_pitch_link | 108.8 × 56.3 × 49.3 | 64 | 5.8 | yes |
| l_wrist_roll_link | 50.2 × 43.1 × 155.3 | 39 | 3.5 | yes |
| l_gripper_jaw | 124.3 × 39.3 × 8.5 | 14 | 1.3 | yes |
| r_shoulder_pitch_link | 95 × 51.3 × 148.4 | 171 | 15.6 | yes |
| r_shoulder_roll_link | 128.3 × 41 × 72.4 | 65 | 5.9 | yes |
| r_upper_arm_yaw_link | 39.5 × 49 × 159 | 114 | 10.4 | yes |
| r_elbow_link | 108.8 × 56.3 × 49.3 | 63 | 5.8 | yes |
| r_wrist_yaw_link | 41.4 × 50.6 × 70.5 | 38 | 3.4 | yes |
| r_wrist_pitch_link | 108.8 × 56.3 × 49.3 | 63 | 5.8 | yes |
| r_wrist_roll_link | 50.2 × 43.1 × 155.3 | 39 | 3.5 | yes |
| r_gripper_jaw | 124.3 × 39.3 × 8.5 | 14 | 1.3 | yes |
| neck_pan_link | 38.7 × 49.2 × 129.3 | 66 | 6.0 | yes |
| neck_tilt_link | 118.3 × 135.2 × 144 | 901 | 82.1 | yes |
| torso_armour_front | 4.1 × 228 × 199.8 | 159 | 14.5 | yes |
| l_hip_pitch_armour_front | 245.6 × 32.6 × 57.9 | 46 | 4.2 | yes |
| l_knee_armour_front | 157.9 × 21.8 × 57.9 | 29 | 2.7 | yes |
| l_shoulder_roll_armour_out | 38.7 × 4.1 × 60.4 | 7 | 0.6 | yes |
| r_hip_pitch_armour_front | 245.6 × 32.6 × 57.9 | 46 | 4.2 | yes |
| r_knee_armour_front | 157.9 × 21.8 × 57.9 | 29 | 2.7 | yes |
| r_shoulder_roll_armour_out | 38.7 × 4.1 × 60.4 | 7 | 0.6 | yes |
| side_panel_left | 180 × 2.4 × 62 | 17 | 1.6 | yes |
| side_panel_right | 180 × 2.4 × 62 | 17 | 1.6 | yes |
| chest_panel | 2.4 × 218 × 69.3 | 23 | 2.1 | yes |
| backpack_hood | 215.4 × 178.4 × 67.8 | 164 | 15.0 | yes |
| switch_case | 78.4 × 78.4 × 62.8 | 40 | 3.7 | yes |
| imu_hood | 44 × 42.4 × 35.8 | 12 | 1.1 | yes |
