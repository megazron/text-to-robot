// concept part: left_hip_roll_carrier (joint_housing)
// units: mm. Mesh with: openscad -o left_hip_roll_carrier.stl left_hip_roll_carrier.scad
multmatrix([[0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=18, r=20, center=true, $fn=48);
