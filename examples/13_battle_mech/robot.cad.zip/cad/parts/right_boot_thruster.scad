// concept part: right_boot_thruster (sensor)
// units: mm. Mesh with: openscad -o right_boot_thruster.stl right_boot_thruster.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=20, r=30, center=true, $fn=48);
