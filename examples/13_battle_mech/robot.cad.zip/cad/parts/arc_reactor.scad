// concept part: arc_reactor (sensor)
// units: mm. Mesh with: openscad -o arc_reactor.stl arc_reactor.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=15, r=35, center=true, $fn=48);
