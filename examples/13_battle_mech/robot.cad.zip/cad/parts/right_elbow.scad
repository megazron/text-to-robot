// concept part: right_elbow (elbow)
// units: mm. Mesh with: openscad -o right_elbow.stl right_elbow.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -30], [0, 0, 0, 1]])
  cylinder(h=60, r=35, center=true, $fn=48);
