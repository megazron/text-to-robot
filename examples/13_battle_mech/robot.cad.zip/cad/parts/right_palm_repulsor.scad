// concept part: right_palm_repulsor (sensor)
// units: mm. Mesh with: openscad -o right_palm_repulsor.stl right_palm_repulsor.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=20, r=30, center=true, $fn=48);
