// concept part: torso_service_lid (housing)
// units: mm. Mesh with: openscad -o torso_service_lid.stl torso_service_lid.scad
import("../stl/parts/torso_service_lid.stl");
