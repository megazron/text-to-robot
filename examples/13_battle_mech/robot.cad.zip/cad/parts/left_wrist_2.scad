// concept part: left_wrist_2 (wrist_2)
// units: mm. Mesh with: openscad -o left_wrist_2.stl left_wrist_2.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -22.5], [0, 0, 0, 1]])
  cylinder(h=45, r=35, center=true, $fn=48);
