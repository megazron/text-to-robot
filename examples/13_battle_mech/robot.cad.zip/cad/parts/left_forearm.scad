// concept part: left_forearm (forearm)
// units: mm. Mesh with: openscad -o left_forearm.stl left_forearm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -91.25], [0, 0, 0, 1]])
  cylinder(h=182.5, r=47.25, center=true, $fn=48);
