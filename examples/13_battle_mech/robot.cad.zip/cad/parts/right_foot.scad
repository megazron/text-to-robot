// concept part: right_foot (link)
// units: mm. Mesh with: openscad -o right_foot.stl right_foot.scad
multmatrix([[1, 0, 0, 30], [0, 1, 0, 0], [0, 0, 1, -20], [0, 0, 0, 1]])
  cube([160, 80, 40], center=true);
