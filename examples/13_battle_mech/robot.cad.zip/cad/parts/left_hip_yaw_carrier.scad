// concept part: left_hip_yaw_carrier (joint_housing)
// units: mm. Mesh with: openscad -o left_hip_yaw_carrier.stl left_hip_yaw_carrier.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=16, r=23, center=true, $fn=48);
