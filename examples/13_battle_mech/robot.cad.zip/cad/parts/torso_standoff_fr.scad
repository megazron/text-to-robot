// concept part: torso_standoff_fr (housing)
// units: mm. Mesh with: openscad -o torso_standoff_fr.stl torso_standoff_fr.scad
import("../stl/parts/torso_standoff_fr.stl");
