// concept part: left_wrist_3 (wrist_3)
// units: mm. Mesh with: openscad -o left_wrist_3.stl left_wrist_3.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -30], [0, 0, 0, 1]])
  cylinder(h=60, r=35, center=true, $fn=48);
