// concept part: left_palm_repulsor (sensor)
// units: mm. Mesh with: openscad -o left_palm_repulsor.stl left_palm_repulsor.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=20, r=30, center=true, $fn=48);
