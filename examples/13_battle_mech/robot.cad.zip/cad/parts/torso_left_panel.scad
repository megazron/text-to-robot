// concept part: torso_left_panel (housing)
// units: mm. Mesh with: openscad -o torso_left_panel.stl torso_left_panel.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 138.5], [0, 0, 1, 620], [0, 0, 0, 1]])
  cube([154, 3, 354], center=true);
