// concept part: left_wrist_1 (wrist_1)
// units: mm. Mesh with: openscad -o left_wrist_1.stl left_wrist_1.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -30], [0, 0, 0, 1]])
  cylinder(h=60, r=35, center=true, $fn=48);
