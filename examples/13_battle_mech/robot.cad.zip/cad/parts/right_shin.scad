// concept part: right_shin (link)
// units: mm. Mesh with: openscad -o right_shin.stl right_shin.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -98.5], [0, 0, 0, 1]])
  cylinder(h=197, r=54, center=true, $fn=48);
