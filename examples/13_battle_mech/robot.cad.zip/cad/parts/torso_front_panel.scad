// concept part: torso_front_panel (housing)
// units: mm. Mesh with: openscad -o torso_front_panel.stl torso_front_panel.scad
multmatrix([[1, 0, 0, 78.5], [0, 1, 0, 0], [0, 0, 1, 620], [0, 0, 0, 1]])
  cube([3, 280, 354], center=true);
