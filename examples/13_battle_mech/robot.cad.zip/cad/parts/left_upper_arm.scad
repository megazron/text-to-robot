// concept part: left_upper_arm (upper_arm)
// units: mm. Mesh with: openscad -o left_upper_arm.stl left_upper_arm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -110], [0, 0, 0, 1]])
  cylinder(h=220, r=47.25, center=true, $fn=48);
