// concept part: right_upper_arm (upper_arm)
// units: mm. Mesh with: openscad -o right_upper_arm.stl right_upper_arm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -91.25], [0, 0, 0, 1]])
  cylinder(h=182.5, r=47.25, center=true, $fn=48);
