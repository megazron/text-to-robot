// concept part: left_shin (link)
// units: mm. Mesh with: openscad -o left_shin.stl left_shin.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -100], [0, 0, 0, 1]])
  cylinder(h=200, r=54, center=true, $fn=48);
