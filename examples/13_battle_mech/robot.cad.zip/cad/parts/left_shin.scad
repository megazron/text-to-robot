// concept part: left_shin (link)
// units: mm. Mesh with: openscad -o left_shin.stl left_shin.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -98.5], [0, 0, 0, 1]])
  cylinder(h=197, r=54, center=true, $fn=48);
