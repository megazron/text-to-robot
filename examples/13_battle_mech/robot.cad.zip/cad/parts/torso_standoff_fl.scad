// concept part: torso_standoff_fl (housing)
// units: mm. Mesh with: openscad -o torso_standoff_fl.stl torso_standoff_fl.scad
import("../stl/parts/torso_standoff_fl.stl");
