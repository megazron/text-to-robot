// concept part: left_shoulder (shoulder)
// units: mm. Mesh with: openscad -o left_shoulder.stl left_shoulder.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -30], [0, 0, 0, 1]])
  cylinder(h=60, r=35, center=true, $fn=48);
