// concept part: torso_standoff_rr (housing)
// units: mm. Mesh with: openscad -o torso_standoff_rr.stl torso_standoff_rr.scad
import("../stl/parts/torso_standoff_rr.stl");
