// concept part: torso_standoff_rl (housing)
// units: mm. Mesh with: openscad -o torso_standoff_rl.stl torso_standoff_rl.scad
import("../stl/parts/torso_standoff_rl.stl");
