// concept part: torso (base)
// units: mm. Mesh with: openscad -o torso.stl torso.scad
import("../stl/parts/torso.stl");
