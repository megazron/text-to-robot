# Print list: quadruped

15 parts, about 575 g of PETG and 52.4 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 227.2 × 99.8 × 47 | 170 | 15.5 | yes |
| top_deck | 226.2 × 98.8 × 34 | 71 | 6.4 | yes |
| fl_shoulder | 46.4 × 30.8 × 56.9 | 24 | 2.2 | yes |
| fl_thigh | 133.2 × 32.8 × 40.1 | 25 | 2.3 | yes |
| fl_shin | 131.4 × 28 × 6 | 14 | 1.2 | yes |
| fr_shoulder | 46.4 × 30.8 × 56.9 | 24 | 2.2 | yes |
| fr_thigh | 133.2 × 32.8 × 40.1 | 25 | 2.3 | yes |
| fr_shin | 131.4 × 28 × 6 | 14 | 1.2 | yes |
| rl_shoulder | 46.4 × 30.8 × 56.9 | 24 | 2.2 | yes |
| rl_thigh | 133.2 × 32.8 × 40.1 | 25 | 2.3 | yes |
| rl_shin | 131.4 × 28 × 6 | 14 | 1.2 | yes |
| rr_shoulder | 46.4 × 30.8 × 56.9 | 24 | 2.2 | yes |
| rr_thigh | 133.2 × 32.8 × 40.1 | 25 | 2.3 | yes |
| rr_shin | 131.4 × 28 × 6 | 14 | 1.2 | yes |
| electronics_hood | 219 × 87.7 × 47.1 | 83 | 7.5 | yes |
