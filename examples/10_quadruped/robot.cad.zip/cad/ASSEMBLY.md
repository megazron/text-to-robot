# Assembly — quadruped

Start from **base_link**.

1. Mount the **LiPo 3S 2200 mAh 25C, XT60 (Gens Ace G-Tech)** (battery) in **base_link** with its case screws.
2. Bolt **top_deck** to **base_link**.
3. Mount the **Raspberry Pi 5 (4 GB)** (computer) in **top_deck** with its case screws.
4. Mount the **Waveshare Bus Servo Adapter (A)** (actuator_bus) in **top_deck** with its case screws.
5. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **top_deck** with its case screws.
6. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **top_deck** with its case screws.
7. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (camera) in **top_deck** with its case screws.
8. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (fl_hip_abduction_actuator) in **base_link** with its case screws.
9. Set joint `fl_hip_abduction` to zero (centre the servo first), then screw **fl_shoulder** to the actuator output in **base_link**; it moves -9° … 34°.
10. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (fl_hip_pitch_actuator) in **fl_shoulder** with its case screws.
11. Set joint `fl_hip_pitch` to zero (centre the servo first), then screw **fl_thigh** to the actuator output in **fl_shoulder**; it moves -80° … 80°.
12. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (fl_knee_actuator) in **fl_thigh** with its case screws.
13. Set joint `fl_knee` to zero (centre the servo first), then screw **fl_shin** to the actuator output in **fl_thigh**; it moves -74° … 74°.
14. Bolt **fl_foot** to **fl_shin**.
15. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (fr_hip_abduction_actuator) in **base_link** with its case screws.
16. Set joint `fr_hip_abduction` to zero (centre the servo first), then screw **fr_shoulder** to the actuator output in **base_link**; it moves -34° … 9°.
17. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (fr_hip_pitch_actuator) in **fr_shoulder** with its case screws.
18. Set joint `fr_hip_pitch` to zero (centre the servo first), then screw **fr_thigh** to the actuator output in **fr_shoulder**; it moves -80° … 80°.
19. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (fr_knee_actuator) in **fr_thigh** with its case screws.
20. Set joint `fr_knee` to zero (centre the servo first), then screw **fr_shin** to the actuator output in **fr_thigh**; it moves -74° … 74°.
21. Bolt **fr_foot** to **fr_shin**.
22. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rl_hip_abduction_actuator) in **base_link** with its case screws.
23. Set joint `rl_hip_abduction` to zero (centre the servo first), then screw **rl_shoulder** to the actuator output in **base_link**; it moves -34° … 9°.
24. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rl_hip_pitch_actuator) in **rl_shoulder** with its case screws.
25. Set joint `rl_hip_pitch` to zero (centre the servo first), then screw **rl_thigh** to the actuator output in **rl_shoulder**; it moves -80° … 80°.
26. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rl_knee_actuator) in **rl_thigh** with its case screws.
27. Set joint `rl_knee` to zero (centre the servo first), then screw **rl_shin** to the actuator output in **rl_thigh**; it moves -74° … 74°.
28. Bolt **rl_foot** to **rl_shin**.
29. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rr_hip_abduction_actuator) in **base_link** with its case screws.
30. Set joint `rr_hip_abduction` to zero (centre the servo first), then screw **rr_shoulder** to the actuator output in **base_link**; it moves -9° … 34°.
31. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rr_hip_pitch_actuator) in **rr_shoulder** with its case screws.
32. Set joint `rr_hip_pitch` to zero (centre the servo first), then screw **rr_thigh** to the actuator output in **rr_shoulder**; it moves -80° … 80°.
33. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (rr_knee_actuator) in **rr_thigh** with its case screws.
34. Set joint `rr_knee` to zero (centre the servo first), then screw **rr_shin** to the actuator output in **rr_thigh**; it moves -74° … 74°.
35. Bolt **rr_foot** to **rr_shin**.

## Fasteners

- 4 × M2.5 x 10 board screws
- 4 × M3 x 10 deck screws
- 48 × M2 x 6 case screws
- 48 × horn screws

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
