# Build package: quadruped

Servo quadruped, 1.41 kg, hip height 0.18 m, 12 DOF, 33 min runtime, $530 of parts

1. **Buy** everything in `BOM.md` (supplier links included).
2. **Print** every STL in `print/` (see `print/PRINT_LIST.md`).
3. **Assemble** in the order of `ASSEMBLY.md`.
   **Wire** from `WIRING.md` (pin-to-pin table, cut list, power budget, battery runtime, regulator heat, logic levels), `schematic.svg` / `schematic.pdf` the picture view `breadboard.svg` and the harness in 3D `electronics.glb`.
4. **Check** against `design.json`: each actuator's required vs rated torque, the speed it reaches loaded, battery runtime, stability and every other check the design passed.

`reference/` holds the bought parts' models (from their datasheet drawings) for your own CAD; `quadruped_assembly.stl` is the whole robot in its build pose.

## Assumptions

- A trot has two diagonal feet on the ground: the COM sits on the support line, so trotting needs the dynamic balance of the gait controller; the creep gait keeps three feet down (statically stable).
- Every joint's limits are inside its collision-free range (exact solid sweeps).
- Zero joint angles are the standing pose (knees bent); the base origin is at hip-axis height with the feet on the ground plane.
- Joint loads are J^T F at the stance feet for a trot (two diagonal feet carry the whole robot + payload) over a gait envelope, plus ±15 % traction forces, x 1.3 dynamic factor; continuous duty checked at 71 % of the worst stance load (RMS over a gait cycle with half of it in stance).
- Feet are moulded / TPU-printed rubber spheres (contact pads) bolted to the shin tip.
- Servo dog: position-controlled gaits (open-loop trot / creep) run on the computer through the serial servo bus.
- Battery is strapped into the printed fence on the body floor; never screw into a pack.
