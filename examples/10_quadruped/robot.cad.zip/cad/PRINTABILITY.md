# Printability — quadruped

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 400 × 200 × 100 | ❌ |
| front_left_hip | 60 × 60 × 50 | ✅ |
| front_left_thigh | 44 × 44 × 160 | ✅ |
| front_left_shin | 36 × 36 × 160 | ✅ |
| front_right_hip | 60 × 60 × 50 | ✅ |
| front_right_thigh | 44 × 44 × 160 | ✅ |
| front_right_shin | 36 × 36 × 160 | ✅ |
| rear_left_hip | 60 × 60 × 50 | ✅ |
| rear_left_thigh | 44 × 44 × 160 | ✅ |
| rear_left_shin | 36 × 36 × 160 | ✅ |
| rear_right_hip | 60 × 60 × 50 | ✅ |
| rear_right_thigh | 44 × 44 × 160 | ✅ |
| rear_right_shin | 36 × 36 × 160 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
