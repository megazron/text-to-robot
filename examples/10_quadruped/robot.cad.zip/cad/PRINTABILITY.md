# Printability — quadruped

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 400 × 200 × 3 | ❌ |
| base_link_service_lid | 400 × 200 × 3 | ❌ |
| base_link_rear_panel | 3 × 200 × 94 | ✅ |
| base_link_right_panel | 394 × 3 × 94 | ❌ |
| base_link_front_panel | 3 × 200 × 94 | ✅ |
| base_link_left_panel | 394 × 3 × 94 | ❌ |
| base_link_standoff_rr | 8 × 8 × 94 | ✅ |
| base_link_standoff_rl | 8 × 8 × 94 | ✅ |
| base_link_standoff_fr | 8 × 8 × 94 | ✅ |
| base_link_standoff_fl | 8 × 8 × 94 | ✅ |
| front_left_hip | 60 × 60 × 50 | ✅ |
| front_left_thigh | 44 × 44 × 160 | ✅ |
| front_left_shin | 36 × 36 × 160 | ✅ |
| front_right_hip | 60 × 60 × 50 | ✅ |
| front_right_thigh | 44 × 44 × 160 | ✅ |
| front_right_shin | 36 × 36 × 160 | ✅ |
| rear_left_hip | 60 × 60 × 50 | ✅ |
| rear_left_thigh | 44 × 44 × 160 | ✅ |
| rear_left_shin | 36 × 36 × 160 | ✅ |
| rear_right_hip | 60 × 60 × 50 | ✅ |
| rear_right_thigh | 44 × 44 × 160 | ✅ |
| rear_right_shin | 36 × 36 × 160 | ✅ |
| front_left_foot | 50 × 50 × 50 | ✅ |
| front_right_foot | 50 × 50 × 50 | ✅ |
| rear_left_foot | 50 × 50 × 50 | ✅ |
| rear_right_foot | 50 × 50 × 50 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_service_lid**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_right_panel**: longest dimension 394 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_left_panel**: longest dimension 394 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **front_left_foot**: sphere needs supports or a flat-cut base to print
- ℹ️ **front_right_foot**: sphere needs supports or a flat-cut base to print
- ℹ️ **rear_left_foot**: sphere needs supports or a flat-cut base to print
- ℹ️ **rear_right_foot**: sphere needs supports or a flat-cut base to print
