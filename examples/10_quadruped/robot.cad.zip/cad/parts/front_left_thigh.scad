// concept part: front_left_thigh (link)
// units: mm. Mesh with: openscad -o front_left_thigh.stl front_left_thigh.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -80], [0, 0, 0, 1]])
  cylinder(h=160, r=22, center=true, $fn=48);
