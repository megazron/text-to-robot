// concept part: rear_right_hip (link)
// units: mm. Mesh with: openscad -o rear_right_hip.stl rear_right_hip.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=50, r=30, center=true, $fn=48);
