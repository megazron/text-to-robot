// concept part: base_link_right_panel (housing)
// units: mm. Mesh with: openscad -o base_link_right_panel.stl base_link_right_panel.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, -98.5], [0, 0, 1, 385], [0, 0, 0, 1]])
  cube([394, 3, 94], center=true);
