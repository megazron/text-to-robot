// concept part: rear_right_shin (link)
// units: mm. Mesh with: openscad -o rear_right_shin.stl rear_right_shin.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -80], [0, 0, 0, 1]])
  cylinder(h=160, r=18, center=true, $fn=48);
