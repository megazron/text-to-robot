// concept part: base_link (base)
// units: mm. Mesh with: openscad -o base_link.stl base_link.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 350], [0, 0, 0, 1]])
  cube([400, 200, 100], center=true);
