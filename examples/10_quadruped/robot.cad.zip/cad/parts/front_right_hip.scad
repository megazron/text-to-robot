// concept part: front_right_hip (link)
// units: mm. Mesh with: openscad -o front_right_hip.stl front_right_hip.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=50, r=30, center=true, $fn=48);
