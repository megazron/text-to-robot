// concept part: base_link_rear_panel (housing)
// units: mm. Mesh with: openscad -o base_link_rear_panel.stl base_link_rear_panel.scad
multmatrix([[1, 0, 0, -198.5], [0, 1, 0, 0], [0, 0, 1, 385], [0, 0, 0, 1]])
  cube([3, 200, 94], center=true);
