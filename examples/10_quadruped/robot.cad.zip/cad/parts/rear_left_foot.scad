// concept part: rear_left_foot (contact_pad)
// units: mm. Mesh with: openscad -o rear_left_foot.stl rear_left_foot.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  sphere(r=25, $fn=48);
