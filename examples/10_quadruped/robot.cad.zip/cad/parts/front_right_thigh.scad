// concept part: front_right_thigh (link)
// units: mm. Mesh with: openscad -o front_right_thigh.stl front_right_thigh.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -80], [0, 0, 0, 1]])
  cylinder(h=160, r=22, center=true, $fn=48);
