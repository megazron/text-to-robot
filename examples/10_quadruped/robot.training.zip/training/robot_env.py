"""Gymnasium environment for quadruped (auto-generated). Backend: PyBullet."""
import os
import numpy as np
import gymnasium as gym
from gymnasium import spaces
import pybullet as p
import pybullet_data
from pybullet_utils.bullet_client import BulletClient
import tasks as T

URDF = os.path.join(os.path.dirname(__file__), "quadruped.urdf")


class QuadrupedEnv(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 60}

    def __init__(self, render_mode=None, task=None, max_steps=1000):
        super().__init__()
        self.render_mode = render_mode
        self.task_name = task or T.DEFAULT_TASK
        self.task_fn = T.TASKS[self.task_name][1]
        self.max_steps = max_steps
        self.fall_height = 0.15
        self.p = BulletClient(connection_mode=p.GUI if render_mode == "human" else p.DIRECT)
        self.p.setAdditionalSearchPath(pybullet_data.getDataPath())
        self._load()
        n = len(self.joints)
        self.action_space = spaces.Box(-1.0, 1.0, shape=(n,), dtype=np.float32)
        self.observation_space = spaces.Box(-np.inf, np.inf, shape=(2 * n + 6,), dtype=np.float32)
        self.steps = 0

    def _load(self):
        self.p.resetSimulation(); self.p.setGravity(0, 0, -9.81)
        self.plane = self.p.loadURDF("plane.urdf")
        self.robot = self.p.loadURDF(URDF, [0, 0, 0.05], useFixedBase=False, flags=p.URDF_USE_INERTIA_FROM_FILE)
        self.joints = [j for j in range(self.p.getNumJoints(self.robot))
                       if self.p.getJointInfo(self.robot, j)[2] != p.JOINT_FIXED]
        self.limits = []; self.efforts = []; self.velocities = []
        for j in self.joints:
            info = self.p.getJointInfo(self.robot, j); lo, hi = info[8], info[9]
            if lo >= hi: lo, hi = -np.pi, np.pi
            self.limits.append((lo, hi))
            if info[10] <= 0 or info[11] <= 0: raise ValueError("URDF needs positive effort and velocity limits")
            self.efforts.append(info[10]); self.velocities.append(info[11])
        tip_name = "rear_right_shin"
        self.tip_index = next((j for j in range(self.p.getNumJoints(self.robot))
                               if self.p.getJointInfo(self.robot,j)[12].decode() == tip_name), -1)
        if self.task_name == "reach" and self.tip_index < 0:
            raise ValueError("Reaching requires a named tool link in the robot specification")

    def _obs(self):
        q = [self.p.getJointState(self.robot, j)[0] for j in self.joints]
        dq = [self.p.getJointState(self.robot, j)[1] for j in self.joints]
        pos, _ = self.p.getBasePositionAndOrientation(self.robot)
        extra = list(self.target) + list(pos) if hasattr(self, "target") else list(pos) + [0, 0, 0]
        return np.array(q + dq + extra[:6], dtype=np.float32)

    def reset(self, seed=None, options=None):
        super().reset(seed=seed); self._load(); self.steps = 0
        self.target = np.array([self.np_random.uniform(0.2, 0.6),
                                self.np_random.uniform(-0.3, 0.3),
                                self.np_random.uniform(0.1, 0.6)], dtype=np.float32)
        if self.task_name == "aperture":
            self.target[:] = [self.np_random.uniform(0, sum(hi-lo for lo,hi in self.limits)),0,0]
        return self._obs(), {}

    def apply(self, action):
        action = np.asarray(action, dtype=np.float32)
        if action.shape != (len(self.joints),) or not np.all(np.isfinite(action)):
            raise ValueError("Expected one finite action per actuated joint")
        action = np.clip(action, -1.0, 1.0)
        for a, j, (lo, hi), effort, velocity in zip(action, self.joints, self.limits, self.efforts, self.velocities):
            self.p.setJointMotorControl2(self.robot, j, p.POSITION_CONTROL,
                                    targetPosition=lo + (float(a) + 1.0) * 0.5 * (hi - lo), force=effort, maxVelocity=velocity)

    def step(self, action):
        self.apply(action); self.p.stepSimulation(); self.steps += 1
        reward, terminated = self.task_fn(self, np.asarray(action, dtype=np.float32))
        return self._obs(), reward, terminated, self.steps >= self.max_steps, {"is_success": bool(terminated and self.task_name in ("reach", "hold", "goto", "aperture"))}

    def close(self):
        if self.p.isConnected(): self.p.disconnect()


for _tid in T.TASKS:
    gym.register(id=f"Quadruped-{_tid}-v0",
                 entry_point="robot_env:QuadrupedEnv", kwargs={"task": _tid})
