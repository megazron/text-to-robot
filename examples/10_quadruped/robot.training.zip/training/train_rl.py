"""Reinforcement learning (PPO or SAC) for quadruped. Auto-generated.

    python train_rl.py --task reach --algo ppo --steps 200000
    python train_rl.py --play --task reach
"""
import argparse
import gymnasium as gym
from stable_baselines3 import PPO, SAC
from stable_baselines3.common.env_util import make_vec_env
import robot_env, tasks as T

ALGOS = {"ppo": PPO, "sac": SAC}


def env_id(task): return f"Quadruped-{task}-v0"


def _tb_dir():
    try:
        import tensorboard  # noqa: F401
        return "./tb"
    except ImportError:
        return None  # train fine without TensorBoard logging


def train(task, algo, steps):
    Algo = ALGOS[algo]
    env = make_vec_env(env_id(task), n_envs=4)
    model = Algo("MlpPolicy", env, verbose=1, tensorboard_log=_tb_dir())
    model.learn(total_timesteps=steps)
    model.save(f"quadruped_{algo}_{task}")
    print("saved", f"quadruped_{algo}_{task}.zip")


def play(task, algo):
    env = gym.make(env_id(task), render_mode="human")
    model = ALGOS[algo].load(f"quadruped_{algo}_{task}")
    obs, _ = env.reset()
    for _ in range(3000):
        a, _ = model.predict(obs, deterministic=True)
        obs, r, term, trunc, _ = env.step(a)
        if term or trunc: obs, _ = env.reset()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", default=T.DEFAULT_TASK, choices=list(T.TASKS))
    ap.add_argument("--algo", default="ppo", choices=list(ALGOS))
    ap.add_argument("--steps", type=int, default=200_000)
    ap.add_argument("--play", action="store_true")
    a = ap.parse_args()
    play(a.task, a.algo) if a.play else train(a.task, a.algo, a.steps)
