# Print list — arm_6dof

8 parts, about 354 g of PETG and 32.3 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 110 × 110 × 46.1 | 86 | 7.8 | yes |
| turret | 30.8 × 44.1 × 57.4 | 19 | 1.7 | yes |
| upper_arm | 120.4 × 30.8 × 62.3 | 53 | 4.8 | yes |
| forearm | 105.2 × 53.2 × 59.3 | 76 | 7.0 | yes |
| forearm_rotator | 30.8 × 44.1 × 57.4 | 19 | 1.7 | yes |
| wrist | 96.4 × 53.2 × 59.3 | 63 | 5.7 | yes |
| wrist_rotator | 49.6 × 40.4 × 114.2 | 29 | 2.6 | yes |
| gripper_jaw | 84 × 39 × 8.5 | 10 | 0.9 | yes |
