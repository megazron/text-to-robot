# Print list — arm_6dof

8 parts, about 231 g of PETG and 21.1 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 110 × 110 × 46.1 | 81 | 7.4 | yes |
| turret | 30.8 × 39.1 × 57.4 | 16 | 1.5 | yes |
| upper_arm | 135.4 × 30.8 × 41.6 | 25 | 2.3 | yes |
| forearm | 120.2 × 53.2 × 40 | 33 | 3.0 | yes |
| forearm_rotator | 30.8 × 39.1 × 57.4 | 16 | 1.5 | yes |
| wrist | 96.4 × 53.2 × 40 | 30 | 2.7 | yes |
| wrist_rotator | 47.6 × 40.4 × 114.2 | 24 | 2.2 | yes |
| gripper_jaw | 84 × 37 × 6.5 | 5 | 0.5 | yes |
