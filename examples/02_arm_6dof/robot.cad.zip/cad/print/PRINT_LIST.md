# Print list: arm_6dof

10 parts, about 568 g of PETG and 51.8 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 110 × 110 × 45.9 | 87 | 7.9 | yes |
| turret | 39.5 × 54 × 71.5 | 32 | 2.9 | yes |
| upper_arm | 144.7 × 34.5 × 69.2 | 81 | 7.4 | yes |
| forearm | 116.2 × 54.3 × 59.1 | 89 | 8.1 | yes |
| forearm_rotator | 34.5 × 43.9 × 59.5 | 20 | 1.8 | yes |
| wrist | 98.1 × 54.3 × 59.1 | 57 | 5.2 | yes |
| wrist_rotator | 49.4 × 42.3 × 115.3 | 31 | 2.9 | yes |
| gripper_jaw | 84.3 × 39.3 × 8.5 | 10 | 0.9 | yes |
| control_case | 204.7 × 139.7 × 44.4 | 116 | 10.5 | yes |
| control_case_lid | 204.7 × 139.7 × 5.8 | 46 | 4.2 | yes |
