// concept part: base_link_standoff_fl (housing)
// units: mm. Mesh with: openscad -o base_link_standoff_fl.stl base_link_standoff_fl.scad
import("../stl/parts/base_link_standoff_fl.stl");
