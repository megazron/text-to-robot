// concept part: wrist_1_joint_hub (joint_housing)
// units: mm. Mesh with: openscad -o wrist_1_joint_hub.stl wrist_1_joint_hub.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=15.8592, center=true, $fn=48);
