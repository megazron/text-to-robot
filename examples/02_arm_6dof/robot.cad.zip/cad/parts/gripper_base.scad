// concept part: gripper_base (gripper)
// units: mm. Mesh with: openscad -o gripper_base.stl gripper_base.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 15], [0, 0, 0, 1]])
  cube([60, 80, 30], center=true);
