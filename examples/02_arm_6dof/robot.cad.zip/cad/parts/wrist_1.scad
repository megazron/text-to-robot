// concept part: wrist_1 (wrist_1)
// units: mm. Mesh with: openscad -o wrist_1.stl wrist_1.scad
import("../stl/parts/wrist_1.stl");
