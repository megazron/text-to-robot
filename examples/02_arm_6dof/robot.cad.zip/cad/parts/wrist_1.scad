// concept part: wrist_1 (wrist_1)
// units: mm. Mesh with: openscad -o wrist_1.stl wrist_1.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 28], [0, 0, 0, 1]])
  cylinder(h=22.4, r=13.44, center=true, $fn=48);
