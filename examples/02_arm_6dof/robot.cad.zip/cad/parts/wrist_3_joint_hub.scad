// concept part: wrist_3_joint_hub (joint_housing)
// units: mm. Mesh with: openscad -o wrist_3_joint_hub.stl wrist_3_joint_hub.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=22.656, center=true, $fn=48);
