// concept part: wrist_2 (wrist_2)
// units: mm. Mesh with: openscad -o wrist_2.stl wrist_2.scad
import("../stl/parts/wrist_2.stl");
