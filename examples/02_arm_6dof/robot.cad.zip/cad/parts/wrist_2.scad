// concept part: wrist_2 (wrist_2)
// units: mm. Mesh with: openscad -o wrist_2.stl wrist_2.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 34], [0, 0, 0, 1]])
  cylinder(h=27.2, r=16.32, center=true, $fn=48);
