// concept part: forearm_joint_hub (joint_housing)
// units: mm. Mesh with: openscad -o forearm_joint_hub.stl forearm_joint_hub.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=33.984, center=true, $fn=48);
