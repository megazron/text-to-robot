// concept part: base_link_standoff_fr (housing)
// units: mm. Mesh with: openscad -o base_link_standoff_fr.stl base_link_standoff_fr.scad
import("../stl/parts/base_link_standoff_fr.stl");
