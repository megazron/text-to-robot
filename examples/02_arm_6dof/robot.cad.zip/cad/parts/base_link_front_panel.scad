// concept part: base_link_front_panel (housing)
// units: mm. Mesh with: openscad -o base_link_front_panel.stl base_link_front_panel.scad
multmatrix([[1, 0, 0, 70.5], [0, 1, 0, 0], [0, 0, 1, 60], [0, 0, 0, 1]])
  cube([3, 144, 114], center=true);
