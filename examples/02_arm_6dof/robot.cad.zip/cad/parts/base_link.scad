// concept part: base_link (base)
// units: mm. Mesh with: openscad -o base_link.stl base_link.scad
import("../stl/parts/base_link.stl");
