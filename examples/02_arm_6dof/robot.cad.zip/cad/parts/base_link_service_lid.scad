// concept part: base_link_service_lid (housing)
// units: mm. Mesh with: openscad -o base_link_service_lid.stl base_link_service_lid.scad
import("../stl/parts/base_link_service_lid.stl");
