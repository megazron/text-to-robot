// concept part: forearm (forearm)
// units: mm. Mesh with: openscad -o forearm.stl forearm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 125], [0, 0, 0, 1]])
  cylinder(h=250, r=40, center=true, $fn=48);
