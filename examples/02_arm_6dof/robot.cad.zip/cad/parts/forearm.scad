// concept part: forearm (forearm)
// units: mm. Mesh with: openscad -o forearm.stl forearm.scad
import("../stl/parts/forearm.stl");
