// concept part: base_link_standoff_rr (housing)
// units: mm. Mesh with: openscad -o base_link_standoff_rr.stl base_link_standoff_rr.scad
import("../stl/parts/base_link_standoff_rr.stl");
