// concept part: base_link_left_panel (housing)
// units: mm. Mesh with: openscad -o base_link_left_panel.stl base_link_left_panel.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 70.5], [0, 0, 1, 60], [0, 0, 0, 1]])
  cube([138, 3, 114], center=true);
