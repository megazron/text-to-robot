// concept part: wrist_3 (wrist_3)
// units: mm. Mesh with: openscad -o wrist_3.stl wrist_3.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 40], [0, 0, 0, 1]])
  cylinder(h=32, r=19.2, center=true, $fn=48);
