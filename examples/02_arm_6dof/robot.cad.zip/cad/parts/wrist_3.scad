// concept part: wrist_3 (wrist_3)
// units: mm. Mesh with: openscad -o wrist_3.stl wrist_3.scad
import("../stl/parts/wrist_3.stl");
