// concept part: shoulder (shoulder)
// units: mm. Mesh with: openscad -o shoulder.stl shoulder.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 50], [0, 0, 0, 1]])
  cylinder(h=40, r=24, center=true, $fn=48);
