// concept part: shoulder (shoulder)
// units: mm. Mesh with: openscad -o shoulder.stl shoulder.scad
import("../stl/parts/shoulder.stl");
