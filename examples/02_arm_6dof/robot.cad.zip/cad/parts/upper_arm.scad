// concept part: upper_arm (upper_arm)
// units: mm. Mesh with: openscad -o upper_arm.stl upper_arm.scad
import("../stl/parts/upper_arm.stl");
