// concept part: base_link_standoff_rl (housing)
// units: mm. Mesh with: openscad -o base_link_standoff_rl.stl base_link_standoff_rl.scad
import("../stl/parts/base_link_standoff_rl.stl");
