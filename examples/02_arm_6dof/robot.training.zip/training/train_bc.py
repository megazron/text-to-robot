"""Behaviour cloning (imitation learning) from demos.npz using PyTorch.

    python collect_demos.py --episodes 50     # first, gather expert data
    python train_bc.py --epochs 50            # then clone it
"""
import argparse
import numpy as np
import torch
import torch.nn as nn


class Policy(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(obs_dim, 256), nn.ReLU(),
                                 nn.Linear(256, 256), nn.ReLU(), nn.Linear(256, act_dim))
    def forward(self, x): return self.net(x)


def main(epochs, lr):
    d = np.load("demos.npz")
    obs = torch.tensor(d["obs"], dtype=torch.float32)
    act = torch.tensor(d["act"], dtype=torch.float32)
    model = Policy(obs.shape[1], act.shape[1])
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    for e in range(epochs):
        opt.zero_grad()
        loss = loss_fn(model(obs), act)
        loss.backward(); opt.step()
        if e % 10 == 0: print(f"epoch {e}  loss {loss.item():.4f}")
    torch.save(model.state_dict(), "bc_arm_6dof.pt")
    print("saved bc_arm_6dof.pt")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--lr", type=float, default=1e-3)
    a = ap.parse_args(); main(a.epochs, a.lr)
