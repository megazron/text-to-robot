"""Task catalogue (auto-generated). Each task returns (reward, terminated)."""
import numpy as np
import pybullet as p

def reach(self, action):
    tip = self.p.getLinkState(self.robot, self.tip_index)[4]
    dist = float(np.linalg.norm(np.array(tip) - self.target))
    reward = -dist - 0.001 * float(np.square(action).sum())
    terminated = dist < 0.05
    return float(reward), bool(terminated)

def track(self, action):
    if self.steps % 100 == 0: self.target = self._reachable_target()
    tip = self.p.getLinkState(self.robot, self.tip_index)[4]
    dist = float(np.linalg.norm(np.array(tip) - self.target))
    reward = -dist
    terminated = False
    return float(reward), bool(terminated)

def hold(self, action):
    tip = self.p.getLinkState(self.robot, self.tip_index)[4]
    vel = np.array([self.p.getJointState(self.robot, j)[1] for j in self.joints])
    dist = float(np.linalg.norm(np.array(tip) - self.target))
    reward = -dist - 0.05 * float(np.linalg.norm(vel))
    terminated = dist < 0.04 and float(np.linalg.norm(vel)) < 0.1
    return float(reward), bool(terminated)

TASKS = {
    "reach": ("Reach a sampled collision-free target", reach),
    "track": ("Track a sequence of reachable targets", track),
    "hold": ("Reach and hold (settle) at the target", hold),
}
DEFAULT_TASK = "reach"
