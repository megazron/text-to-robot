# arm_6dof in MuJoCo

Test, render and train this exact robot in MuJoCo with the text-to-robot Python layer:

```bash
pip install -r requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cpu    # CPU torch on GPU-less machines

python -m ttr_mujoco.collision ../arm_6dof.urdf --out collision
python -m ttr_mujoco test   collision/robot.urdf --self-collision                       # settle / hold / actuator sweep / disturbance
python -m ttr_mujoco render collision/robot.urdf --self-collision -o arm_6dof.gif --motion sweep
python -m ttr_mujoco train  collision/robot.urdf --self-collision --task reach --tip-body gripper_base --steps 400000
```

Mesh-based exports first prepare approximate convex collision hulls. This preserves
hollow regions better than bounding boxes; inspect the generated collision report.
Simulation and training do not validate hardware fit or a learned policy.
For fixed-base position-servo arms, optional `--bias-compensation` on the train
command adds model-based gravity/Coriolis feedforward through the existing motors.
Effort limits remain active. This is not a measured hardware controller; it rejects
floating bases and velocity actuators. The Python equivalent is
`MujocoRobotEnv(..., bias_compensation=True)`.

Or from Python:

```python
from ttr_mujoco import urdf_to_mjcf, run_tests, render_gif
from ttr_mujoco.env import MujocoRobotEnv
report = run_tests(urdf_to_mjcf("collision/robot.urdf", self_collision=True))              # dict with per-test pass/fail + metrics
env = MujocoRobotEnv("collision/robot.urdf", self_collision=True, task="reach", tip_body="gripper_base")
```
