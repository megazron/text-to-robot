# Printability — humanoid_robot

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| torso | 160 × 280 × 3 | ❌ |
| torso_service_lid | 160 × 280 × 3 | ❌ |
| torso_rear_panel | 3 × 280 × 354 | ❌ |
| torso_right_panel | 154 × 3 × 354 | ❌ |
| torso_front_panel | 3 × 280 × 354 | ❌ |
| torso_left_panel | 154 × 3 × 354 | ❌ |
| torso_standoff_rr | 8 × 8 × 354 | ❌ |
| torso_standoff_rl | 8 × 8 × 354 | ❌ |
| torso_standoff_fr | 8 × 8 × 354 | ❌ |
| torso_standoff_fl | 8 × 8 × 354 | ❌ |
| head | 180 × 180 × 180 | ✅ |
| left_shoulder | 70 × 70 × 60 | ✅ |
| left_upper_arm | 70 × 70 × 220 | ✅ |
| left_elbow | 70 × 70 × 60 | ✅ |
| left_forearm | 70 × 70 × 220 | ✅ |
| left_wrist_1 | 70 × 70 × 60 | ✅ |
| left_wrist_2 | 70 × 70 × 60 | ✅ |
| left_wrist_3 | 70 × 70 × 60 | ✅ |
| left_gripper_base | 60 × 80 × 30 | ✅ |
| left_left_finger | 15 × 20 × 60 | ✅ |
| left_right_finger | 15 × 20 × 60 | ✅ |
| left_left_finger_pad | 15 × 2 × 36 | ✅ |
| left_right_finger_pad | 15 × 2 × 36 | ✅ |
| right_shoulder | 70 × 70 × 60 | ✅ |
| right_upper_arm | 70 × 70 × 220 | ✅ |
| right_elbow | 70 × 70 × 60 | ✅ |
| right_forearm | 70 × 70 × 220 | ✅ |
| right_wrist_1 | 70 × 70 × 60 | ✅ |
| right_wrist_2 | 70 × 70 × 60 | ✅ |
| right_wrist_3 | 70 × 70 × 60 | ✅ |
| right_gripper_base | 60 × 80 × 30 | ✅ |
| right_left_finger | 15 × 20 × 60 | ✅ |
| right_right_finger | 15 × 20 × 60 | ✅ |
| right_left_finger_pad | 15 × 2 × 36 | ✅ |
| right_right_finger_pad | 15 × 2 × 36 | ✅ |
| left_hip_yaw_carrier | 46 × 46 × 16 | ✅ |
| left_hip_roll_carrier | 40 × 40 × 18 | ✅ |
| left_thigh | 90 × 90 × 200 | ✅ |
| left_shin | 80 × 80 × 200 | ✅ |
| left_foot | 160 × 80 × 40 | ✅ |
| left_ankle_pitch_carrier | 30 × 30 × 22 | ✅ |
| right_hip_yaw_carrier | 46 × 46 × 16 | ✅ |
| right_hip_roll_carrier | 40 × 40 × 18 | ✅ |
| right_thigh | 90 × 90 × 200 | ✅ |
| right_shin | 80 × 80 × 200 | ✅ |
| right_foot | 160 × 80 × 40 | ✅ |
| right_ankle_pitch_carrier | 30 × 30 × 22 | ✅ |

## Notes
- ⚠️ **torso**: longest dimension 280 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_service_lid**: longest dimension 280 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_rear_panel**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_right_panel**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_front_panel**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_left_panel**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_rr**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_rl**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_fr**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_fl**: longest dimension 354 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **head**: sphere needs supports or a flat-cut base to print
- ⚠️ **left_left_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **left_right_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_left_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_right_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
