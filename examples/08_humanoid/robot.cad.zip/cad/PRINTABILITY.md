# Printability — humanoid_robot

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| torso | 120 × 210 × 2.3 | ✅ |
| torso_service_lid | 120 × 210 × 2.3 | ✅ |
| torso_rear_panel | 2.3 × 210 × 265.5 | ❌ |
| torso_right_panel | 115.5 × 2.3 × 265.5 | ❌ |
| torso_front_panel | 2.3 × 210 × 265.5 | ❌ |
| torso_left_panel | 115.5 × 2.3 × 265.5 | ❌ |
| torso_standoff_rr | 6 × 6 × 265.5 | ❌ |
| torso_standoff_rl | 6 × 6 × 265.5 | ❌ |
| torso_standoff_fr | 6 × 6 × 265.5 | ❌ |
| torso_standoff_fl | 6 × 6 × 265.5 | ❌ |
| head | 135 × 135 × 135 | ✅ |
| left_shoulder | 52.5 × 52.5 × 33.8 | ✅ |
| left_upper_arm | 52.5 × 52.5 × 103.1 | ✅ |
| left_elbow | 52.5 × 52.5 × 33.8 | ✅ |
| left_forearm | 52.5 × 52.5 × 103.1 | ✅ |
| left_wrist_1 | 52.5 × 52.5 × 33.8 | ✅ |
| left_wrist_2 | 52.5 × 52.5 × 33.8 | ✅ |
| left_wrist_3 | 52.5 × 52.5 × 33.8 | ✅ |
| left_gripper_base | 45 × 60 × 22.5 | ✅ |
| left_left_finger | 11.3 × 15 × 45 | ✅ |
| left_right_finger | 11.3 × 15 × 45 | ✅ |
| left_left_finger_pad | 11.3 × 1.5 × 27 | ✅ |
| left_right_finger_pad | 11.3 × 1.5 × 27 | ✅ |
| right_shoulder | 52.5 × 52.5 × 33.8 | ✅ |
| right_upper_arm | 52.5 × 52.5 × 103.1 | ✅ |
| right_elbow | 52.5 × 52.5 × 33.8 | ✅ |
| right_forearm | 52.5 × 52.5 × 103.1 | ✅ |
| right_wrist_1 | 52.5 × 52.5 × 33.8 | ✅ |
| right_wrist_2 | 52.5 × 52.5 × 33.8 | ✅ |
| right_wrist_3 | 52.5 × 52.5 × 33.8 | ✅ |
| right_gripper_base | 45 × 60 × 22.5 | ✅ |
| right_left_finger | 11.3 × 15 × 45 | ✅ |
| right_right_finger | 11.3 × 15 × 45 | ✅ |
| right_left_finger_pad | 11.3 × 1.5 × 27 | ✅ |
| right_right_finger_pad | 11.3 × 1.5 × 27 | ✅ |
| left_hip_yaw_carrier | 34.5 × 34.5 × 12 | ✅ |
| left_hip_roll_carrier | 30 × 30 × 13.5 | ✅ |
| left_thigh | 67.5 × 67.5 × 147.8 | ✅ |
| left_shin | 60 × 60 × 147.8 | ✅ |
| left_foot | 120 × 60 × 30 | ✅ |
| left_ankle_pitch_carrier | 22.5 × 22.5 × 16.5 | ✅ |
| right_hip_yaw_carrier | 34.5 × 34.5 × 12 | ✅ |
| right_hip_roll_carrier | 30 × 30 × 13.5 | ✅ |
| right_thigh | 67.5 × 67.5 × 147.8 | ✅ |
| right_shin | 60 × 60 × 147.8 | ✅ |
| right_foot | 120 × 60 × 30 | ✅ |
| right_ankle_pitch_carrier | 22.5 × 22.5 × 16.5 | ✅ |

## Notes
- ⚠️ **torso**: thinnest dimension 2.3 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **torso_service_lid**: thinnest dimension 2.3 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **torso_rear_panel**: longest dimension 265.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_rear_panel**: thinnest dimension 2.3 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **torso_right_panel**: longest dimension 265.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_right_panel**: thinnest dimension 2.3 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **torso_front_panel**: longest dimension 265.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_front_panel**: thinnest dimension 2.3 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **torso_left_panel**: longest dimension 265.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_left_panel**: thinnest dimension 2.3 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **torso_standoff_rr**: longest dimension 265.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_rl**: longest dimension 265.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_fr**: longest dimension 265.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **torso_standoff_fl**: longest dimension 265.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **head**: sphere needs supports or a flat-cut base to print
- ⚠️ **left_left_finger_pad**: thinnest dimension 1.5 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **left_right_finger_pad**: thinnest dimension 1.5 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_left_finger_pad**: thinnest dimension 1.5 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_right_finger_pad**: thinnest dimension 1.5 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
