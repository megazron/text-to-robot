# Printability — humanoid_robot

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| torso | 160 × 280 × 360 | ❌ |
| head | 180 × 180 × 180 | ✅ |
| left_shoulder | 70 × 70 × 60 | ✅ |
| left_upper_arm | 70 × 70 × 220 | ✅ |
| left_elbow | 70 × 70 × 60 | ✅ |
| left_forearm | 70 × 70 × 220 | ✅ |
| left_wrist_1 | 70 × 70 × 60 | ✅ |
| left_wrist_2 | 70 × 70 × 60 | ✅ |
| left_wrist_3 | 70 × 70 × 60 | ✅ |
| left_gripper_base | 60 × 80 × 30 | ✅ |
| left_left_finger | 15 × 20 × 60 | ✅ |
| left_right_finger | 15 × 20 × 60 | ✅ |
| right_shoulder | 70 × 70 × 60 | ✅ |
| right_upper_arm | 70 × 70 × 220 | ✅ |
| right_elbow | 70 × 70 × 60 | ✅ |
| right_forearm | 70 × 70 × 220 | ✅ |
| right_wrist_1 | 70 × 70 × 60 | ✅ |
| right_wrist_2 | 70 × 70 × 60 | ✅ |
| right_wrist_3 | 70 × 70 × 60 | ✅ |
| right_gripper_base | 60 × 80 × 30 | ✅ |
| right_left_finger | 15 × 20 × 60 | ✅ |
| right_right_finger | 15 × 20 × 60 | ✅ |
| left_thigh | 90 × 90 × 200 | ✅ |
| left_shin | 80 × 80 × 200 | ✅ |
| left_foot | 160 × 80 × 40 | ✅ |
| right_thigh | 90 × 90 × 200 | ✅ |
| right_shin | 80 × 80 × 200 | ✅ |
| right_foot | 160 × 80 × 40 | ✅ |

## Notes
- ⚠️ **torso**: longest dimension 360 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **head**: sphere needs supports or a flat-cut base to print
