# Assembly: humanoid_robot

Start from **base_link**.

1. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **base_link** with its case screws.
2. Bolt **torso** to **base_link**.
3. Mount the **LiPo 3S 5000 mAh 60C, XT60 (Gens Ace G-Tech)** (battery) in **torso** with its case screws.
4. Mount the **Raspberry Pi 5 (4 GB)** (computer) in **torso** with its case screws.
5. Mount the **Waveshare Bus Servo Adapter (A)** (leg_bus) in **torso** with its case screws.
6. Mount the **ROBOTIS U2D2 USB to TTL/RS-485 interface** (arm_bus) in **torso** with its case screws.
7. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **torso** with its case screws.
8. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v_arms) in **torso** with its case screws.
9. Mount the **DYNAMIXEL XL430-W250-T** (l_shoulder_pitch_actuator) in **torso** with its case screws.
10. Set joint `l_shoulder_pitch` to zero (centre the servo first), then screw **l_shoulder_pitch_link** to the actuator output in **torso**; it moves -172° … 172°.
11. Mount the **DYNAMIXEL XL430-W250-T** (l_shoulder_roll_actuator) in **l_shoulder_pitch_link** with its case screws.
12. Set joint `l_shoulder_roll` to zero (centre the servo first), then screw **l_shoulder_roll_link** to the actuator output in **l_shoulder_pitch_link**; it moves -8° … 92°.
13. Mount the **DYNAMIXEL XL430-W250-T** (l_upper_arm_yaw_actuator) in **l_shoulder_roll_link** with its case screws.
14. Set joint `l_upper_arm_yaw` to zero (centre the servo first), then screw **l_upper_arm_yaw_link** to the actuator output in **l_shoulder_roll_link**; it moves -115° … 115°.
15. Mount the **DYNAMIXEL XL330-M288-T** (l_elbow_actuator) in **l_upper_arm_yaw_link** with its case screws.
16. Set joint `l_elbow` to zero (centre the servo first), then screw **l_elbow_link** to the actuator output in **l_upper_arm_yaw_link**; it moves -132° … 132°.
17. Mount the **DYNAMIXEL XL330-M288-T** (l_gripper_actuator) in **l_elbow_link** with its case screws.
18. Set joint `l_gripper` to zero (centre the servo first), then screw **l_gripper_jaw** to the actuator output in **l_elbow_link**; it moves -20° … 31°.
19. Mount the **DYNAMIXEL XL430-W250-T** (r_shoulder_pitch_actuator) in **torso** with its case screws.
20. Set joint `r_shoulder_pitch` to zero (centre the servo first), then screw **r_shoulder_pitch_link** to the actuator output in **torso**; it moves -172° … 172°.
21. Mount the **DYNAMIXEL XL430-W250-T** (r_shoulder_roll_actuator) in **r_shoulder_pitch_link** with its case screws.
22. Set joint `r_shoulder_roll` to zero (centre the servo first), then screw **r_shoulder_roll_link** to the actuator output in **r_shoulder_pitch_link**; it moves -92° … 8°.
23. Mount the **DYNAMIXEL XL430-W250-T** (r_upper_arm_yaw_actuator) in **r_shoulder_roll_link** with its case screws.
24. Set joint `r_upper_arm_yaw` to zero (centre the servo first), then screw **r_upper_arm_yaw_link** to the actuator output in **r_shoulder_roll_link**; it moves -115° … 115°.
25. Mount the **DYNAMIXEL XL330-M288-T** (r_elbow_actuator) in **r_upper_arm_yaw_link** with its case screws.
26. Set joint `r_elbow` to zero (centre the servo first), then screw **r_elbow_link** to the actuator output in **r_upper_arm_yaw_link**; it moves -132° … 132°.
27. Mount the **DYNAMIXEL XL330-M288-T** (r_gripper_actuator) in **r_elbow_link** with its case screws.
28. Set joint `r_gripper` to zero (centre the servo first), then screw **r_gripper_jaw** to the actuator output in **r_elbow_link**; it moves -20° … 31°.
29. Mount the **DYNAMIXEL XL330-M288-T** (neck_pan_actuator) in **torso** with its case screws.
30. Set joint `neck_pan` to zero (centre the servo first), then screw **neck_pan_link** to the actuator output in **torso**; it moves -92° … 92°.
31. Mount the **DYNAMIXEL XL330-M288-T** (neck_tilt_actuator) in **neck_pan_link** with its case screws.
32. Set joint `neck_tilt` to zero (centre the servo first), then screw **neck_tilt_link** to the actuator output in **neck_pan_link**; it moves -40° … 22°.
33. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (head_camera) in **neck_tilt_link** with its case screws.
34. Bolt **side_panel_left** to **torso**.
35. Bolt **side_panel_right** to **torso**.
36. Bolt **chest_panel** to **torso**.
37. Mount the **KCD4 double-pole rocker switch, 16 A 250 VAC / 20 A 125 VAC** (main_switch) in **chest_panel** with its case screws.
38. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (l_hip_yaw_actuator) in **base_link** with its case screws.
39. Set joint `l_hip_yaw` to zero (centre the servo first), then screw **l_hip_yaw_link** to the actuator output in **base_link**; it moves -34° … 34°.
40. Mount the **DYNAMIXEL XH540-W270-T(R)** (l_hip_roll_actuator) in **l_hip_yaw_link** with its case screws.
41. Set joint `l_hip_roll` to zero (centre the servo first), then screw **l_hip_roll_link** to the actuator output in **l_hip_yaw_link**; it moves -7° … 26°.
42. Mount the **DYNAMIXEL XH540-W270-T(R)** (l_hip_pitch_actuator) in **l_hip_roll_link** with its case screws.
43. Set joint `l_hip_pitch` to zero (centre the servo first), then screw **l_hip_pitch_link** to the actuator output in **l_hip_roll_link**; it moves -92° … 92°.
44. Mount the **DYNAMIXEL XH540-W270-T(R)** (l_knee_actuator) in **l_hip_pitch_link** with its case screws.
45. Set joint `l_knee` to zero (centre the servo first), then screw **l_knee_link** to the actuator output in **l_hip_pitch_link**; it moves -117° … 126°.
46. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (l_ankle_pitch_actuator) in **l_knee_link** with its case screws.
47. Set joint `l_ankle_pitch` to zero (centre the servo first), then screw **l_ankle_pitch_link** to the actuator output in **l_knee_link**; it moves -69° … 69°.
48. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (l_ankle_roll_actuator) in **l_ankle_pitch_link** with its case screws.
49. Set joint `l_ankle_roll` to zero (centre the servo first), then screw **l_ankle_roll_link** to the actuator output in **l_ankle_pitch_link**; it moves -29° … 7°.
50. Bolt **l_sole_pad** to **l_ankle_roll_link**.
51. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (r_hip_yaw_actuator) in **base_link** with its case screws.
52. Set joint `r_hip_yaw` to zero (centre the servo first), then screw **r_hip_yaw_link** to the actuator output in **base_link**; it moves -34° … 34°.
53. Mount the **DYNAMIXEL XH540-W270-T(R)** (r_hip_roll_actuator) in **r_hip_yaw_link** with its case screws.
54. Set joint `r_hip_roll` to zero (centre the servo first), then screw **r_hip_roll_link** to the actuator output in **r_hip_yaw_link**; it moves -26° … 7°.
55. Mount the **DYNAMIXEL XH540-W270-T(R)** (r_hip_pitch_actuator) in **r_hip_roll_link** with its case screws.
56. Set joint `r_hip_pitch` to zero (centre the servo first), then screw **r_hip_pitch_link** to the actuator output in **r_hip_roll_link**; it moves -92° … 92°.
57. Mount the **DYNAMIXEL XH540-W270-T(R)** (r_knee_actuator) in **r_hip_pitch_link** with its case screws.
58. Set joint `r_knee` to zero (centre the servo first), then screw **r_knee_link** to the actuator output in **r_hip_pitch_link**; it moves -126° … 117°.
59. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (r_ankle_pitch_actuator) in **r_knee_link** with its case screws.
60. Set joint `r_ankle_pitch` to zero (centre the servo first), then screw **r_ankle_pitch_link** to the actuator output in **r_knee_link**; it moves -69° … 69°.
61. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (r_ankle_roll_actuator) in **r_ankle_pitch_link** with its case screws.
62. Set joint `r_ankle_roll` to zero (centre the servo first), then screw **r_ankle_roll_link** to the actuator output in **r_ankle_pitch_link**; it moves -7° … 29°.
63. Bolt **r_sole_pad** to **r_ankle_roll_link**.
64. Bolt **imu_hood** to **base_link**.

## Fasteners

- 4 × M3 x 12 torso-to-pelvis bolts
- 88 × M2/M2.5 x 6 case screws
- 88 × horn / hub screws
- 4 × M3 x 8 self-tapping (side_panel_left)
- 4 × M3 x 8 self-tapping (side_panel_right)
- 4 × M3 x 8 self-tapping (chest_panel)
- 4 × M3 x 12 self-tapping (hood to deck)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
