// concept part: left_upper_arm (upper_arm)
// units: mm. Mesh with: openscad -o left_upper_arm.stl left_upper_arm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -90], [0, 0, 0, 1]])
  cylinder(h=180, r=35, center=true, $fn=48);
