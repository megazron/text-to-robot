// concept part: right_right_finger (gripper)
// units: mm. Mesh with: openscad -o right_right_finger.stl right_right_finger.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 22.5], [0, 0, 0, 1]])
  cube([11.25, 15, 45], center=true);
