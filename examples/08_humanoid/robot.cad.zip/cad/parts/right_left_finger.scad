// concept part: right_left_finger (gripper)
// units: mm. Mesh with: openscad -o right_left_finger.stl right_left_finger.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 22.5], [0, 0, 0, 1]])
  cube([11.25, 15, 45], center=true);
