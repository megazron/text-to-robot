// concept part: right_elbow (elbow)
// units: mm. Mesh with: openscad -o right_elbow.stl right_elbow.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -16.875], [0, 0, 0, 1]])
  cylinder(h=33.75, r=26.25, center=true, $fn=48);
