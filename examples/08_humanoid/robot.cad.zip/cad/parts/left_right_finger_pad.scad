// concept part: left_right_finger_pad (contact_pad)
// units: mm. Mesh with: openscad -o left_right_finger_pad.stl left_right_finger_pad.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 11], [0, 0, 1, 39], [0, 0, 0, 1]])
  cube([15, 2, 36], center=true);
