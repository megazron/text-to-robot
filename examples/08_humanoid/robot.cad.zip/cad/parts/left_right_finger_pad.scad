// concept part: left_right_finger_pad (contact_pad)
// units: mm. Mesh with: openscad -o left_right_finger_pad.stl left_right_finger_pad.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 8.25], [0, 0, 1, 29.25], [0, 0, 0, 1]])
  cube([11.25, 1.5, 27], center=true);
