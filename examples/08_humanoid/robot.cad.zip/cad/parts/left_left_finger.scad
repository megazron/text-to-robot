// concept part: left_left_finger (gripper)
// units: mm. Mesh with: openscad -o left_left_finger.stl left_left_finger.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 22.5], [0, 0, 0, 1]])
  cube([11.25, 15, 45], center=true);
