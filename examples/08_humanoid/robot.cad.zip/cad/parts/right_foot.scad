// concept part: right_foot (link)
// units: mm. Mesh with: openscad -o right_foot.stl right_foot.scad
multmatrix([[1, 0, 0, 22.5], [0, 1, 0, 0], [0, 0, 1, -15], [0, 0, 0, 1]])
  cube([120, 60, 30], center=true);
