// concept part: right_forearm (forearm)
// units: mm. Mesh with: openscad -o right_forearm.stl right_forearm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -110], [0, 0, 0, 1]])
  cylinder(h=220, r=35, center=true, $fn=48);
