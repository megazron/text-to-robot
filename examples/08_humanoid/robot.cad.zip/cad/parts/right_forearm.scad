// concept part: right_forearm (forearm)
// units: mm. Mesh with: openscad -o right_forearm.stl right_forearm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -51.5625], [0, 0, 0, 1]])
  cylinder(h=103.125, r=26.25, center=true, $fn=48);
