// concept part: left_right_finger (gripper)
// units: mm. Mesh with: openscad -o left_right_finger.stl left_right_finger.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 30], [0, 0, 0, 1]])
  cube([15, 20, 60], center=true);
