// concept part: left_thigh (link)
// units: mm. Mesh with: openscad -o left_thigh.stl left_thigh.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -101.5], [0, 0, 0, 1]])
  cylinder(h=197, r=45, center=true, $fn=48);
