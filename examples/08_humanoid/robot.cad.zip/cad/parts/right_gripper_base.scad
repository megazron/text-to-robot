// concept part: right_gripper_base (gripper)
// units: mm. Mesh with: openscad -o right_gripper_base.stl right_gripper_base.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 15], [0, 0, 0, 1]])
  cube([60, 80, 30], center=true);
