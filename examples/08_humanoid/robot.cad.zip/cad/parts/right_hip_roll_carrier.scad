// concept part: right_hip_roll_carrier (joint_housing)
// units: mm. Mesh with: openscad -o right_hip_roll_carrier.stl right_hip_roll_carrier.scad
multmatrix([[0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=13.5, r=15, center=true, $fn=48);
