// concept part: torso (base)
// units: mm. Mesh with: openscad -o torso.stl torso.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 620], [0, 0, 0, 1]])
  cube([160, 280, 360], center=true);
