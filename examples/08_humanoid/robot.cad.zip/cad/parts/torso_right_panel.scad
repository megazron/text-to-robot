// concept part: torso_right_panel (housing)
// units: mm. Mesh with: openscad -o torso_right_panel.stl torso_right_panel.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, -103.875], [0, 0, 1, 465], [0, 0, 0, 1]])
  cube([115.5, 2.25, 265.5], center=true);
