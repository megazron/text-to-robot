// concept part: right_wrist_3 (wrist_3)
// units: mm. Mesh with: openscad -o right_wrist_3.stl right_wrist_3.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -16.875], [0, 0, 0, 1]])
  cylinder(h=33.75, r=26.25, center=true, $fn=48);
