// concept part: left_foot (link)
// units: mm. Mesh with: openscad -o left_foot.stl left_foot.scad
multmatrix([[1, 0, 0, 22.5], [0, 1, 0, 0], [0, 0, 1, -15], [0, 0, 0, 1]])
  cube([120, 60, 30], center=true);
