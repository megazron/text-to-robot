// concept part: right_ankle_pitch_carrier (joint_housing)
// units: mm. Mesh with: openscad -o right_ankle_pitch_carrier.stl right_ankle_pitch_carrier.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=16.5, r=11.25, center=true, $fn=48);
