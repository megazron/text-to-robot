// concept part: left_gripper_base (gripper)
// units: mm. Mesh with: openscad -o left_gripper_base.stl left_gripper_base.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 11.25], [0, 0, 0, 1]])
  cube([45, 60, 22.5], center=true);
