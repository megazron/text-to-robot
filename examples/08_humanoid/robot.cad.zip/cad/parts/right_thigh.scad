// concept part: right_thigh (link)
// units: mm. Mesh with: openscad -o right_thigh.stl right_thigh.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -76.125], [0, 0, 0, 1]])
  cylinder(h=147.75, r=33.75, center=true, $fn=48);
