// concept part: torso_front_panel (housing)
// units: mm. Mesh with: openscad -o torso_front_panel.stl torso_front_panel.scad
multmatrix([[1, 0, 0, 58.875], [0, 1, 0, 0], [0, 0, 1, 465], [0, 0, 0, 1]])
  cube([2.25, 210, 265.5], center=true);
