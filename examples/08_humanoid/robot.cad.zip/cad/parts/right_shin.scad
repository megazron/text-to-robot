// concept part: right_shin (link)
// units: mm. Mesh with: openscad -o right_shin.stl right_shin.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -100], [0, 0, 0, 1]])
  cylinder(h=200, r=40, center=true, $fn=48);
