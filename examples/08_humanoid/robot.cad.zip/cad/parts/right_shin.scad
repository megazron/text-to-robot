// concept part: right_shin (link)
// units: mm. Mesh with: openscad -o right_shin.stl right_shin.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -73.875], [0, 0, 0, 1]])
  cylinder(h=147.75, r=30, center=true, $fn=48);
