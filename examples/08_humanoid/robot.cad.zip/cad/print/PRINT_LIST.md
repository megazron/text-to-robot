# Print list: humanoid_robot

30 parts, about 1353 g of PETG and 123.4 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 67.5 × 152.8 × 44.6 | 83 | 7.6 | yes |
| torso | 100 × 180 × 155.5 | 372 | 33.9 | yes |
| l_hip_yaw_link | 49 × 39.5 × 70.5 | 31 | 2.8 | yes |
| l_hip_roll_link | 140.2 × 50.6 × 49.2 | 45 | 4.1 | yes |
| l_hip_pitch_link | 159.2 × 55.4 × 50 | 43 | 3.9 | yes |
| l_knee_link | 146.8 × 38.4 × 45 | 35 | 3.2 | yes |
| l_ankle_pitch_link | 108.8 × 40.7 × 38.4 | 37 | 3.3 | yes |
| l_ankle_roll_link | 60.3 × 62 × 120 | 32 | 2.9 | yes |
| r_hip_yaw_link | 49 × 39.5 × 70.5 | 31 | 2.8 | yes |
| r_hip_roll_link | 140.2 × 50.6 × 49.2 | 46 | 4.1 | yes |
| r_hip_pitch_link | 159.2 × 55.4 × 50 | 43 | 3.9 | yes |
| r_knee_link | 146.8 × 38.4 × 45 | 35 | 3.2 | yes |
| r_ankle_pitch_link | 108.8 × 40.7 × 38.4 | 36 | 3.3 | yes |
| r_ankle_roll_link | 60.3 × 62 × 120 | 32 | 2.9 | yes |
| l_shoulder_pitch_link | 53.5 × 38.9 × 56.2 | 33 | 3.0 | yes |
| l_shoulder_roll_link | 98.1 × 36.3 × 62.2 | 35 | 3.2 | yes |
| l_upper_arm_yaw_link | 28.5 × 30.3 × 46 | 10 | 0.9 | yes |
| l_elbow_link | 38 × 37.5 × 94.5 | 19 | 1.8 | yes |
| l_gripper_jaw | 73 × 39 × 8.5 | 10 | 0.9 | yes |
| r_shoulder_pitch_link | 53.5 × 38.9 × 56.2 | 34 | 3.1 | yes |
| r_shoulder_roll_link | 98.1 × 36.3 × 62.2 | 35 | 3.2 | yes |
| r_upper_arm_yaw_link | 28.5 × 30.3 × 46 | 10 | 0.9 | yes |
| r_elbow_link | 38 × 37.5 × 94.5 | 19 | 1.8 | yes |
| r_gripper_jaw | 73 × 39 × 8.5 | 10 | 0.9 | yes |
| neck_pan_link | 26 × 28 × 86.5 | 23 | 2.1 | yes |
| neck_tilt_link | 79.4 × 97.4 × 81 | 179 | 16.3 | yes |
| side_panel_left | 94 × 2.4 × 40.9 | 7 | 0.6 | yes |
| side_panel_right | 94 × 2.4 × 40.9 | 7 | 0.6 | yes |
| chest_panel | 2.4 × 158 × 45.3 | 11 | 1.0 | yes |
| imu_hood | 44 × 42.4 × 35.8 | 12 | 1.1 | yes |
