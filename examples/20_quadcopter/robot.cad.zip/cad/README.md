# Build package: quadcopter

Quadcopter, 5 in props on 2207 motors: 0.47 kg take-off, thrust-to-weight 6.6, hover at 15 % throttle, about 10 min

1. **Buy** everything in `BOM.md` (supplier links included).
2. **Print** every STL in `print/` (see `print/PRINT_LIST.md`).
3. **Assemble** in the order of `ASSEMBLY.md`.
   **Wire** from `WIRING.md` (pin-to-pin table, cut list, power budget, battery runtime, regulator heat, logic levels), `schematic.svg` / `schematic.pdf` the picture view `breadboard.svg` and the harness in 3D `electronics.glb`.
4. **Check** against `design.json`: each actuator's required vs rated torque, the speed it reaches loaded, battery runtime, stability and every other check the design passed.

`reference/` holds the bought parts' models (from their datasheet drawings) for your own CAD; `quadcopter_assembly.stl` is the whole robot in its build pose.

## Assumptions

- Thrust and current come from a typical 2207 1750 KV static thrust table with 5 x 4.3 x 3 props on a full 4S pack (estimated; real motors vary by about 10 %). Thrust falls as the pack sags and in forward flight.
- The frame is printed flat in PETG (or better, CF-nylon). It is stiff enough for gentle flying; it does not survive crashes like a carbon frame. Balance the props.
- The flight controller runs Betaflight, INAV or ArduPilot: it does the stabilisation. Configure motor order, direction (props in), failsafe and the 60 A current limit before the first flight, without props.
- Fly where it is legal: in most countries a drone over 250 g must be registered and flown within sight, away from people.
