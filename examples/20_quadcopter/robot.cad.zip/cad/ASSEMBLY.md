# Assembly: quadcopter

Start from **base_link**.

1. Mount the **2207 brushless motor 1750 KV for 5 in props, 4S (e.g. iFlight XING2 2207)** (front_left_motor) in **base_link** with its case screws.
2. Fit **front_left_prop** on the output of the motor in **base_link** (driven joint `front_left_rotor`).
3. Mount the **2207 brushless motor 1750 KV for 5 in props, 4S (e.g. iFlight XING2 2207)** (rear_left_motor) in **base_link** with its case screws.
4. Fit **rear_left_prop** on the output of the motor in **base_link** (driven joint `rear_left_rotor`).
5. Mount the **2207 brushless motor 1750 KV for 5 in props, 4S (e.g. iFlight XING2 2207)** (rear_right_motor) in **base_link** with its case screws.
6. Fit **rear_right_prop** on the output of the motor in **base_link** (driven joint `rear_right_rotor`).
7. Mount the **2207 brushless motor 1750 KV for 5 in props, 4S (e.g. iFlight XING2 2207)** (front_right_motor) in **base_link** with its case screws.
8. Fit **front_right_prop** on the output of the motor in **base_link** (driven joint `front_right_rotor`).
9. Bolt **canopy** to **base_link**.
10. Bolt **canopy_lid** to **canopy**.
11. Mount the **LiPo 4S 1500 mAh 100C, XT60 (e.g. CNHL Black Series)** (battery) in **canopy_lid** with its case screws.
12. Mount the **4-in-1 BLHeli_S ESC 45 A per motor, 3-6S, 30.5 mm mount (e.g. SpeedyBee BLS 50A)** (esc) in **canopy** with its case screws.
13. Mount the **F405 flight controller, BMI270 IMU, OSD, barometer, 30.5 mm mount (e.g. SpeedyBee F405 V4)** (controller) in **canopy** with its case screws.
14. Mount the **ExpressLRS 2.4 GHz nano receiver with T antenna (e.g. RadioMaster RP1)** (receiver) in **canopy** with its case screws.
15. Bolt **camera_cradle** to **base_link**.
16. Mount the **Micro analog FPV camera, 19 mm, 1/1.8 in sensor (e.g. Caddx Ratel 2)** (fpv_camera) in **camera_cradle** with its case screws.

## Fasteners

- 16 × M3 x 8 socket head (motor to arm, from below)
- 4 × M5 nyloc prop nut
- 4 × M3 x 10 self-tapping (lid to compartment)
- 4 × M3 x 25 socket head + 8 mm nylon spacers (flight-controller stack)
- 2 × M3 x 10 + nut (camera cradle)
- 2 × M2 x 4 (camera side screws)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
