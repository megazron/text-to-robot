# Print list: quadcopter

4 parts, about 96 g of PETG and 8.8 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 191.1 × 191.1 × 7.8 | 65 | 6.0 | yes |
| canopy | 70.5 × 70.5 × 30 | 17 | 1.6 | yes |
| canopy_lid | 70.5 × 70.5 × 5.8 | 11 | 1.0 | yes |
| camera_cradle | 17 × 28 × 26 | 3 | 0.2 | yes |
