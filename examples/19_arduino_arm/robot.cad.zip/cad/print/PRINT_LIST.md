# Print list: arduino_arm

9 parts, about 377 g of PETG and 34.4 h of printing.

Exact solids of these parts are in `cad/step/` (STEP AP214, millimetres): open them in Fusion, FreeCAD or Onshape to edit.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 188.8 × 116 × 39.7 | 109 | 9.9 | yes |
| turntable | 43 × 54.1 × 65.5 | 30 | 2.7 | yes |
| upper_arm | 180.9 × 43.5 × 46.9 | 34 | 3.1 | yes |
| forearm | 193.8 × 50.3 × 37.5 | 25 | 2.3 | yes |
| claw_jaw | 70.5 × 42 × 4.6 | 5 | 0.5 | yes |
| console | 101.7 × 105.7 × 32.4 | 50 | 4.5 | yes |
| console_lid | 101.7 × 105.7 × 5.8 | 23 | 2.1 | yes |
| supply_case | 151.7 × 103.7 × 44.4 | 73 | 6.7 | yes |
| supply_case_lid | 151.7 × 103.7 × 5.8 | 29 | 2.7 | yes |
