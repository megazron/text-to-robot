# Print list — arduino_arm

5 parts, about 142 g of PETG and 13.0 h of printing.

Exact solids of these parts are in `cad/step/` (STEP AP214, millimetres): open them in Fusion, FreeCAD or Onshape to edit.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 110 × 90 × 30.7 | 49 | 4.5 | yes |
| turntable | 43 × 54.1 × 65.5 | 30 | 2.7 | yes |
| upper_arm | 180.9 × 43.5 × 46.9 | 34 | 3.1 | yes |
| forearm | 193.8 × 50.3 × 37.5 | 25 | 2.2 | yes |
| claw_jaw | 70.5 × 42 × 4.6 | 5 | 0.5 | yes |
