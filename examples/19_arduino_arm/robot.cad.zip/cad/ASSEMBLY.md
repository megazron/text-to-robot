# Assembly — arduino_arm

Start from **base_link**.

1. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (yaw_servo) in **base_link** with its case screws.
2. Set joint `yaw` to zero (centre the servo first), then screw **turntable** to the actuator output in **base_link**; it moves -90° … 90°.
3. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (shoulder_servo) in **turntable** with its case screws.
4. Set joint `shoulder` to zero (centre the servo first), then screw **upper_arm** to the actuator output in **turntable**; it moves -90° … 90°.
5. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (elbow_servo) in **upper_arm** with its case screws.
6. Set joint `elbow` to zero (centre the servo first), then screw **forearm** to the actuator output in **upper_arm**; it moves -120° … 120°.
7. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (claw_servo) in **forearm** with its case screws.
8. Set joint `claw` to zero (centre the servo first), then screw **claw_jaw** to the actuator output in **forearm**; it moves -34° … 20°.

## Fasteners

- 8 × M2 self-tapping (servo tabs, from the servo kits)
- 4 × M4 screws or desk clamps (base)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
