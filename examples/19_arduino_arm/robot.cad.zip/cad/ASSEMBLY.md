# Assembly — arduino_arm

Start from **base_link**.

1. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (yaw_servo) in **base_link** with its case screws.
2. Set joint `yaw` to zero (centre the servo first), then screw **turntable** to the actuator output in **base_link**; it moves -90° … 90°.
3. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (shoulder_servo) in **turntable** with its case screws.
4. Set joint `shoulder` to zero (centre the servo first), then screw **upper_arm** to the actuator output in **turntable**; it moves -90° … 90°.
5. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (elbow_servo) in **upper_arm** with its case screws.
6. Set joint `elbow` to zero (centre the servo first), then screw **forearm** to the actuator output in **upper_arm**; it moves -120° … 120°.
7. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (claw_servo) in **forearm** with its case screws.
8. Set joint `claw` to zero (centre the servo first), then screw **claw_jaw** to the actuator output in **forearm**; it moves 0° … 17°.
9. Bolt **console** to **base_link**.
10. Bolt **console_lid** to **console**.
11. Mount the **Arduino Uno R3 compatible board (ATmega328P, CH340 USB)** (controller) in **console** with its case screws.
12. Mount the **PCA9685 16-channel PWM servo driver board (generic, I2C)** (servo_driver) in **console** with its case screws.
13. Mount the **KCD1 rocker switch, SPST, 6 A 250 VAC / 10 A 125 VAC** (main_switch) in **console** with its case screws.
14. Bolt **supply_case** to **base_link**.
15. Bolt **supply_case_lid** to **supply_case**.
16. Mount the **Mean Well LRS-50-5 enclosed PSU, 5 V 10 A (50 W)** (power_supply) in **supply_case** with its case screws.
17. Mount the **IEC C14 panel inlet with fuse drawer and rocker switch, 10 A** (mains_inlet) in **supply_case** with its case screws.

## Fasteners

- 8 × M3 x 10 self-tapping (lid to compartment)
- 4 × M3 x 12 self-tapping (compartment to its base, from below)
- 4 × M3 x 6 self-tapping (Arduino Uno R3 compatible board to standoffs)
- 4 × M2.5 x 6 self-tapping (PCA9685 16-channel PWM servo driver board to standoffs)
- 2 × M3 x 6 self-tapping (Mean Well LRS-50-5 enclosed PSU, 5 V 10 A to standoffs)
- 8 × M2 self-tapping (servo tabs, from the servo kits)
- 4 × M4 screws or desk clamps (base)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
