cmake_minimum_required(VERSION 3.8)
project(scara)

find_package(ament_cmake REQUIRED)

install(
  DIRECTORY urdf launch config rviz meshes
  DESTINATION share/${PROJECT_NAME}
)
foreach(optional_dir moveit worlds motions)
  if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/${optional_dir}")
    install(DIRECTORY ${optional_dir} DESTINATION share/${PROJECT_NAME})
  endif()
endforeach()
if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/scripts/replay_motion.py")
  install(PROGRAMS scripts/replay_motion.py DESTINATION lib/${PROJECT_NAME})
endif()

ament_package()
