// concept part: spindle (wrist)
// units: mm. Mesh with: openscad -o spindle.stl spindle.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -60], [0, 0, 0, 1]])
  cylinder(h=120, r=20, center=true, $fn=48);
