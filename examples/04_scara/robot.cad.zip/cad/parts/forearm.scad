// concept part: forearm (forearm)
// units: mm. Mesh with: openscad -o forearm.stl forearm.scad
multmatrix([[0, 0, 1, 100], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=200, r=30, center=true, $fn=48);
