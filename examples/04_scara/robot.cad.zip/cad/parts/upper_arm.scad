// concept part: upper_arm (upper_arm)
// units: mm. Mesh with: openscad -o upper_arm.stl upper_arm.scad
multmatrix([[0, 0, 1, 125], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=250, r=35, center=true, $fn=48);
