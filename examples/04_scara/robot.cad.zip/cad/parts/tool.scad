// concept part: tool (wrist)
// units: mm. Mesh with: openscad -o tool.stl tool.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -15], [0, 0, 0, 1]])
  cylinder(h=30, r=15, center=true, $fn=48);
