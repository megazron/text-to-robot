# Assembly — scara

Start from **base_link**.

1. Mount the **NEMA17 stepper + 5.18:1 planetary gearbox (StepperOnline 17HS19-1684S-PG5)** (j1_motor) in **base_link** with its case screws.
2. Mount the **Ball bearing 61808-2RZ (6808 thin section) 40x52x7 mm** (j1_bearing_lower) in **base_link** with its case screws.
3. Mount the **Ball bearing 61808-2RZ (6808 thin section) 40x52x7 mm** (j1_bearing_upper) in **base_link** with its case screws.
4. Set joint `j1` to zero (centre the servo first), then screw **column** to the actuator output in **base_link**; it moves -166° … 166°.
5. Mount the **Hardened chromed linear rod 8 mm h6, 300 mm** (z_rod_right) in **column** with its case screws.
6. Mount the **Hardened chromed linear rod 8 mm h6, 300 mm** (z_rod_left) in **column** with its case screws.
7. Mount the **Ball bearing 608-2Z 8x22x7 mm** (z_screw_bearing) in **column** with its case screws.
8. Mount the **Lead screw Tr8x8 (P2, 4 starts) 300 mm, stainless steel** (z_lead_screw) in **column** with its case screws.
9. Bolt **column_top** to **column**.
10. Mount the **NEMA17 stepper 42x42x40 mm, 0.45 N.m (StepperOnline 17HS16-2004S1)** (z_motor) in **column_top** with its case screws.
11. Mount the **Aluminium flexible beam coupler 5 mm to 8 mm (D19 L25)** (z_coupler) in **column_top** with its case screws.
12. Set joint `z` to zero (centre the servo first), then screw **inner_arm** to the actuator output in **column**; it moves 0° … 9°.
13. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (z_bushing_r1) in **inner_arm** with its case screws.
14. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (z_bushing_r2) in **inner_arm** with its case screws.
15. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (z_bushing_l1) in **inner_arm** with its case screws.
16. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (z_bushing_l2) in **inner_arm** with its case screws.
17. Mount the **Tr8x8 brass flange nut (22 mm flange, 4x M3 on PCD 16)** (z_nut) in **inner_arm** with its case screws.
18. Mount the **NEMA17 stepper + 5.18:1 planetary gearbox (StepperOnline 17HS19-1684S-PG5)** (j2_motor) in **inner_arm** with its case screws.
19. Mount the **Ball bearing 61806-2Z (6806ZZ) 30x42x7 mm** (j2_bearing_upper) in **inner_arm** with its case screws.
20. Mount the **Ball bearing 61806-2Z (6806ZZ) 30x42x7 mm** (j2_bearing_lower) in **inner_arm** with its case screws.
21. Set joint `j2` to zero (centre the servo first), then screw **outer_arm** to the actuator output in **inner_arm**; it moves -127° … 127°.
22. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (wrist_servo) in **outer_arm** with its case screws.
23. Set joint `wrist_roll` to zero (centre the servo first), then screw **wrist_flange** to the actuator output in **outer_arm**; it moves -172° … 172°.
24. Bolt **gripper_body** to **wrist_flange**.
25. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (gripper_servo) in **gripper_body** with its case screws.
26. Set joint `gripper_pinion` to zero (centre the servo first), then screw **pinion** to the actuator output in **gripper_body**; it moves 0° … 109°.
27. Set joint `finger_a` to zero (centre the servo first), then screw **finger_a** to the actuator output in **gripper_body**; it moves 0° … 1°.
28. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (finger_a_bushing_lower) in **finger_a** with its case screws.
29. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (finger_a_bushing_upper) in **finger_a** with its case screws.
30. Set joint `finger_b` to zero (centre the servo first), then screw **finger_b** to the actuator output in **gripper_body**; it moves 0° … 1°.
31. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (finger_b_bushing_lower) in **finger_b** with its case screws.
32. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (finger_b_bushing_upper) in **finger_b** with its case screws.
33. Mount the **Hardened chromed linear rod 8 mm h6, 110 mm** (gripper_rod_lower) in **gripper_body** with its case screws.
34. Mount the **Hardened chromed linear rod 8 mm h6, 110 mm** (gripper_rod_upper) in **gripper_body** with its case screws.
35. Bolt **controller_box** to **base_link**.
36. Mount the **Mean Well LRS-150-24 enclosed PSU, 24 V 6.5 A (156 W)** (psu_24v) in **controller_box** with its case screws.
37. Mount the **Mean Well LRS-75-12 enclosed PSU, 12 V 6 A (75 W)** (psu_12v) in **controller_box** with its case screws.
38. Bolt **controller_deck** to **controller_box**.
39. Mount the **Espressif ESP32-S3-DevKitC-1 (N8R8)** (controller) in **controller_deck** with its case screws.
40. Mount the **BigTreeTech TMC2209 V1.3 StepStick stepper driver (UART)** (driver_j1) in **controller_deck** with its case screws.
41. Mount the **BigTreeTech TMC2209 V1.3 StepStick stepper driver (UART)** (driver_j2) in **controller_deck** with its case screws.
42. Mount the **BigTreeTech TMC2209 V1.3 StepStick stepper driver (UART)** (driver_z) in **controller_deck** with its case screws.
43. Mount the **Waveshare Bus Servo Adapter (A)** (servo_bus) in **controller_deck** with its case screws.

## Fasteners

- 4 × M5 x 16 socket head (base to bench)
- 16 × M3 x 8 socket head (motor face)
- 4 × M3 x 6 set screw (rod clamps)
- 4 × M3 x 8 socket head + heat-set insert (lead nut)
- 0 × M6 x 16 socket head (adapter to robot flange)
- 4 × M4 x 10 socket head + M4 heat-set insert (housing to adapter, radial)
- 4 × M3 x 6 set screw (rod retention)
- 4 × servo case screws (M2 x 6)
- 4 × horn screws
- 4 × M3 x 6 socket head (PSU bottom)
- 4 × M2 x 6 screw (bus adapter)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
