# Printability — scara

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 120 × 120 × 3 | ✅ |
| base_link_service_lid | 120 × 120 × 3 | ✅ |
| base_link_rear_panel | 3 × 120 × 344 | ❌ |
| base_link_right_panel | 114 × 3 × 344 | ❌ |
| base_link_front_panel | 3 × 120 × 344 | ❌ |
| base_link_left_panel | 114 × 3 × 344 | ❌ |
| base_link_standoff_rr | 8 × 8 × 344 | ❌ |
| base_link_standoff_rl | 8 × 8 × 344 | ❌ |
| base_link_standoff_fr | 8 × 8 × 344 | ❌ |
| base_link_standoff_fl | 8 × 8 × 344 | ❌ |
| upper_arm | 70 × 70 × 250 | ❌ |
| forearm | 60 × 60 × 200 | ✅ |
| spindle | 40 × 40 × 120 | ✅ |
| tool | 30 × 30 × 30 | ✅ |

## Notes
- ⚠️ **base_link_rear_panel**: longest dimension 344 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_right_panel**: longest dimension 344 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_front_panel**: longest dimension 344 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_left_panel**: longest dimension 344 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_standoff_rr**: longest dimension 344 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_standoff_rl**: longest dimension 344 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_standoff_fr**: longest dimension 344 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_standoff_fl**: longest dimension 344 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **upper_arm**: longest dimension 250 mm exceeds the 220 mm build volume — split the part or print diagonally
