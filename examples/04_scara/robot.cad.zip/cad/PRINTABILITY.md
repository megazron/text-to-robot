# Printability — scara

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 120 × 120 × 350 | ❌ |
| upper_arm | 70 × 70 × 250 | ❌ |
| forearm | 60 × 60 × 200 | ✅ |
| spindle | 40 × 40 × 120 | ✅ |
| tool | 30 × 30 × 30 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 350 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **upper_arm**: longest dimension 250 mm exceeds the 220 mm build volume — split the part or print diagonally
