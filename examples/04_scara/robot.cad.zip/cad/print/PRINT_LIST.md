# Print list: scara

13 parts, about 2081 g of PETG and 189.7 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 180 × 180 × 121 | 420 | 38.3 | yes |
| column | 124 × 124 × 48.4 | 150 | 13.6 | yes |
| column_top | 70 × 96 × 39 | 49 | 4.5 | yes |
| inner_arm | 239 × 96 × 56 | 460 | 41.9 | yes |
| outer_arm | 172.2 × 48 × 40.4 | 106 | 9.6 | yes |
| wrist_flange | 63 × 63 × 10 | 25 | 2.3 | yes |
| gripper_body | 122 × 72 × 144.6 | 227 | 20.6 | yes |
| pinion | 28 × 28 × 12 | 4 | 0.4 | yes |
| finger_a | 58 × 36.8 × 116 | 66 | 6.0 | yes |
| finger_b | 58 × 36.8 × 116 | 66 | 6.0 | yes |
| controller_box | 230 × 206 × 92 | 324 | 29.5 | yes |
| controller_deck | 161.7 × 199.4 × 9 | 71 | 6.5 | yes |
| controller_lid | 230 × 206 × 6 | 113 | 10.3 | yes |
