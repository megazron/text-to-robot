# Print list — scara

13 parts, about 1964 g of PETG and 179.0 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 180 × 180 × 121 | 422 | 38.5 | yes |
| column | 124 × 124 × 48.4 | 150 | 13.7 | yes |
| column_top | 70 × 96 × 39 | 49 | 4.5 | yes |
| inner_arm | 239 × 96 × 63.8 | 461 | 42.0 | yes |
| outer_arm | 172.2 × 48 × 40.4 | 106 | 9.6 | yes |
| wrist_flange | 63 × 63 × 10 | 25 | 2.3 | yes |
| gripper_body | 122 × 72 × 138.6 | 213 | 19.4 | yes |
| pinion | 28 × 28 × 12 | 4 | 0.4 | yes |
| finger_a | 58 × 36.8 × 116 | 66 | 6.0 | yes |
| finger_b | 58 × 36.8 × 116 | 66 | 6.0 | yes |
| controller_box | 171 × 206 × 86 | 249 | 22.7 | yes |
| controller_deck | 164.4 × 199.4 × 23.9 | 73 | 6.7 | yes |
| controller_lid | 171 × 206 × 6 | 79 | 7.2 | yes |
