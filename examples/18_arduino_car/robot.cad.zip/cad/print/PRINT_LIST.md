# Print list — arduino_car

2 parts, about 97 g of PETG and 8.9 h of printing.

Exact solids of these parts are in `cad/step/` (STEP AP214, millimetres): open them in Fusion, FreeCAD or Onshape to edit.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| chassis | 200 × 112 × 26.7 | 91 | 8.3 | yes |
| sensor_bracket | 16 × 52 × 29 | 6 | 0.6 | yes |
