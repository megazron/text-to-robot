# Print list — arduino_car

4 parts, about 163 g of PETG and 14.8 h of printing.

Exact solids of these parts are in `cad/step/` (STEP AP214, millimetres): open them in Fusion, FreeCAD or Onshape to edit.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| chassis | 200 × 112 × 26.7 | 92 | 8.4 | yes |
| electronics_bay | 184.7 × 107.1 × 26 | 30 | 2.7 | yes |
| electronics_bay_lid | 184.7 × 107.1 × 5.2 | 35 | 3.2 | yes |
| sensor_bracket | 16 × 52 × 29 | 6 | 0.6 | yes |
