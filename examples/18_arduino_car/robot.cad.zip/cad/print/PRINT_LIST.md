# Print list: arduino_car

4 parts, about 203 g of PETG and 18.5 h of printing.

Exact solids of these parts are in `cad/step/` (STEP AP214, millimetres): open them in Fusion, FreeCAD or Onshape to edit.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| chassis | 222 × 122 × 28.5 | 109 | 9.9 | yes |
| electronics_bay | 206.7 × 117.1 × 36 | 46 | 4.2 | yes |
| electronics_bay_lid | 206.7 × 117.1 × 5.2 | 43 | 3.9 | yes |
| sensor_bracket | 16 × 52 × 29 | 6 | 0.5 | yes |
