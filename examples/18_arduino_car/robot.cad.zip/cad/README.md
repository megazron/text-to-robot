# Build package: arduino_car

Arduino car (stronger (4WD, ramps up to 10 deg)): 4WD on TT gear motors, 0.68 kg, 0.54 m/s, 99 min, $54 of parts

1. **Buy** everything in `BOM.md` (supplier links included).
2. **Print** every STL in `print/` (see `print/PRINT_LIST.md`).
3. **Assemble** in the order of `ASSEMBLY.md`.
   **Wire** from `WIRING.md` (pin-to-pin table, cut list, power budget, battery runtime, regulator heat, logic levels), `schematic.svg` / `schematic.pdf` the picture view `breadboard.svg` and the harness in 3D `electronics.glb`.
   **Flash** the Arduino with `firmware/arduino_car/arduino_car.ino`: board, libraries, port and the pin map are in `firmware/README.md`.
4. **Check** against `design.json`: each actuator's required vs rated torque, the speed it reaches loaded, battery runtime, stability and every other check the design passed.

`reference/` holds the bought parts' models (from their datasheet drawings) for your own CAD; `arduino_car_assembly.stl` is the whole robot in its build pose.

## Assumptions

- TT motor continuous torque taken as 30 % of the 0.8 kg.cm stall (Adafruit #3777 data)
- prices are typical single-unit marketplace prices for generic modules and vary by seller
