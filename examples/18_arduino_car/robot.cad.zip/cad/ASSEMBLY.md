# Assembly: arduino_car

Start from **chassis**.

1. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (front_left_motor) in **chassis** with its case screws.
2. Fit **front_left_wheel** on the output of the motor in **chassis** (driven joint `front_left_wheel_joint`).
3. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (front_right_motor) in **chassis** with its case screws.
4. Fit **front_right_wheel** on the output of the motor in **chassis** (driven joint `front_right_wheel_joint`).
5. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (rear_left_motor) in **chassis** with its case screws.
6. Fit **rear_left_wheel** on the output of the motor in **chassis** (driven joint `rear_left_wheel_joint`).
7. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (rear_right_motor) in **chassis** with its case screws.
8. Fit **rear_right_wheel** on the output of the motor in **chassis** (driven joint `rear_right_wheel_joint`).
9. Bolt **electronics_bay** to **chassis**.
10. Bolt **electronics_bay_lid** to **electronics_bay**.
11. Mount the **2S 18650 pack: two 2500 mAh 20 A cells (Samsung 25R class) in a plain two-cell holder** (battery) in **electronics_bay** with its case screws.
12. Mount the **Half-size solderless breadboard, 400 points, adhesive back** (breadboard) in **electronics_bay** with its case screws.
13. Mount the **Arduino Nano compatible board (ATmega328P, CH340, USB-C)** (controller) in **breadboard** with its case screws.
14. Mount the **TB6612FNG dual DC motor driver module (1.2 A per channel)** (motor_driver_1) in **breadboard** with its case screws.
15. Mount the **TB6612FNG dual DC motor driver module (1.2 A per channel)** (motor_driver_2) in **breadboard** with its case screws.
16. Mount the **KCD1 rocker switch, SPST, 6 A 250 VAC / 10 A 125 VAC** (main_switch) in **electronics_bay** with its case screws.
17. Bolt **sensor_bracket** to **chassis**.
18. Mount the **HC-SR04 ultrasonic distance sensor (2-400 cm)** (ultrasonic) in **sensor_bracket** with its case screws.

## Fasteners

- 8 × M3x25 socket head + nut (motor through-bolt)
- 4 × M3 x 10 self-tapping (lid to compartment)
- 4 × M3 x 12 self-tapping (compartment to its base, from below)
- 2 × M3 x 6 self-tapping (2S 18650 pack: two 2500 mAh 20 A cells to standoffs)
- 2 × M3x8 countersunk + nut (pack, through the deck)
- 2 × M3x10 + nut (sensor bracket)
- 4 × M2x6 self-tapping (sensor)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
