# Assembly: cartesian_gantry

Start from **base_link**.

1. Bolt **y_module_end_a** to **base_link**.
2. Bolt **y_module_end_b** to **base_link**.
3. Mount the **Hardened chromed linear rod 8 mm h6, 300 mm** (y_module_rod_b) in **base_link** with its case screws.
4. Mount the **Hardened chromed linear rod 8 mm h6, 300 mm** (y_module_rod_a) in **base_link** with its case screws.
5. Mount the **NEMA17 stepper 42x42x40 mm, 0.45 N.m (StepperOnline 17HS16-2004S1)** (y_motor) in **base_link** with its case screws.
6. Mount the **Aluminium flexible beam coupler 5 mm to 8 mm (D19 L25)** (y_module_coupler) in **base_link** with its case screws.
7. Mount the **Lead screw Tr8x8 (P2, 4 starts) 300 mm, stainless steel** (y_module_screw) in **base_link** with its case screws.
8. Mount the **Ball bearing 608-2Z 8x22x7 mm** (y_module_bearing) in **base_link** with its case screws.
9. Mount the **Mechanical end stop, microswitch on a small board, 3-pin** (y_endstop) in **base_link** with its case screws.
10. Set joint `y_axis` to zero (centre the servo first), then screw **y_module_carriage** to the actuator output in **base_link**; it moves 0° … 10°.
11. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (y_module_bushing_b1) in **y_module_carriage** with its case screws.
12. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (y_module_bushing_b2) in **y_module_carriage** with its case screws.
13. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (y_module_bushing_a1) in **y_module_carriage** with its case screws.
14. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (y_module_bushing_a2) in **y_module_carriage** with its case screws.
15. Mount the **Tr8x8 brass flange nut (22 mm flange, 4x M3 on PCD 16)** (y_module_nut) in **y_module_carriage** with its case screws.
16. Bolt **x_adapter** to **y_module_carriage**.
17. Bolt **x_module_end_a** to **y_module_carriage**.
18. Bolt **x_module_end_b** to **y_module_carriage**.
19. Mount the **Hardened chromed linear rod 8 mm h6, 300 mm** (x_module_rod_b) in **y_module_carriage** with its case screws.
20. Mount the **Hardened chromed linear rod 8 mm h6, 300 mm** (x_module_rod_a) in **y_module_carriage** with its case screws.
21. Mount the **NEMA17 stepper 42x42x40 mm, 0.45 N.m (StepperOnline 17HS16-2004S1)** (x_motor) in **y_module_carriage** with its case screws.
22. Mount the **Aluminium flexible beam coupler 5 mm to 8 mm (D19 L25)** (x_module_coupler) in **y_module_carriage** with its case screws.
23. Mount the **Lead screw Tr8x8 (P2, 4 starts) 300 mm, stainless steel** (x_module_screw) in **y_module_carriage** with its case screws.
24. Mount the **Ball bearing 608-2Z 8x22x7 mm** (x_module_bearing) in **y_module_carriage** with its case screws.
25. Mount the **Mechanical end stop, microswitch on a small board, 3-pin** (x_endstop) in **y_module_carriage** with its case screws.
26. Set joint `x_axis` to zero (centre the servo first), then screw **x_module_carriage** to the actuator output in **y_module_carriage**; it moves 0° … 10°.
27. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (x_module_bushing_b1) in **x_module_carriage** with its case screws.
28. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (x_module_bushing_b2) in **x_module_carriage** with its case screws.
29. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (x_module_bushing_a1) in **x_module_carriage** with its case screws.
30. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (x_module_bushing_a2) in **x_module_carriage** with its case screws.
31. Mount the **Tr8x8 brass flange nut (22 mm flange, 4x M3 on PCD 16)** (x_module_nut) in **x_module_carriage** with its case screws.
32. Bolt **z_bracket** to **x_module_carriage**.
33. Bolt **z_module_end_a** to **x_module_carriage**.
34. Bolt **z_module_end_b** to **x_module_carriage**.
35. Mount the **Hardened chromed linear rod 8 mm h6, 130 mm** (z_module_rod_b) in **x_module_carriage** with its case screws.
36. Mount the **Hardened chromed linear rod 8 mm h6, 130 mm** (z_module_rod_a) in **x_module_carriage** with its case screws.
37. Mount the **NEMA17 stepper 42x42x40 mm, 0.45 N.m (StepperOnline 17HS16-2004S1)** (z_motor) in **x_module_carriage** with its case screws.
38. Mount the **Aluminium flexible beam coupler 5 mm to 8 mm (D19 L25)** (z_module_coupler) in **x_module_carriage** with its case screws.
39. Mount the **Lead screw Tr8x8 (P2, 4 starts) 150 mm, stainless steel** (z_module_screw) in **x_module_carriage** with its case screws.
40. Mount the **Ball bearing 608-2Z 8x22x7 mm** (z_module_bearing) in **x_module_carriage** with its case screws.
41. Mount the **Mechanical end stop, microswitch on a small board, 3-pin** (z_endstop) in **x_module_carriage** with its case screws.
42. Set joint `z_axis` to zero (centre the servo first), then screw **z_module_carriage** to the actuator output in **x_module_carriage**; it moves 0° … 1°.
43. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (z_module_bushing_b1) in **z_module_carriage** with its case screws.
44. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (z_module_bushing_a1) in **z_module_carriage** with its case screws.
45. Mount the **Tr8x8 brass flange nut (22 mm flange, 4x M3 on PCD 16)** (z_module_nut) in **z_module_carriage** with its case screws.
46. Bolt **pen_holder** to **z_module_carriage**.
47. Bolt **control_case** to **base_link**.
48. Bolt **control_case_lid** to **control_case**.
49. Mount the **Mean Well LRS-150-24 enclosed PSU, 24 V 6.5 A (156 W)** (power_supply) in **control_case** with its case screws.
50. Mount the **Espressif ESP32-S3-DevKitC-1 (N8R8)** (controller) in **control_case** with its case screws.
51. Mount the **BigTreeTech TMC2209 V1.3 StepStick stepper driver (UART)** (driver_x) in **control_case** with its case screws.
52. Mount the **BigTreeTech TMC2209 V1.3 StepStick stepper driver (UART)** (driver_y) in **control_case** with its case screws.
53. Mount the **BigTreeTech TMC2209 V1.3 StepStick stepper driver (UART)** (driver_z) in **control_case** with its case screws.
54. Mount the **IEC C14 panel inlet with fuse drawer and rocker switch, 10 A** (mains_inlet) in **control_case** with its case screws.

## Fasteners

- 12 × M3 x 12 self-tapping (lead nut)
- 4 × M4 x 12 socket head (adapter to Y carriage)
- 4 × M4 x 12 socket head (Z bracket to X carriage)
- 1 × M3 x 10 thumb screw (pen clamp)
- 4 × M3 x 10 self-tapping (lid to compartment)
- 2 × M3 x 6 self-tapping (Mean Well LRS-150-24 enclosed PSU, 24 V 6.5 A to standoffs)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
