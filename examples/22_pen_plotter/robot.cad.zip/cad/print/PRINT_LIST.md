# Print list: cartesian_gantry

14 parts, about 1025 g of PETG and 93.4 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| y_module_end_a | 72 × 16 × 44 | 38 | 3.5 | yes |
| y_module_end_b | 72 × 27 × 44 | 73 | 6.6 | yes |
| y_module_carriage | 32 × 76 × 70 | 130 | 11.8 | yes |
| x_adapter | 4 × 75 × 70 | 19 | 1.7 | yes |
| x_module_end_a | 44 × 21 × 80.1 | 39 | 3.5 | yes |
| x_module_end_b | 44 × 27 × 72 | 73 | 6.6 | yes |
| x_module_carriage | 32 × 76 × 70 | 130 | 11.8 | yes |
| z_bracket | 180 × 76 × 70 | 64 | 5.8 | yes |
| z_module_end_a | 16 × 44 × 72 | 38 | 3.5 | yes |
| z_module_end_b | 47 × 44 × 72 | 129 | 11.8 | yes |
| z_module_carriage | 32 × 76 × 34 | 63 | 5.7 | yes |
| pen_holder | 22 × 60 × 60 | 19 | 1.7 | yes |
| control_case | 249.7 × 150.1 × 44.4 | 152 | 13.8 | yes |
| control_case_lid | 249.7 × 150.1 × 5.8 | 59 | 5.3 | yes |
