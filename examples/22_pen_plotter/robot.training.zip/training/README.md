# Train cartesian_gantry

Auto-generated training suite. Robot class: **manipulator**. Physics: PyBullet (loads the URDF directly with a motor per joint). No ROS required.

```bash
cd training
pip install -r requirements.txt
```

## Tasks available
  - `reach`: Reach a sampled collision-free target
  - `track`: Track a sequence of reachable targets
  - `hold`: Reach and hold (settle) at the target

## MuJoCo (recommended)
See `mujoco/README.md`: the same URDF converted to an actuated MuJoCo scene, with a test battery, renderer and PPO trainer.

## Reinforcement learning in PyBullet (PPO / SAC)
```bash
python train_rl.py --task reach --algo ppo --steps 200000
python train_rl.py --task reach --play          # watch it
```

## Imitation learning (behaviour cloning)
```bash
python collect_demos.py --task reach --episodes 50   # scripted expert -> demos.npz
python train_bc.py --epochs 50                                     # clone the expert
```

## Evaluate
```bash
python evaluate.py --task reach --rl cartesian_gantry_ppo_reach
python evaluate.py --task reach --bc bc_cartesian_gantry.pt
```

Add your own task by dropping a reward function into `tasks.py`; it is picked up automatically.
Classical motion planning is available via the exported ROS 2 / MoveIt 2 package.

## Reference motions
`reference_motions/` holds `plot.csv`, `tour.csv`: the motions the website plays, as joint positions at 30 Hz (one column per joint, `time_s` first; `<motion>_base.csv` is the base path when the whole robot moves). Use them as targets for motion imitation or as a tracking reward:

```python
from reference_motion import ReferenceMotion
ref = ReferenceMotion("reference_motions/plot.csv")
target = ref.at(t)            # {joint: position} at time t (seconds), interpolated, looped
```
