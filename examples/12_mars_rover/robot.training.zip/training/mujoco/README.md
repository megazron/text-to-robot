# rover_arm in MuJoCo

Test, render and train this exact robot in MuJoCo with the text-to-robot Python layer:

```bash
pip install -r requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cpu    # CPU torch on GPU-less machines

python -m ttr_mujoco test   ../rover_arm.urdf --self-collision                       # settle / hold / actuator sweep / disturbance
python -m ttr_mujoco render ../rover_arm.urdf -o rover_arm.gif --motion sweep
python -m ttr_mujoco train  ../rover_arm.urdf --self-collision --task stand --steps 400000
```

Or from Python:

```python
from ttr_mujoco import urdf_to_mjcf, run_tests, render_gif
from ttr_mujoco.env import MujocoRobotEnv
report = run_tests("../rover_arm.urdf")              # dict with per-test pass/fail + metrics
env = MujocoRobotEnv("../rover_arm.urdf", task="stand")
```
