# Train rover_arm

Auto-generated training suite. Robot class: **mobile**. Physics: PyBullet (loads the URDF directly with a motor per joint). No ROS required.

```bash
cd training
pip install -r requirements.txt
```

## Tasks available
  - `forward`: Drive forward as fast as possible
  - `goto`: Navigate to a goal point

## MuJoCo (recommended)
See `mujoco/README.md`: the same URDF converted to an actuated MuJoCo scene, with a test battery, renderer and PPO trainer.

## Reinforcement learning in PyBullet (PPO / SAC)
```bash
python train_rl.py --task forward --algo ppo --steps 200000
python train_rl.py --task forward --play          # watch it
```

## Imitation learning (behaviour cloning)
```bash
python collect_demos.py --task forward --episodes 50   # scripted expert -> demos.npz
python train_bc.py --epochs 50                                     # clone the expert
```

## Evaluate
```bash
python evaluate.py --task forward --rl rover_arm_ppo_forward
python evaluate.py --task forward --bc bc_rover_arm.pt
```

Add your own task by dropping a reward function into `tasks.py`; it is picked up automatically.
Classical motion planning is available via the exported ROS 2 / MoveIt 2 package.

## Reference motions
`reference_motions/` holds `drive.csv`, `pick_place.csv`, `grip.csv`: the motions the website plays, as joint positions at 30 Hz (one column per joint, `time_s` first; `<motion>_base.csv` is the base path when the whole robot moves). Use them as targets for motion imitation or as a tracking reward:

```python
from reference_motion import ReferenceMotion
ref = ReferenceMotion("reference_motions/drive.csv")
target = ref.at(t)            # {joint: position} at time t (seconds), interpolated, looped
```
