# Build package — rover_arm

4-wheel rocker-bogie rover with a 6-DOF arm: 4.677 kg, 1.24 m/s, 1.53 h, jetson_orin_nano_super

1. **Buy** everything in `BOM.md` (supplier links included).
2. **Print** every STL in `print/` (see `print/PRINT_LIST.md`).
3. **Assemble** in the order of `ASSEMBLY.md`.
4. **Check** against `design.json`: each actuator's required vs rated torque, the speed it reaches loaded, battery runtime, stability and every other check the design passed.

`reference/` holds the bought parts' models (from their datasheet drawings) for your own CAD; `rover_arm_assembly.stl` is the whole robot in its build pose.

## Assumptions

- Rocker-bogie after the JPL Open Source Rover, 4 driven wheels, skid steering (the OSR's four corner-steering servos are left out; add them for less tyre scrub).
- A rover's differential bar links the two rockers through the body, a closed loop URDF cannot describe; the model frees the left rocker on its pivot and bolts the right rocker to the body, which keeps every wheel on the ground and the body supported on three points (body pitch follows the right rocker instead of the average).
- Rockers and bogies are printed in PETG; for outdoor use print them in 6 bolt-on sections from aluminium channel instead (as the OSR does).
- Body: folded 2 mm aluminium box with a 3 mm lid; electronics on printed standoff plates on its floor.
- All motors and servos are 12 V parts run straight from a 3S LiPo; arm servos share the pack through the bus adapter.
- Arm: 6 DOF bolted to the lid front, sized as mounted for a 0.2 kg sample at full reach; the rover's tipping check includes the arm stretched forward, sideways and back with the sample.
