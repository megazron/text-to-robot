// concept part: arm_mount_standoff_rr (housing)
// units: mm. Mesh with: openscad -o arm_mount_standoff_rr.stl arm_mount_standoff_rr.scad
import("../stl/parts/arm_mount_standoff_rr.stl");
