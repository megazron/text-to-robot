// concept part: depth_1_link (sensor)
// units: mm. Mesh with: openscad -o depth_1_link.stl depth_1_link.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cube([40, 60, 30], center=true);
