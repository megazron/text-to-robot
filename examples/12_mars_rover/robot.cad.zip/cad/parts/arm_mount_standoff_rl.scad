// concept part: arm_mount_standoff_rl (housing)
// units: mm. Mesh with: openscad -o arm_mount_standoff_rl.stl arm_mount_standoff_rl.scad
import("../stl/parts/arm_mount_standoff_rl.stl");
