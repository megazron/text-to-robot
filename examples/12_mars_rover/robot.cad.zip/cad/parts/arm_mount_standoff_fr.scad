// concept part: arm_mount_standoff_fr (housing)
// units: mm. Mesh with: openscad -o arm_mount_standoff_fr.stl arm_mount_standoff_fr.scad
import("../stl/parts/arm_mount_standoff_fr.stl");
