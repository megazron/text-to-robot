// concept part: arm_mount (link)
// units: mm. Mesh with: openscad -o arm_mount.stl arm_mount.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 60], [0, 0, 0, 1]])
  cylinder(h=120, r=60, center=true, $fn=48);
