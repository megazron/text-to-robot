// concept part: arm_mount (link)
// units: mm. Mesh with: openscad -o arm_mount.stl arm_mount.scad
import("../stl/parts/arm_mount.stl");
