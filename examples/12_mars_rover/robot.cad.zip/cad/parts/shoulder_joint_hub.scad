// concept part: shoulder_joint_hub (joint_housing)
// units: mm. Mesh with: openscad -o shoulder_joint_hub.stl shoulder_joint_hub.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=28.32, center=true, $fn=48);
