// concept part: arm_mount_service_lid (housing)
// units: mm. Mesh with: openscad -o arm_mount_service_lid.stl arm_mount_service_lid.scad
import("../stl/parts/arm_mount_service_lid.stl");
