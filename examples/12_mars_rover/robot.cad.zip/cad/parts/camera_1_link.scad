// concept part: camera_1_link (sensor)
// units: mm. Mesh with: openscad -o camera_1_link.stl camera_1_link.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cube([40, 60, 30], center=true);
