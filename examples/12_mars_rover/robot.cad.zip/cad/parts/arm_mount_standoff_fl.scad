// concept part: arm_mount_standoff_fl (housing)
// units: mm. Mesh with: openscad -o arm_mount_standoff_fl.stl arm_mount_standoff_fl.scad
import("../stl/parts/arm_mount_standoff_fl.stl");
