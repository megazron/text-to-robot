# Print list — rover_arm

20 parts, about 828 g of PETG and 75.4 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| left_rocker_rear_arm | 145.4 × 122.2 × 19 | 48 | 4.4 | yes |
| left_rocker_frame | 170 × 138 × 19 | 58 | 5.3 | yes |
| right_rocker_rear_arm | 145.4 × 122.2 × 19 | 48 | 4.4 | yes |
| right_rocker_frame | 170 × 138 × 19 | 58 | 5.3 | yes |
| battery_tray | 157.6 × 49.7 × 17.8 | 29 | 2.6 | yes |
| computer_tray | 102 × 94 × 7 | 27 | 2.4 | yes |
| motor_driver_1_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| motor_driver_2_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| servo_bus_tray | 44 × 35 × 7 | 5 | 0.4 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| depth_camera_bracket | 30 × 60 × 72 | 24 | 2.2 | yes |
| camera_mast | 50 × 50 × 194 | 64 | 5.8 | yes |
| arm_base_link | 100 × 100 × 45.9 | 76 | 6.9 | yes |
| arm_turret | 39.5 × 54 × 71.5 | 32 | 3.0 | yes |
| arm_upper_arm | 156.9 × 39.5 × 72.2 | 93 | 8.4 | yes |
| arm_forearm | 128.4 × 55.8 × 69.2 | 109 | 9.9 | yes |
| arm_forearm_rotator | 34.5 × 43.9 × 59.5 | 21 | 1.9 | yes |
| arm_wrist | 98.1 × 54.3 × 59.1 | 61 | 5.5 | yes |
| arm_wrist_rotator | 49.4 × 42.3 × 115.3 | 32 | 2.9 | yes |
| arm_gripper_jaw | 84.3 × 39.3 × 8.5 | 10 | 0.9 | yes |
