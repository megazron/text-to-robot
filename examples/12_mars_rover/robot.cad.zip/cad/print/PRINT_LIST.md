# Print list — rover_arm

20 parts, about 627 g of PETG and 57.2 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| left_rocker_rear_arm | 145.4 × 122.2 × 19 | 48 | 4.4 | yes |
| left_rocker_frame | 170 × 138 × 19 | 58 | 5.3 | yes |
| right_rocker_rear_arm | 145.4 × 122.2 × 19 | 48 | 4.4 | yes |
| right_rocker_frame | 170 × 138 × 19 | 58 | 5.3 | yes |
| battery_tray | 157.6 × 49.7 × 17.8 | 29 | 2.6 | yes |
| computer_tray | 96 × 88 × 7 | 24 | 2.1 | yes |
| motor_driver_1_tray | 84.4 × 61.4 × 7 | 13 | 1.2 | yes |
| motor_driver_2_tray | 84.4 × 61.4 × 7 | 13 | 1.2 | yes |
| servo_bus_tray | 42.4 × 33.4 × 7 | 3 | 0.3 | yes |
| regulator_5v_tray | 26.7 × 26.7 × 7 | 2 | 0.1 | yes |
| depth_camera_bracket | 30 × 60 × 72 | 24 | 2.2 | yes |
| camera_mast | 50 × 50 × 194 | 64 | 5.8 | yes |
| arm_base_link | 100 × 100 × 45.9 | 72 | 6.5 | yes |
| arm_turret | 39.5 × 49 × 71.5 | 25 | 2.3 | yes |
| arm_upper_arm | 137 × 39.5 × 51.5 | 31 | 2.8 | yes |
| arm_forearm | 110.4 × 55.8 × 46.8 | 38 | 3.4 | yes |
| arm_forearm_rotator | 34.5 × 38.9 × 59.5 | 18 | 1.6 | yes |
| arm_wrist | 98.1 × 54.3 × 41.7 | 29 | 2.7 | yes |
| arm_wrist_rotator | 47.4 × 42.3 × 115.3 | 25 | 2.3 | yes |
| arm_gripper_jaw | 84.3 × 37.3 × 6.5 | 5 | 0.5 | yes |
