# Print list: rover_arm

21 parts, about 827 g of PETG and 75.4 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| left_rocker_rear_arm | 146.8 × 122.1 × 19 | 49 | 4.5 | yes |
| left_rocker_frame | 171.6 × 138 × 28 | 60 | 5.5 | yes |
| right_rocker_rear_arm | 146.8 × 122.1 × 19 | 49 | 4.5 | yes |
| right_rocker_frame | 171.6 × 138 × 19 | 59 | 5.4 | yes |
| battery_tray | 172.6 × 49.7 × 17.8 | 31 | 2.8 | yes |
| computer_tray | 102 × 94 × 7 | 27 | 2.4 | yes |
| motor_driver_1_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| motor_driver_2_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| io_controller_tray | 66.2 × 27.4 × 9 | 5 | 0.5 | yes |
| servo_bus_tray | 44 × 35 × 7 | 5 | 0.4 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| depth_camera_bracket | 30 × 60 × 72 | 24 | 2.2 | yes |
| camera_mast | 50 × 50 × 194 | 64 | 5.8 | yes |
| arm_base_link | 100 × 100 × 45.9 | 75 | 6.8 | yes |
| arm_turret | 39.5 × 54 × 71.5 | 32 | 2.9 | yes |
| arm_upper_arm | 156.9 × 39.5 × 72.2 | 92 | 8.3 | yes |
| arm_forearm | 128.4 × 55.8 × 69.2 | 105 | 9.6 | yes |
| arm_forearm_rotator | 34.5 × 43.9 × 59.5 | 20 | 1.8 | yes |
| arm_wrist | 98.1 × 54.3 × 59.1 | 57 | 5.2 | yes |
| arm_wrist_rotator | 49.4 × 42.3 × 115.3 | 31 | 2.9 | yes |
| arm_gripper_jaw | 84.3 × 39.3 × 8.5 | 10 | 0.9 | yes |
