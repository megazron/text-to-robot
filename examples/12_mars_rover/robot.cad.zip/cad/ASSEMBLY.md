# Assembly — rover_arm

Start from **base_link**.

1. Bolt **deck_lid** to **base_link**.
2. Bolt **depth_camera_bracket** to **deck_lid**.
3. Mount the **Intel RealSense D435i depth camera + IMU** (depth_camera) in **deck_lid** with its case screws.
4. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (mast_camera) in **deck_lid** with its case screws.
5. Bolt **camera_mast** to **deck_lid**.
6. Bolt **arm_base_link** to **deck_lid**.
7. Mount the **DYNAMIXEL XM430-W350-T(R)** (arm_base_yaw_actuator) in **arm_base_link** with its case screws.
8. Set joint `arm_base_yaw` to zero (centre the servo first), then screw **arm_turret** to the actuator output in **arm_base_link**; it moves -170° … 170°.
9. Mount the **DYNAMIXEL XH540-W270-T(R)** (arm_shoulder_pitch_actuator) in **arm_turret** with its case screws.
10. Set joint `arm_shoulder_pitch` to zero (centre the servo first), then screw **arm_upper_arm** to the actuator output in **arm_turret**; it moves -100° … 100°.
11. Mount the **DYNAMIXEL XH540-W270-T(R)** (arm_elbow_pitch_actuator) in **arm_upper_arm** with its case screws.
12. Set joint `arm_elbow_pitch` to zero (centre the servo first), then screw **arm_forearm** to the actuator output in **arm_upper_arm**; it moves -132° … 132°.
13. Mount the **DYNAMIXEL XM430-W350-T(R)** (arm_forearm_roll_actuator) in **arm_forearm** with its case screws.
14. Set joint `arm_forearm_roll` to zero (centre the servo first), then screw **arm_forearm_rotator** to the actuator output in **arm_forearm**; it moves -170° … 170°.
15. Mount the **DYNAMIXEL XM430-W350-T(R)** (arm_wrist_pitch_actuator) in **arm_forearm_rotator** with its case screws.
16. Set joint `arm_wrist_pitch` to zero (centre the servo first), then screw **arm_wrist** to the actuator output in **arm_forearm_rotator**; it moves -132° … 132°.
17. Mount the **DYNAMIXEL XM430-W350-T(R)** (arm_wrist_roll_actuator) in **arm_wrist** with its case screws.
18. Set joint `arm_wrist_roll` to zero (centre the servo first), then screw **arm_wrist_rotator** to the actuator output in **arm_wrist**; it moves -170° … 170°.
19. Mount the **DYNAMIXEL XM430-W350-T(R)** (arm_gripper_actuator) in **arm_wrist_rotator** with its case screws.
20. Set joint `arm_gripper` to zero (centre the servo first), then screw **arm_gripper_jaw** to the actuator output in **arm_wrist_rotator**; it moves -20° … 27°.
21. Set joint `left_rocker_pivot` to zero (centre the servo first), then screw **left_rocker** to the actuator output in **base_link**; it moves -20° … 20°.
22. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (left_front_motor) in **left_rocker** with its case screws.
23. Fit **left_front_wheel** on the output of the motor in **left_rocker** (driven joint `left_front_wheel_joint`).
24. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (left_rear_motor) in **left_rocker** with its case screws.
25. Fit **left_rear_wheel** on the output of the motor in **left_rocker** (driven joint `left_rear_wheel_joint`).
26. Bolt **left_rocker_rear_arm** to **left_rocker**.
27. Bolt **left_rocker_frame** to **left_rocker**.
28. Bolt **right_rocker** to **base_link**.
29. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (right_front_motor) in **right_rocker** with its case screws.
30. Fit **right_front_wheel** on the output of the motor in **right_rocker** (driven joint `right_front_wheel_joint`).
31. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (right_rear_motor) in **right_rocker** with its case screws.
32. Fit **right_rear_wheel** on the output of the motor in **right_rocker** (driven joint `right_rear_wheel_joint`).
33. Bolt **right_rocker_rear_arm** to **right_rocker**.
34. Bolt **right_rocker_frame** to **right_rocker**.
35. Mount the **LiPo 3S 5000 mAh 60C, XT60 (Gens Ace G-Tech)** (battery) in **base_link** with its case screws.
36. Bolt **battery_tray** to **base_link**.
37. Mount the **NVIDIA Jetson Orin Nano Super Developer Kit** (computer) in **base_link** with its case screws.
38. Bolt **computer_tray** to **base_link**.
39. Mount the **Cytron MDD10A dual-channel 10 A DC motor driver (5-30 V)** (motor_driver_1) in **base_link** with its case screws.
40. Bolt **motor_driver_1_tray** to **base_link**.
41. Mount the **Cytron MDD10A dual-channel 10 A DC motor driver (5-30 V)** (motor_driver_2) in **base_link** with its case screws.
42. Bolt **motor_driver_2_tray** to **base_link**.
43. Mount the **Waveshare Bus Servo Adapter (A)** (servo_bus) in **base_link** with its case screws.
44. Bolt **servo_bus_tray** to **base_link**.
45. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **base_link** with its case screws.
46. Bolt **regulator_5v_tray** to **base_link**.

## Fasteners

- 24 × M3 x 8 socket head (motor face)
- 2 × M8 x 40 shoulder bolt + spacer (rocker pivot)
- 4 × M4 x 20 + nut (rocker rear arm to hub)
- 1 × 20 mm hook-and-loop battery strap
- 12 × M3 x 8 socket head (tray to deck)
- 19 × M2.5 x 6 screws (board to standoffs)
- 2 × M3 x 6 (camera back)
- 4 × M5 x 12 socket head (base to bench)
- 24 × M2.5 x 6 case screws
- 48 × horn screws
- 3 × M5 x 16 socket head + M5 washer + M5 heat-set insert (clevis bearing axle)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
