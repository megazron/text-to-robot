# Printability — rover_arm

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 400 × 300 × 120 | ❌ |
| front_left_wheel | 120 × 120 × 40 | ✅ |
| front_right_wheel | 120 × 120 × 40 | ✅ |
| rear_left_wheel | 120 × 120 × 40 | ✅ |
| rear_right_wheel | 120 × 120 × 40 | ✅ |
| shoulder | 80 × 80 × 100 | ✅ |
| upper_arm | 80 × 80 × 250 | ❌ |
| forearm | 80 × 80 × 250 | ❌ |
| wrist_1 | 80 × 80 × 56 | ✅ |
| wrist_2 | 80 × 80 × 68 | ✅ |
| wrist_3 | 80 × 80 × 80 | ✅ |
| arm_mount | 120 × 120 × 120 | ✅ |
| gripper_base | 60 × 80 × 30 | ✅ |
| left_finger | 15 × 20 × 60 | ✅ |
| right_finger | 15 × 20 × 60 | ✅ |
| depth_1_link | 40 × 60 × 30 | ✅ |
| camera_1_link | 40 × 60 × 30 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **upper_arm**: longest dimension 250 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **forearm**: longest dimension 250 mm exceeds the 220 mm build volume — split the part or print diagonally
