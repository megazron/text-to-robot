# Print list: diff_drive_robot

12 parts, about 552 g of PETG and 50.3 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 244 × 200 × 6 | 249 | 22.7 | yes |
| left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| rear_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| battery_tray | 40.7 × 125.6 × 16.2 | 18 | 1.7 | yes |
| computer_tray | 59.2 × 90 × 7 | 15 | 1.4 | yes |
| motor_driver_1_tray | 64 × 87 × 7 | 16 | 1.4 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| electronics_enclosure | 234.5 × 190.8 × 45.1 | 75 | 6.8 | yes |
| electronics_lid | 208.5 × 180.6 × 5.4 | 62 | 5.6 | yes |
| front_camera_bracket | 15.3 × 36 × 45 | 16 | 1.5 | yes |
