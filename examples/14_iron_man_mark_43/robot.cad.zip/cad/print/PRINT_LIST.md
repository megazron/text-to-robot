# Print list — iron_man_mark_43

70 parts, about 3747 g of PETG and 341.5 h of printing.

Exact solids of these parts are in `cad/step/` (STEP AP214, millimetres): open them in Fusion, FreeCAD or Onshape to edit.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| helmet_faceplate | 135 × 92.9 × 246 | 89 | 8.1 | yes |
| helmet_cranium_1 | 120 × 100.3 × 140 | 57 | 5.2 | yes |
| helmet_cranium_2 | 121 × 119 × 131 | 94 | 8.6 | yes |
| helmet_cranium_3 | 120 × 100.3 × 140 | 57 | 5.2 | yes |
| helmet_cranium_4 | 121 × 119 × 131 | 95 | 8.7 | yes |
| helmet_cranium_5 | 114.6 × 100.2 × 140 | 32 | 2.9 | yes |
| helmet_cranium_6 | 115.7 × 119 × 131 | 52 | 4.7 | yes |
| helmet_cranium_7 | 114.6 × 100.2 × 140 | 32 | 2.9 | yes |
| helmet_cranium_8 | 115.9 × 119 × 131 | 51 | 4.6 | yes |
| chest_1 | 124 × 110.8 × 150 | 67 | 6.1 | yes |
| chest_2 | 100 × 108.5 × 140 | 50 | 4.5 | yes |
| chest_3 | 64.4 × 102.6 × 110 | 33 | 3.0 | yes |
| chest_4 | 17 × 100 × 150 | 41 | 3.8 | yes |
| chest_5 | 25.7 × 100 × 140 | 39 | 3.5 | yes |
| chest_6 | 18.3 × 100 × 110 | 30 | 2.8 | yes |
| chest_7 | 128.5 × 130.8 × 150 | 76 | 6.9 | yes |
| chest_8 | 104.2 × 128.5 × 140 | 57 | 5.2 | yes |
| chest_9 | 68.9 × 122.8 × 110 | 39 | 3.6 | yes |
| chest_10 | 124 × 110.8 × 150 | 67 | 6.1 | yes |
| chest_11 | 100 × 108.5 × 140 | 44 | 4.0 | yes |
| chest_12 | 37 × 64.1 × 110 | 19 | 1.7 | yes |
| chest_13 | 17 × 100 × 150 | 41 | 3.8 | yes |
| chest_14 | 25.7 × 100 × 140 | 39 | 3.5 | yes |
| chest_15 | 18 × 100 × 110 | 27 | 2.5 | yes |
| chest_16 | 128.5 × 130.8 × 150 | 76 | 6.9 | yes |
| chest_17 | 106.5 × 128.7 × 140 | 53 | 4.8 | yes |
| chest_18 | 41.3 × 84.1 × 110 | 25 | 2.3 | yes |
| electronics_box | 49.5 × 110 × 95 | 89 | 8.1 | yes |
| left_shoulder_bell_1 | 90 × 74.9 × 130 | 43 | 3.9 | yes |
| left_shoulder_bell_2 | 90 × 74.9 × 130 | 43 | 3.9 | yes |
| left_bicep_1 | 66 × 74 × 128 | 37 | 3.4 | yes |
| left_bicep_2 | 66 × 74 × 128 | 37 | 3.4 | yes |
| left_gauntlet_1 | 62 × 120.1 × 168 | 80 | 7.3 | yes |
| left_gauntlet_2 | 62 × 120.1 × 168 | 80 | 7.3 | yes |
| left_hand_armour_1 | 100.8 × 34.3 × 145 | 46 | 4.2 | yes |
| left_hand_armour_2 | 100.8 × 34.3 × 145 | 50 | 4.5 | yes |
| left_thigh_armour_1 | 93.2 × 120.3 × 120 | 53 | 4.9 | yes |
| left_thigh_armour_2 | 105.9 × 132.9 × 125 | 63 | 5.7 | yes |
| left_thigh_armour_3 | 93.2 × 120.3 × 120 | 53 | 4.9 | yes |
| left_thigh_armour_4 | 100.2 × 132.9 × 125 | 36 | 3.3 | yes |
| left_shin_armour_1 | 76.1 × 142.9 × 170 | 93 | 8.5 | yes |
| left_shin_armour_2 | 80.4 × 153.8 × 155 | 60 | 5.5 | yes |
| left_shin_armour_3 | 76.1 × 142.9 × 170 | 93 | 8.5 | yes |
| left_shin_armour_4 | 80.4 × 153.8 × 155 | 101 | 9.2 | yes |
| left_boot_1 | 145 × 22.6 × 62 | 26 | 2.4 | yes |
| left_boot_2 | 145 × 22.6 × 62 | 26 | 2.4 | yes |
| left_boot_3 | 135 × 65.1 × 62 | 32 | 2.9 | yes |
| left_boot_4 | 135 × 65.1 × 62 | 32 | 2.9 | yes |
| right_shoulder_bell_1 | 90 × 74.9 × 130 | 43 | 3.9 | yes |
| right_shoulder_bell_2 | 90 × 74.9 × 130 | 43 | 3.9 | yes |
| right_bicep_1 | 66 × 74 × 128 | 37 | 3.4 | yes |
| right_bicep_2 | 66 × 74 × 128 | 37 | 3.4 | yes |
| right_gauntlet_1 | 62 × 120.1 × 168 | 80 | 7.3 | yes |
| right_gauntlet_2 | 62 × 120.1 × 168 | 80 | 7.3 | yes |
| right_hand_armour_1 | 100.8 × 34.3 × 145 | 50 | 4.5 | yes |
| right_hand_armour_2 | 100.8 × 34.3 × 145 | 46 | 4.2 | yes |
| right_thigh_armour_1 | 93.2 × 120.3 × 120 | 53 | 4.9 | yes |
| right_thigh_armour_2 | 105.9 × 132.9 × 125 | 63 | 5.7 | yes |
| right_thigh_armour_3 | 93.2 × 120.3 × 120 | 53 | 4.9 | yes |
| right_thigh_armour_4 | 100.2 × 132.9 × 125 | 36 | 3.3 | yes |
| right_shin_armour_1 | 76.1 × 142.9 × 170 | 93 | 8.5 | yes |
| right_shin_armour_2 | 80.4 × 153.8 × 155 | 60 | 5.5 | yes |
| right_shin_armour_3 | 76.1 × 142.9 × 170 | 93 | 8.5 | yes |
| right_shin_armour_4 | 80.4 × 153.8 × 155 | 101 | 9.2 | yes |
| right_boot_1 | 145 × 22.6 × 62 | 26 | 2.4 | yes |
| right_boot_2 | 145 × 22.6 × 62 | 26 | 2.4 | yes |
| right_boot_3 | 135 × 65.1 × 62 | 32 | 2.9 | yes |
| right_boot_4 | 135 × 65.1 × 62 | 32 | 2.9 | yes |
| belt_1 | 112 × 182.5 × 85 | 52 | 4.7 | yes |
| belt_2 | 112 × 182.5 × 85 | 52 | 4.7 | yes |
