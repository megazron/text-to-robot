# Printability — iron_man_mark_43

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| pelvis_frame | 220 × 340 × 90 | ❌ |
| spine_frame | 50 × 80 × 504 | ❌ |
| backpack | 160 × 320 × 420 | ❌ |
| chest_plate | 20 × 280 × 240 | ❌ |
| shoulder_yoke | 60 × 530 × 60 | ❌ |
| left_hip_module | 130 × 130 × 90 | ✅ |
| left_thigh_strut | 55 × 40 × 428.7 | ❌ |
| left_thigh_cuff | 180 × 180 × 70 | ✅ |
| left_knee_module | 120 × 120 × 80 | ✅ |
| left_shank_strut | 50 × 35 × 430.5 | ❌ |
| left_shank_cuff | 146 × 146 × 70 | ✅ |
| left_ankle_module | 100 × 100 × 70 | ✅ |
| left_boot | 320 × 120 × 35 | ❌ |
| right_hip_module | 130 × 130 × 90 | ✅ |
| right_thigh_strut | 55 × 40 × 428.7 | ❌ |
| right_thigh_cuff | 180 × 180 × 70 | ✅ |
| right_knee_module | 120 × 120 × 80 | ✅ |
| right_shank_strut | 50 × 35 × 430.5 | ❌ |
| right_shank_cuff | 146 × 146 × 70 | ✅ |
| right_ankle_module | 100 × 100 × 70 | ✅ |
| right_boot | 320 × 120 × 35 | ❌ |
| left_shoulder_module | 110 × 110 × 80 | ✅ |
| left_upper_arm_strut | 40 × 35 × 325.5 | ❌ |
| left_upper_arm_cuff | 120 × 120 × 60 | ✅ |
| left_elbow_module | 90 × 90 × 70 | ✅ |
| left_forearm_strut | 35 × 30 × 255.5 | ❌ |
| left_forearm_cuff | 100 × 100 × 60 | ✅ |
| left_hand | 100 × 70 × 30 | ✅ |
| right_shoulder_module | 110 × 110 × 80 | ✅ |
| right_upper_arm_strut | 40 × 35 × 325.5 | ❌ |
| right_upper_arm_cuff | 120 × 120 × 60 | ✅ |
| right_elbow_module | 90 × 90 × 70 | ✅ |
| right_forearm_strut | 35 × 30 × 255.5 | ❌ |
| right_forearm_cuff | 100 × 100 × 60 | ✅ |
| right_hand | 100 × 70 × 30 | ✅ |
| helmet | 124.5 × 204 × 205 | ✅ |
| helmet_neck_collar | 191.2 × 175.3 × 37 | ✅ |
| helmet_left_ear_pod | 72 × 14 × 72 | ✅ |
| helmet_right_ear_pod | 72 × 14 × 72 | ✅ |
| helmet_crown_panel | 116.5 × 174 × 45.8 | ✅ |
| faceplate | 61.9 × 158.5 × 216 | ✅ |
| forehead_plate | 34.9 × 85.9 × 33.6 | ✅ |
| mouth_line | 12.8 × 80 × 4 | ✅ |
| left_eye_socket | 25.4 × 59 × 29 | ✅ |
| left_eye_lens | 13 × 49 × 14 | ✅ |
| left_cheek_panel | 149.7 × 82.3 × 216 | ✅ |
| right_eye_socket | 25.4 × 59 × 29 | ✅ |
| right_eye_lens | 13 × 49 × 14 | ✅ |
| right_cheek_panel | 149.7 × 82.3 × 216 | ✅ |
| chin_guard | 94.6 × 177.7 × 37.9 | ✅ |
| neck_ring | 160 × 160 × 25 | ✅ |
| collar_plate | 28.6 × 303.5 × 65 | ❌ |
| left_chest_door | 102.3 × 228.3 × 310 | ❌ |
| left_pectoral_trim | 12.7 × 194.9 × 137.2 | ✅ |
| right_chest_door | 102.3 × 228.3 × 310 | ❌ |
| right_pectoral_trim | 12.7 × 194.9 × 137.2 | ✅ |
| chest_centre | 8.7 × 134.2 × 220 | ✅ |
| arc_reactor_housing | 70 × 70 × 8 | ✅ |
| arc_reactor | 54 × 54 × 5 | ✅ |
| ab_plate_1 | 24 × 236.3 × 69 | ❌ |
| ab_plate_2 | 21.2 × 220 × 69 | ✅ |
| ab_plate_3 | 18.6 × 203.3 × 69 | ✅ |
| left_lat_plate | 24.3 × 291.9 × 180 | ❌ |
| right_lat_plate | 24.3 × 291.9 × 180 | ❌ |
| back_shell | 30.2 × 367.6 × 460 | ❌ |
| left_flight_flap | 7.4 × 117 × 176.4 | ✅ |
| left_back_vent | 60 × 60 × 12 | ✅ |
| right_flight_flap | 7.4 × 117 × 176.4 | ✅ |
| right_back_vent | 60 × 60 × 12 | ✅ |
| belt_plate | 29 × 334.6 × 75 | ❌ |
| rear_belt_plate | 29 × 334.6 × 75 | ❌ |
| codpiece | 18.7 × 124.7 × 140 | ✅ |
| left_rib_0 | 6.5 × 94.2 × 82 | ✅ |
| left_rib_1 | 6.5 × 94.2 × 82 | ✅ |
| left_rib_2 | 6.5 × 94.2 × 82 | ✅ |
| left_chest_inlay | 6.5 × 81 × 145 | ✅ |
| right_rib_0 | 6.5 × 94.2 × 82 | ✅ |
| right_rib_1 | 6.5 × 94.2 × 82 | ✅ |
| right_rib_2 | 6.5 × 94.2 × 82 | ✅ |
| right_chest_inlay | 6.5 × 81 × 145 | ✅ |
| left_pauldron | 224 × 208 × 125.9 | ❌ |
| left_pauldron_edge | 10.8 × 86.9 × 29.9 | ✅ |
| left_bicep_sleeve | 149.7 × 138.1 × 266.9 | ❌ |
| left_bicep_clamshell | 111.6 × 43.6 × 266.9 | ❌ |
| left_elbow_cap | 110 × 110 × 40.7 | ✅ |
| left_gauntlet_sleeve | 136.4 × 125.9 × 222.3 | ❌ |
| left_gauntlet_clamshell | 101.7 × 44.1 × 222.3 | ❌ |
| left_gauntlet_stripe | 4.1 × 29.3 × 100 | ✅ |
| left_gauntlet_hatch | 5.4 × 43.6 × 40 | ✅ |
| left_hand_plate | 14.3 × 83.9 × 119.8 | ✅ |
| left_palm_repulsor | 52 × 52 × 8 | ✅ |
| left_finger_1 | 12 × 17.9 × 71.9 | ✅ |
| left_finger_2 | 12 × 17.9 × 71.9 | ✅ |
| left_finger_3 | 12 × 17.9 × 71.9 | ✅ |
| left_finger_4 | 12 × 17.9 × 71.9 | ✅ |
| left_thumb | 12 × 19.8 × 59.9 | ✅ |
| right_pauldron | 224 × 208 × 125.9 | ❌ |
| right_pauldron_edge | 10.8 × 86.9 × 29.9 | ✅ |
| right_bicep_sleeve | 149.7 × 138.1 × 266.9 | ❌ |
| right_bicep_clamshell | 111.6 × 43.7 × 266.9 | ❌ |
| right_elbow_cap | 110 × 110 × 40.7 | ✅ |
| right_gauntlet_sleeve | 136.4 × 125.9 × 222.3 | ❌ |
| right_gauntlet_clamshell | 101.7 × 44.1 × 222.3 | ❌ |
| right_gauntlet_stripe | 4.1 × 29.3 × 100 | ✅ |
| right_gauntlet_hatch | 5.4 × 43.6 × 40 | ✅ |
| right_hand_plate | 14.3 × 83.9 × 119.8 | ✅ |
| right_palm_repulsor | 52 × 52 × 8 | ✅ |
| right_finger_1 | 12 × 17.9 × 71.9 | ✅ |
| right_finger_2 | 12 × 17.9 × 71.9 | ✅ |
| right_finger_3 | 12 × 17.9 × 71.9 | ✅ |
| right_finger_4 | 12 × 17.9 × 71.9 | ✅ |
| right_thumb | 12 × 19.8 × 59.9 | ✅ |
| left_hip_flap | 17.8 × 133.5 × 149.7 | ✅ |
| left_thigh_shell | 222.6 × 203.3 × 377.3 | ❌ |
| left_thigh_clamshell | 165.9 × 68.5 × 377.3 | ❌ |
| left_knee_cap | 20 × 117.3 × 145 | ✅ |
| left_shin_shell | 185.1 × 170.7 × 378.8 | ❌ |
| left_calf_clamshell | 138 × 60.4 × 378.8 | ❌ |
| left_shin_stripe | 8.5 × 74.1 × 220 | ✅ |
| left_thigh_stripe | 10.4 × 139.8 × 275 | ❌ |
| left_shin_guard | 13.2 × 91 × 100 | ✅ |
| left_boot_toe | 338 × 158 × 151.3 | ❌ |
| left_boot_trim | 8.9 × 70 × 80 | ✅ |
| left_heel_thruster | 56 × 56 × 30 | ✅ |
| left_thruster_cover | 10.8 × 76.3 × 69.9 | ✅ |
| left_ankle_flap | 8.6 × 57.1 × 79.8 | ✅ |
| right_hip_flap | 17.8 × 133.5 × 149.7 | ✅ |
| right_thigh_shell | 222.6 × 203.3 × 377.3 | ❌ |
| right_thigh_clamshell | 165.9 × 68.6 × 377.3 | ❌ |
| right_knee_cap | 20 × 117.3 × 145 | ✅ |
| right_shin_shell | 185.1 × 170.7 × 378.8 | ❌ |
| right_calf_clamshell | 138 × 60.4 × 378.8 | ❌ |
| right_shin_stripe | 8.5 × 74.1 × 220 | ✅ |
| right_thigh_stripe | 10.4 × 139.8 × 275 | ❌ |
| right_shin_guard | 13.2 × 91 × 100 | ✅ |
| right_boot_toe | 338 × 158 × 151.3 | ❌ |
| right_boot_trim | 8.9 × 70 × 80 | ✅ |
| right_heel_thruster | 56 × 56 × 30 | ✅ |
| right_thruster_cover | 10.8 × 76.3 × 69.9 | ✅ |
| right_ankle_flap | 8.6 × 57.1 × 79.8 | ✅ |
| left_clavicle_cover | 6.4 × 93.9 × 75 | ✅ |
| left_back_scapula | 13.5 × 155.2 × 176.4 | ✅ |
| left_back_grille_0 | 5.5 × 99.4 × 12 | ✅ |
| left_back_grille_1 | 5.5 × 99.4 × 12 | ✅ |
| left_back_grille_2 | 5.5 × 99.4 × 12 | ✅ |
| left_hip_cowl | 174.4 × 169.3 × 100 | ✅ |
| left_hip_outer_plate | 9.6 × 121 × 160 | ✅ |
| left_thigh_ridge | 4.9 × 63.4 × 220 | ✅ |
| left_thigh_edge | 3 × 13.7 × 204.6 | ✅ |
| left_shin_ridge | 4.5 × 45.9 × 230 | ❌ |
| left_shin_edge | 3 × 13.4 × 213.9 | ✅ |
| left_knee_bezel | 7.7 × 88.8 × 115 | ✅ |
| left_knee_face | 7.3 × 76 × 90 | ✅ |
| left_knee_motor_cover | 126 × 126 × 9 | ✅ |
| left_ankle_motor_cover | 106 × 106 × 9 | ✅ |
| left_elbow_motor_cover | 96 × 96 × 9 | ✅ |
| left_bicep_front | 5.4 × 67.5 × 170 | ✅ |
| left_forearm_crest | 7.9 × 78.4 × 190 | ✅ |
| right_clavicle_cover | 6.4 × 93.9 × 75 | ✅ |
| right_back_scapula | 13.5 × 155.2 × 176.4 | ✅ |
| right_back_grille_0 | 5.5 × 99.4 × 12 | ✅ |
| right_back_grille_1 | 5.5 × 99.4 × 12 | ✅ |
| right_back_grille_2 | 5.5 × 99.4 × 12 | ✅ |
| right_hip_cowl | 174.4 × 169.3 × 100 | ✅ |
| right_hip_outer_plate | 9.6 × 121 × 160 | ✅ |
| right_thigh_ridge | 4.9 × 63.4 × 220 | ✅ |
| right_thigh_edge | 3 × 13.7 × 204.6 | ✅ |
| right_shin_ridge | 4.5 × 45.9 × 230 | ❌ |
| right_shin_edge | 3 × 13.4 × 213.9 | ✅ |
| right_knee_bezel | 7.7 × 88.8 × 115 | ✅ |
| right_knee_face | 7.3 × 76 × 90 | ✅ |
| right_knee_motor_cover | 126 × 126 × 9 | ✅ |
| right_ankle_motor_cover | 106 × 106 × 9 | ✅ |
| right_elbow_motor_cover | 96 × 96 × 9 | ✅ |
| right_bicep_front | 5.4 × 67.5 × 170 | ✅ |
| right_forearm_crest | 7.9 × 78.4 × 190 | ✅ |
| left_rib_edge_0 | 3.8 × 68.6 × 58 | ✅ |
| left_rib_insert_0 | 2.7 × 50.8 × 41 | ✅ |
| left_rib_edge_1 | 3.8 × 68.6 × 58 | ✅ |
| left_rib_insert_1 | 2.7 × 50.8 × 41 | ✅ |
| left_rib_edge_2 | 3.8 × 68.6 × 58 | ✅ |
| left_rib_insert_2 | 2.7 × 50.8 × 41 | ✅ |
| left_collar_inlay | 4.5 × 94.5 × 41 | ✅ |
| left_finger_1_knuckle_0 | 3 × 14 × 12 | ✅ |
| left_finger_1_knuckle_1 | 3 × 14 × 12 | ✅ |
| left_finger_2_knuckle_0 | 3 × 14 × 12 | ✅ |
| left_finger_2_knuckle_1 | 3 × 14 × 12 | ✅ |
| left_finger_3_knuckle_0 | 3 × 14 × 12 | ✅ |
| left_finger_3_knuckle_1 | 3 × 14 × 12 | ✅ |
| left_finger_4_knuckle_0 | 3 × 14 × 12 | ✅ |
| left_finger_4_knuckle_1 | 3 × 14 × 12 | ✅ |
| right_rib_edge_0 | 3.8 × 68.6 × 58 | ✅ |
| right_rib_insert_0 | 2.7 × 50.8 × 41 | ✅ |
| right_rib_edge_1 | 3.8 × 68.6 × 58 | ✅ |
| right_rib_insert_1 | 2.7 × 50.8 × 41 | ✅ |
| right_rib_edge_2 | 3.8 × 68.6 × 58 | ✅ |
| right_rib_insert_2 | 2.7 × 50.8 × 41 | ✅ |
| right_collar_inlay | 4.5 × 94.5 × 41 | ✅ |
| right_finger_1_knuckle_0 | 3 × 14 × 12 | ✅ |
| right_finger_1_knuckle_1 | 3 × 14 × 12 | ✅ |
| right_finger_2_knuckle_0 | 3 × 14 × 12 | ✅ |
| right_finger_2_knuckle_1 | 3 × 14 × 12 | ✅ |
| right_finger_3_knuckle_0 | 3 × 14 × 12 | ✅ |
| right_finger_3_knuckle_1 | 3 × 14 × 12 | ✅ |
| right_finger_4_knuckle_0 | 3 × 14 × 12 | ✅ |
| right_finger_4_knuckle_1 | 3 × 14 × 12 | ✅ |
| left_chest_door_moving_knuckle | 11 × 11 × 9 | ✅ |
| left_chest_door_fixed_knuckle_lower | 11 × 11 × 9 | ✅ |
| left_chest_door_fixed_knuckle_upper | 11 × 11 × 9 | ✅ |
| left_chest_door_hinge_pin | 3 × 3 × 34 | ✅ |
| right_chest_door_moving_knuckle | 11 × 11 × 9 | ✅ |
| right_chest_door_fixed_knuckle_lower | 11 × 11 × 9 | ✅ |
| right_chest_door_fixed_knuckle_upper | 11 × 11 × 9 | ✅ |
| right_chest_door_hinge_pin | 3 × 3 × 34 | ✅ |
| left_lat_plate_moving_knuckle | 11 × 11 × 9 | ✅ |
| left_lat_plate_fixed_knuckle_lower | 11 × 11 × 9 | ✅ |
| left_lat_plate_fixed_knuckle_upper | 11 × 11 × 9 | ✅ |
| left_lat_plate_hinge_pin | 3 × 3 × 34 | ✅ |
| right_lat_plate_moving_knuckle | 11 × 11 × 9 | ✅ |
| right_lat_plate_fixed_knuckle_lower | 11 × 11 × 9 | ✅ |
| right_lat_plate_fixed_knuckle_upper | 11 × 11 × 9 | ✅ |
| right_lat_plate_hinge_pin | 3 × 3 × 34 | ✅ |
| left_gauntlet_clamshell_moving_knuckle | 11 × 11 × 9 | ✅ |
| left_gauntlet_clamshell_fixed_knuckle_lower | 11 × 11 × 9 | ✅ |
| left_gauntlet_clamshell_fixed_knuckle_upper | 11 × 11 × 9 | ✅ |
| left_gauntlet_clamshell_hinge_pin | 3 × 3 × 34 | ✅ |
| right_gauntlet_clamshell_moving_knuckle | 11 × 11 × 9 | ✅ |
| right_gauntlet_clamshell_fixed_knuckle_lower | 11 × 11 × 9 | ✅ |
| right_gauntlet_clamshell_fixed_knuckle_upper | 11 × 11 × 9 | ✅ |
| right_gauntlet_clamshell_hinge_pin | 3 × 3 × 34 | ✅ |
| left_thigh_clamshell_moving_knuckle | 11 × 11 × 9 | ✅ |
| left_thigh_clamshell_fixed_knuckle_lower | 11 × 11 × 9 | ✅ |
| left_thigh_clamshell_fixed_knuckle_upper | 11 × 11 × 9 | ✅ |
| left_thigh_clamshell_hinge_pin | 3 × 3 × 34 | ✅ |
| right_thigh_clamshell_moving_knuckle | 11 × 11 × 9 | ✅ |
| right_thigh_clamshell_fixed_knuckle_lower | 11 × 11 × 9 | ✅ |
| right_thigh_clamshell_fixed_knuckle_upper | 11 × 11 × 9 | ✅ |
| right_thigh_clamshell_hinge_pin | 3 × 3 × 34 | ✅ |

## Notes
- ⚠️ **pelvis_frame**: longest dimension 340 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **spine_frame**: longest dimension 504 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **backpack**: longest dimension 420 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **chest_plate**: longest dimension 280 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **shoulder_yoke**: longest dimension 530 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_thigh_strut**: longest dimension 428.7 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_shank_strut**: longest dimension 430.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_boot**: longest dimension 320 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_thigh_strut**: longest dimension 428.7 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_shank_strut**: longest dimension 430.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_boot**: longest dimension 320 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_upper_arm_strut**: longest dimension 325.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_forearm_strut**: longest dimension 255.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_upper_arm_strut**: longest dimension 325.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_forearm_strut**: longest dimension 255.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **collar_plate**: longest dimension 303.5 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_chest_door**: longest dimension 310 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_chest_door**: longest dimension 310 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **ab_plate_1**: longest dimension 236.3 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_lat_plate**: longest dimension 291.9 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_lat_plate**: longest dimension 291.9 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **back_shell**: longest dimension 460 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **belt_plate**: longest dimension 334.6 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **rear_belt_plate**: longest dimension 334.6 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_pauldron**: longest dimension 224 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_bicep_sleeve**: longest dimension 266.9 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_bicep_clamshell**: longest dimension 266.9 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_gauntlet_sleeve**: longest dimension 222.3 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_gauntlet_clamshell**: longest dimension 222.3 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_pauldron**: longest dimension 224 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_bicep_sleeve**: longest dimension 266.9 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_bicep_clamshell**: longest dimension 266.9 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_gauntlet_sleeve**: longest dimension 222.3 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_gauntlet_clamshell**: longest dimension 222.3 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_thigh_shell**: longest dimension 377.3 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_thigh_clamshell**: longest dimension 377.3 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_shin_shell**: longest dimension 378.8 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_calf_clamshell**: longest dimension 378.8 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_thigh_stripe**: longest dimension 275 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_boot_toe**: longest dimension 338 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_thigh_shell**: longest dimension 377.3 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_thigh_clamshell**: longest dimension 377.3 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_shin_shell**: longest dimension 378.8 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_calf_clamshell**: longest dimension 378.8 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_thigh_stripe**: longest dimension 275 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_boot_toe**: longest dimension 338 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_shin_ridge**: longest dimension 230 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_shin_ridge**: longest dimension 230 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_rib_insert_0**: thinnest dimension 2.7 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **left_rib_insert_1**: thinnest dimension 2.7 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **left_rib_insert_2**: thinnest dimension 2.7 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_rib_insert_0**: thinnest dimension 2.7 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_rib_insert_1**: thinnest dimension 2.7 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_rib_insert_2**: thinnest dimension 2.7 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
