# Fabricated parts — iron_man_mark_43

Not printed: made from sheet, tube or fabric (see BOM.md for the exact item and cost). Each STL is the finished shape; plates are 2D-cut from it (export the top face as DXF for laser or waterjet cutting).

| Part | Material | Mass (g) |
|---|---|--:|
| left_mech_shoulder_0 | armour_mech | 125 |
| right_mech_shoulder_0 | armour_mech | 125 |
| left_mech_elbow_0 | armour_mech | 73 |
| right_mech_elbow_0 | armour_mech | 73 |
| left_mech_wrist_0 | armour_mech | 37 |
| right_mech_wrist_0 | armour_mech | 37 |
| left_mech_hip_0 | armour_mech | 106 |
| right_mech_hip_0 | armour_mech | 106 |
| left_mech_knee_0 | armour_mech | 89 |
| right_mech_knee_0 | armour_mech | 89 |
| left_mech_ankle_0 | armour_mech | 41 |
| left_mech_ankle_0p1 | armour_mech | 26 |
| right_mech_ankle_0 | armour_mech | 41 |
| right_mech_ankle_0p1 | armour_mech | 26 |
