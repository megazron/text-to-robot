# Fabricated parts: iron_man_mark_43

Not printed: made from sheet, tube or fabric (see BOM.md for the exact item and cost). Each STL is the finished shape; plates are 2D-cut from it (export the top face as DXF for laser or waterjet cutting).

| Part | Material | Mass (g) |
|---|---|--:|
| left_mech_shoulder_0 | armour_mech | 62 |
| right_mech_shoulder_0 | armour_mech | 62 |
| left_mech_shoulder_1 | armour_mech | 63 |
| right_mech_shoulder_1 | armour_mech | 63 |
| left_mech_elbow_0 | armour_mech | 57 |
| right_mech_elbow_0 | armour_mech | 57 |
| left_mech_elbow_1 | armour_mech | 8 |
| left_mech_elbow_1p1 | armour_mech | 3 |
| right_mech_elbow_1 | armour_mech | 8 |
| right_mech_elbow_1p1 | armour_mech | 3 |
| left_mech_elbow_2 | armour_mech | 4 |
| right_mech_elbow_2 | armour_mech | 4 |
| left_mech_wrist_0 | armour_mech | 37 |
| right_mech_wrist_0 | armour_mech | 37 |
| left_mech_hip_0 | armour_mech | 40 |
| left_mech_hip_0p1 | armour_mech | 26 |
| right_mech_hip_0 | armour_mech | 40 |
| right_mech_hip_0p1 | armour_mech | 26 |
| left_mech_hip_1 | armour_mech | 21 |
| left_mech_hip_1p1 | armour_mech | 19 |
| right_mech_hip_1 | armour_mech | 21 |
| right_mech_hip_1p1 | armour_mech | 19 |
| left_mech_hip_2 | armour_mech | 2 |
| right_mech_hip_2 | armour_mech | 2 |
| left_mech_knee_0 | armour_mech | 8 |
| left_mech_knee_0p1 | armour_mech | 4 |
| right_mech_knee_0 | armour_mech | 8 |
| right_mech_knee_0p1 | armour_mech | 4 |
| left_mech_knee_1 | armour_mech | 4 |
| right_mech_knee_1 | armour_mech | 4 |
| left_mech_knee_2 | armour_mech | 73 |
| right_mech_knee_2 | armour_mech | 73 |
| left_mech_ankle_0 | armour_mech | 40 |
| left_mech_ankle_0p1 | armour_mech | 26 |
| left_mech_ankle_0p2 | armour_mech | 2 |
| right_mech_ankle_0 | armour_mech | 40 |
| right_mech_ankle_0p1 | armour_mech | 26 |
| right_mech_ankle_0p2 | armour_mech | 2 |
