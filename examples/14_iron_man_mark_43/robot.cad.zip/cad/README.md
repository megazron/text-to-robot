# Build package — iron_man_mark_43

Iron Man Mark 43 (full wearable suit): 362 printed pieces, 8.6 kg filament, motorised faceplate, $528 incl. filament

1. **Buy** everything in `BOM.md` (supplier links included).
2. **Print** every STL in `print/` (see `print/PRINT_LIST.md`).
3. **Assemble** in the order of `ASSEMBLY.md`.
   **Wire** from `WIRING.md` (pin-to-pin table, cut list, power budget) and `wiring.svg`.
4. **Check** against `design.json`: each actuator's required vs rated torque, the speed it reaches loaded, battery runtime, stability and every other check the design passed.

`reference/` holds the bought parts' models (from their datasheet drawings) for your own CAD; `iron_man_mark_43_assembly.stl` is the whole robot in its build pose.

## Assumptions

- armour shape from: suit: designed directly by scripts/forge_mark43.py from reference photos of the movie suit; 3 mm walls, 2 mm faceplate, 15 % gyroid infill (shells are mostly walls)
- filament at $22/kg, 8 % waste
- the suit is worn armour over a black undersuit: the wearer moves every joint; nothing powers the limbs (hobby servos cannot move a person); the servos only open and close the doors
- the wearer is an average adult male body at 1.75 m and the pieces scale evenly with height; check against your own measurements before printing
- gaps at the groin, armpits and elbows are cut on purpose so the joints move; the undersuit shows through them, as on real builds
- cable channels are 7 to 10 mm deep on the inside of the shells and the latch servos stand up to 31 mm off them: there is no body model, so their room against a real wearer is not checked; fit the suit before bonding them
- NOTHING HERE HAS BEEN BUILT OR TESTED. Door torques, the clutch setting, pawl strength and pinch force are calculations with estimated inputs; none has been measured on hardware
- gloves and boots are not part of the opening: their mouths are smaller than a hand or a foot, so they are put on separately and are not designed to come on through the suit
