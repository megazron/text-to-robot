// concept part: right_shin_shell (armor)
// units: mm. Mesh with: openscad -o right_shin_shell.stl right_shin_shell.scad
import("../stl/parts/right_shin_shell.stl");
