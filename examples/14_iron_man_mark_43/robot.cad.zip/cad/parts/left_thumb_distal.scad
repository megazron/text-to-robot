// concept part: left_thumb_distal (armor)
// units: mm. Mesh with: openscad -o left_thumb_distal.stl left_thumb_distal.scad
import("../stl/parts/left_thumb_distal.stl");
