// concept part: shoulder_yoke (link)
// units: mm. Mesh with: openscad -o shoulder_yoke.stl shoulder_yoke.scad
multmatrix([[1, 0, 0, -60], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cube([60, 530, 60], center=true);
