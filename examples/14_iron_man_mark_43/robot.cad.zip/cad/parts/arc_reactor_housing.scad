// concept part: arc_reactor_housing (armor)
// units: mm. Mesh with: openscad -o arc_reactor_housing.stl arc_reactor_housing.scad
import("../stl/parts/arc_reactor_housing.stl");
