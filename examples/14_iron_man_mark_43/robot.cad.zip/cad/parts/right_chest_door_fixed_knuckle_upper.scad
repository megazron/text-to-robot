// concept part: right_chest_door_fixed_knuckle_upper (armor)
// units: mm. Mesh with: openscad -o right_chest_door_fixed_knuckle_upper.stl right_chest_door_fixed_knuckle_upper.scad
import("../stl/parts/right_chest_door_fixed_knuckle_upper.stl");
