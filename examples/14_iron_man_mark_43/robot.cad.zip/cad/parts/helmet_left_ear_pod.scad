// concept part: helmet_left_ear_pod (armor)
// units: mm. Mesh with: openscad -o helmet_left_ear_pod.stl helmet_left_ear_pod.scad
import("../stl/parts/helmet_left_ear_pod.stl");
