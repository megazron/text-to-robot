// concept part: left_gauntlet_clamshell (armor)
// units: mm. Mesh with: openscad -o left_gauntlet_clamshell.stl left_gauntlet_clamshell.scad
import("../stl/parts/left_gauntlet_clamshell.stl");
