// concept part: right_shin_guard (armor)
// units: mm. Mesh with: openscad -o right_shin_guard.stl right_shin_guard.scad
import("../stl/parts/right_shin_guard.stl");
