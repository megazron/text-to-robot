// concept part: right_knee_face (armor)
// units: mm. Mesh with: openscad -o right_knee_face.stl right_knee_face.scad
import("../stl/parts/right_knee_face.stl");
