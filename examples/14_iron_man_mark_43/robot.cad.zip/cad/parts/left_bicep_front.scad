// concept part: left_bicep_front (armor)
// units: mm. Mesh with: openscad -o left_bicep_front.stl left_bicep_front.scad
import("../stl/parts/left_bicep_front.stl");
