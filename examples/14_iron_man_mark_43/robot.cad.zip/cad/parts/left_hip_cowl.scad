// concept part: left_hip_cowl (armor)
// units: mm. Mesh with: openscad -o left_hip_cowl.stl left_hip_cowl.scad
import("../stl/parts/left_hip_cowl.stl");
