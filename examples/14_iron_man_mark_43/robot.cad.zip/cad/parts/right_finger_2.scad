// concept part: right_finger_2 (armor)
// units: mm. Mesh with: openscad -o right_finger_2.stl right_finger_2.scad
import("../stl/parts/right_finger_2.stl");
