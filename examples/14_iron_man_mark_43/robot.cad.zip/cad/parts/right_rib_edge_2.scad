// concept part: right_rib_edge_2 (armor)
// units: mm. Mesh with: openscad -o right_rib_edge_2.stl right_rib_edge_2.scad
import("../stl/parts/right_rib_edge_2.stl");
