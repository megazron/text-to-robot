// concept part: arc_reactor (armor)
// units: mm. Mesh with: openscad -o arc_reactor.stl arc_reactor.scad
import("../stl/parts/arc_reactor.stl");
