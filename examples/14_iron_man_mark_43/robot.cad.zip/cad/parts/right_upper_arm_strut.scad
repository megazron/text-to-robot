// concept part: right_upper_arm_strut (upper_arm)
// units: mm. Mesh with: openscad -o right_upper_arm_strut.stl right_upper_arm_strut.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -162.75], [0, 0, 0, 1]])
  cube([40, 35, 325.5], center=true);
