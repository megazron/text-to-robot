// concept part: right_finger_2_knuckle_1 (armor)
// units: mm. Mesh with: openscad -o right_finger_2_knuckle_1.stl right_finger_2_knuckle_1.scad
import("../stl/parts/right_finger_2_knuckle_1.stl");
