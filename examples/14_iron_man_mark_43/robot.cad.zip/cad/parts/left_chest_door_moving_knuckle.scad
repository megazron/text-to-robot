// concept part: left_chest_door_moving_knuckle (armor)
// units: mm. Mesh with: openscad -o left_chest_door_moving_knuckle.stl left_chest_door_moving_knuckle.scad
import("../stl/parts/left_chest_door_moving_knuckle.stl");
