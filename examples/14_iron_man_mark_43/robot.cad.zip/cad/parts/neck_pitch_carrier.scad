// concept part: neck_pitch_carrier (link)
// units: mm. Mesh with: openscad -o neck_pitch_carrier.stl neck_pitch_carrier.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=10, r=28, center=true, $fn=48);
