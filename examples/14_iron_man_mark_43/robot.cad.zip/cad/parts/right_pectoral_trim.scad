// concept part: right_pectoral_trim (armor)
// units: mm. Mesh with: openscad -o right_pectoral_trim.stl right_pectoral_trim.scad
import("../stl/parts/right_pectoral_trim.stl");
