// concept part: right_thigh_ridge (armor)
// units: mm. Mesh with: openscad -o right_thigh_ridge.stl right_thigh_ridge.scad
import("../stl/parts/right_thigh_ridge.stl");
