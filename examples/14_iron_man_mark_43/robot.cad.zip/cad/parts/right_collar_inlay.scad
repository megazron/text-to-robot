// concept part: right_collar_inlay (armor)
// units: mm. Mesh with: openscad -o right_collar_inlay.stl right_collar_inlay.scad
import("../stl/parts/right_collar_inlay.stl");
