// concept part: helmet_crown_panel (armor)
// units: mm. Mesh with: openscad -o helmet_crown_panel.stl helmet_crown_panel.scad
import("../stl/parts/helmet_crown_panel.stl");
