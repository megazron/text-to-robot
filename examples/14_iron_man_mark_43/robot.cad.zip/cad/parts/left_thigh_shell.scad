// concept part: left_thigh_shell (armor)
// units: mm. Mesh with: openscad -o left_thigh_shell.stl left_thigh_shell.scad
import("../stl/parts/left_thigh_shell.stl");
