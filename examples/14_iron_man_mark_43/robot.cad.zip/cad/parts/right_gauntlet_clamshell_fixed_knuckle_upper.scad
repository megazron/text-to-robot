// concept part: right_gauntlet_clamshell_fixed_knuckle_upper (armor)
// units: mm. Mesh with: openscad -o right_gauntlet_clamshell_fixed_knuckle_upper.stl right_gauntlet_clamshell_fixed_knuckle_upper.scad
import("../stl/parts/right_gauntlet_clamshell_fixed_knuckle_upper.stl");
