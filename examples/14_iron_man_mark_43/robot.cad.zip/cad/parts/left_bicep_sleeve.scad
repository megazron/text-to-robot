// concept part: left_bicep_sleeve (armor)
// units: mm. Mesh with: openscad -o left_bicep_sleeve.stl left_bicep_sleeve.scad
import("../stl/parts/left_bicep_sleeve.stl");
