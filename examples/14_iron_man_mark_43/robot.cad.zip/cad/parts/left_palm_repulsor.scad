// concept part: left_palm_repulsor (armor)
// units: mm. Mesh with: openscad -o left_palm_repulsor.stl left_palm_repulsor.scad
import("../stl/parts/left_palm_repulsor.stl");
