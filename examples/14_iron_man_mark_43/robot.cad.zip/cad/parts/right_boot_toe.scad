// concept part: right_boot_toe (armor)
// units: mm. Mesh with: openscad -o right_boot_toe.stl right_boot_toe.scad
import("../stl/parts/right_boot_toe.stl");
