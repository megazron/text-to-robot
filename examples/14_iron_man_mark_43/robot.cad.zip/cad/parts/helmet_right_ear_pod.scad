// concept part: helmet_right_ear_pod (armor)
// units: mm. Mesh with: openscad -o helmet_right_ear_pod.stl helmet_right_ear_pod.scad
import("../stl/parts/helmet_right_ear_pod.stl");
