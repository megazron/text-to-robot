// concept part: right_hip_module (link)
// units: mm. Mesh with: openscad -o right_hip_module.stl right_hip_module.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, -45], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=90, r=65, center=true, $fn=48);
