// concept part: left_lat_plate_fixed_knuckle_lower (armor)
// units: mm. Mesh with: openscad -o left_lat_plate_fixed_knuckle_lower.stl left_lat_plate_fixed_knuckle_lower.scad
import("../stl/parts/left_lat_plate_fixed_knuckle_lower.stl");
