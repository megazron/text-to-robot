// concept part: left_bicep_clamshell (armor)
// units: mm. Mesh with: openscad -o left_bicep_clamshell.stl left_bicep_clamshell.scad
import("../stl/parts/left_bicep_clamshell.stl");
