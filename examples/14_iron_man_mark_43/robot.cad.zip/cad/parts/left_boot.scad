// concept part: left_boot (link)
// units: mm. Mesh with: openscad -o left_boot.stl left_boot.scad
multmatrix([[1, 0, 0, 20], [0, 1, 0, -45], [0, 0, 1, -87.5], [0, 0, 0, 1]])
  cube([320, 120, 35], center=true);
