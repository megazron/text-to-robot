// concept part: left_forearm_crest (armor)
// units: mm. Mesh with: openscad -o left_forearm_crest.stl left_forearm_crest.scad
import("../stl/parts/left_forearm_crest.stl");
