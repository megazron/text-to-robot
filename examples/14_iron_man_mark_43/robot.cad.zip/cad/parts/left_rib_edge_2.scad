// concept part: left_rib_edge_2 (armor)
// units: mm. Mesh with: openscad -o left_rib_edge_2.stl left_rib_edge_2.scad
import("../stl/parts/left_rib_edge_2.stl");
