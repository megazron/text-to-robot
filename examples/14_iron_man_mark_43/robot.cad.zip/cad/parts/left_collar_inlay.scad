// concept part: left_collar_inlay (armor)
// units: mm. Mesh with: openscad -o left_collar_inlay.stl left_collar_inlay.scad
import("../stl/parts/left_collar_inlay.stl");
