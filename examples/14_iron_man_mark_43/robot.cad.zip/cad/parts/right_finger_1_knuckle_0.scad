// concept part: right_finger_1_knuckle_0 (armor)
// units: mm. Mesh with: openscad -o right_finger_1_knuckle_0.stl right_finger_1_knuckle_0.scad
import("../stl/parts/right_finger_1_knuckle_0.stl");
