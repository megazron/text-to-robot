// concept part: collar_plate (armor)
// units: mm. Mesh with: openscad -o collar_plate.stl collar_plate.scad
import("../stl/parts/collar_plate.stl");
