// concept part: left_finger_1_knuckle (armor)
// units: mm. Mesh with: openscad -o left_finger_1_knuckle.stl left_finger_1_knuckle.scad
import("../stl/parts/left_finger_1_knuckle.stl");
