// concept part: left_lat_plate_fixed_knuckle_upper (armor)
// units: mm. Mesh with: openscad -o left_lat_plate_fixed_knuckle_upper.stl left_lat_plate_fixed_knuckle_upper.scad
import("../stl/parts/left_lat_plate_fixed_knuckle_upper.stl");
