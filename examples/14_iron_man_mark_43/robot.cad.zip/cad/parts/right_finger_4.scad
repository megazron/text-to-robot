// concept part: right_finger_4 (armor)
// units: mm. Mesh with: openscad -o right_finger_4.stl right_finger_4.scad
import("../stl/parts/right_finger_4.stl");
