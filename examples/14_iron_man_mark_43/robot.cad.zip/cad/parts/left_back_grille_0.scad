// concept part: left_back_grille_0 (armor)
// units: mm. Mesh with: openscad -o left_back_grille_0.stl left_back_grille_0.scad
import("../stl/parts/left_back_grille_0.stl");
