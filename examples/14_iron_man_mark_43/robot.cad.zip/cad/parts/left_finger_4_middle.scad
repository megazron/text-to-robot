// concept part: left_finger_4_middle (armor)
// units: mm. Mesh with: openscad -o left_finger_4_middle.stl left_finger_4_middle.scad
import("../stl/parts/left_finger_4_middle.stl");
