// concept part: codpiece (armor)
// units: mm. Mesh with: openscad -o codpiece.stl codpiece.scad
import("../stl/parts/codpiece.stl");
