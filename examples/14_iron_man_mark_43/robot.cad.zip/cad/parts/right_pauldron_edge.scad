// concept part: right_pauldron_edge (armor)
// units: mm. Mesh with: openscad -o right_pauldron_edge.stl right_pauldron_edge.scad
import("../stl/parts/right_pauldron_edge.stl");
