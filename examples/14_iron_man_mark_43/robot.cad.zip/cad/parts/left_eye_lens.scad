// concept part: left_eye_lens (armor)
// units: mm. Mesh with: openscad -o left_eye_lens.stl left_eye_lens.scad
import("../stl/parts/left_eye_lens.stl");
