// concept part: left_chest_inlay (armor)
// units: mm. Mesh with: openscad -o left_chest_inlay.stl left_chest_inlay.scad
import("../stl/parts/left_chest_inlay.stl");
