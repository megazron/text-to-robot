// concept part: left_knee_motor_cover (armor)
// units: mm. Mesh with: openscad -o left_knee_motor_cover.stl left_knee_motor_cover.scad
import("../stl/parts/left_knee_motor_cover.stl");
