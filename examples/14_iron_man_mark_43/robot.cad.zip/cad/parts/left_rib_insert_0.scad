// concept part: left_rib_insert_0 (armor)
// units: mm. Mesh with: openscad -o left_rib_insert_0.stl left_rib_insert_0.scad
import("../stl/parts/left_rib_insert_0.stl");
