// concept part: right_eye_socket (armor)
// units: mm. Mesh with: openscad -o right_eye_socket.stl right_eye_socket.scad
import("../stl/parts/right_eye_socket.stl");
