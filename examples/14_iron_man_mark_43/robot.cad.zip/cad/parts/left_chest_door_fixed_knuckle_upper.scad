// concept part: left_chest_door_fixed_knuckle_upper (armor)
// units: mm. Mesh with: openscad -o left_chest_door_fixed_knuckle_upper.stl left_chest_door_fixed_knuckle_upper.scad
import("../stl/parts/left_chest_door_fixed_knuckle_upper.stl");
