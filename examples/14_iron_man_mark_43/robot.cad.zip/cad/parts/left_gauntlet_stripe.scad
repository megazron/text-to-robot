// concept part: left_gauntlet_stripe (armor)
// units: mm. Mesh with: openscad -o left_gauntlet_stripe.stl left_gauntlet_stripe.scad
import("../stl/parts/left_gauntlet_stripe.stl");
