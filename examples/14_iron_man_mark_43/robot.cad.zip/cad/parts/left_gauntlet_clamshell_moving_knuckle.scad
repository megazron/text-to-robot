// concept part: left_gauntlet_clamshell_moving_knuckle (armor)
// units: mm. Mesh with: openscad -o left_gauntlet_clamshell_moving_knuckle.stl left_gauntlet_clamshell_moving_knuckle.scad
import("../stl/parts/left_gauntlet_clamshell_moving_knuckle.stl");
