// concept part: right_palm_repulsor (armor)
// units: mm. Mesh with: openscad -o right_palm_repulsor.stl right_palm_repulsor.scad
import("../stl/parts/right_palm_repulsor.stl");
