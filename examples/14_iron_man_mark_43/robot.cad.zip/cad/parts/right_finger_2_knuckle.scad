// concept part: right_finger_2_knuckle (armor)
// units: mm. Mesh with: openscad -o right_finger_2_knuckle.stl right_finger_2_knuckle.scad
import("../stl/parts/right_finger_2_knuckle.stl");
