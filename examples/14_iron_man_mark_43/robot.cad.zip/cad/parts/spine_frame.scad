// concept part: spine_frame (link)
// units: mm. Mesh with: openscad -o spine_frame.stl spine_frame.scad
multmatrix([[1, 0, 0, -110], [0, 1, 0, 0], [0, 0, 1, 252], [0, 0, 0, 1]])
  cube([50, 80, 504], center=true);
