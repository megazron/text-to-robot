// concept part: left_hip_flap (armor)
// units: mm. Mesh with: openscad -o left_hip_flap.stl left_hip_flap.scad
import("../stl/parts/left_hip_flap.stl");
