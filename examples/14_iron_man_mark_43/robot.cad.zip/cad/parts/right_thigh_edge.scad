// concept part: right_thigh_edge (armor)
// units: mm. Mesh with: openscad -o right_thigh_edge.stl right_thigh_edge.scad
import("../stl/parts/right_thigh_edge.stl");
