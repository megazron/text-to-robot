// concept part: right_ankle_flap (armor)
// units: mm. Mesh with: openscad -o right_ankle_flap.stl right_ankle_flap.scad
import("../stl/parts/right_ankle_flap.stl");
