// concept part: left_thigh_edge (armor)
// units: mm. Mesh with: openscad -o left_thigh_edge.stl left_thigh_edge.scad
import("../stl/parts/left_thigh_edge.stl");
