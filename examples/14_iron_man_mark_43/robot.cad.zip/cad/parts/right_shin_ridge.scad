// concept part: right_shin_ridge (armor)
// units: mm. Mesh with: openscad -o right_shin_ridge.stl right_shin_ridge.scad
import("../stl/parts/right_shin_ridge.stl");
