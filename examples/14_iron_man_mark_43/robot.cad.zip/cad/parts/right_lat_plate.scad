// concept part: right_lat_plate (armor)
// units: mm. Mesh with: openscad -o right_lat_plate.stl right_lat_plate.scad
import("../stl/parts/right_lat_plate.stl");
