// concept part: left_shank_strut (link)
// units: mm. Mesh with: openscad -o left_shank_strut.stl left_shank_strut.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -215.25], [0, 0, 0, 1]])
  cube([50, 35, 426.5], center=true);
