// concept part: left_chest_door (armor)
// units: mm. Mesh with: openscad -o left_chest_door.stl left_chest_door.scad
import("../stl/parts/left_chest_door.stl");
