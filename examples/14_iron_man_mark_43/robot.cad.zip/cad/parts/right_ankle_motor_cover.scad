// concept part: right_ankle_motor_cover (armor)
// units: mm. Mesh with: openscad -o right_ankle_motor_cover.stl right_ankle_motor_cover.scad
import("../stl/parts/right_ankle_motor_cover.stl");
