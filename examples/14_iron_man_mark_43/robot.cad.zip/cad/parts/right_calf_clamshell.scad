// concept part: right_calf_clamshell (armor)
// units: mm. Mesh with: openscad -o right_calf_clamshell.stl right_calf_clamshell.scad
import("../stl/parts/right_calf_clamshell.stl");
