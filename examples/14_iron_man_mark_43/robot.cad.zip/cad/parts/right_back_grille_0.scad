// concept part: right_back_grille_0 (armor)
// units: mm. Mesh with: openscad -o right_back_grille_0.stl right_back_grille_0.scad
import("../stl/parts/right_back_grille_0.stl");
