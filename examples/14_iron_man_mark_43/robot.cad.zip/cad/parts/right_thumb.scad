// concept part: right_thumb (armor)
// units: mm. Mesh with: openscad -o right_thumb.stl right_thumb.scad
import("../stl/parts/right_thumb.stl");
