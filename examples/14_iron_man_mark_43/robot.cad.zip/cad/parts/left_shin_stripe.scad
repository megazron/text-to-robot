// concept part: left_shin_stripe (armor)
// units: mm. Mesh with: openscad -o left_shin_stripe.stl left_shin_stripe.scad
import("../stl/parts/left_shin_stripe.stl");
