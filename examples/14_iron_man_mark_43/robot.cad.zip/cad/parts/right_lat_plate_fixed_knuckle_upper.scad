// concept part: right_lat_plate_fixed_knuckle_upper (armor)
// units: mm. Mesh with: openscad -o right_lat_plate_fixed_knuckle_upper.stl right_lat_plate_fixed_knuckle_upper.scad
import("../stl/parts/right_lat_plate_fixed_knuckle_upper.stl");
