// concept part: left_finger_3_knuckle (armor)
// units: mm. Mesh with: openscad -o left_finger_3_knuckle.stl left_finger_3_knuckle.scad
import("../stl/parts/left_finger_3_knuckle.stl");
