// concept part: left_pauldron_edge (armor)
// units: mm. Mesh with: openscad -o left_pauldron_edge.stl left_pauldron_edge.scad
import("../stl/parts/left_pauldron_edge.stl");
