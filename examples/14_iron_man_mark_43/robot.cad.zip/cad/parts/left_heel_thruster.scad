// concept part: left_heel_thruster (armor)
// units: mm. Mesh with: openscad -o left_heel_thruster.stl left_heel_thruster.scad
import("../stl/parts/left_heel_thruster.stl");
