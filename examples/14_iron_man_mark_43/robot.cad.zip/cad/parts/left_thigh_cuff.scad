// concept part: left_thigh_cuff (link)
// units: mm. Mesh with: openscad -o left_thigh_cuff.stl left_thigh_cuff.scad
import("../stl/parts/left_thigh_cuff.stl");
