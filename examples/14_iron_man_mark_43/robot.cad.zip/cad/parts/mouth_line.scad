// concept part: mouth_line (armor)
// units: mm. Mesh with: openscad -o mouth_line.stl mouth_line.scad
import("../stl/parts/mouth_line.stl");
