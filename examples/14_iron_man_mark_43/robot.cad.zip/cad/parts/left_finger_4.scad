// concept part: left_finger_4 (armor)
// units: mm. Mesh with: openscad -o left_finger_4.stl left_finger_4.scad
import("../stl/parts/left_finger_4.stl");
