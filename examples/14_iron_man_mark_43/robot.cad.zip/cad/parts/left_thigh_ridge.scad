// concept part: left_thigh_ridge (armor)
// units: mm. Mesh with: openscad -o left_thigh_ridge.stl left_thigh_ridge.scad
import("../stl/parts/left_thigh_ridge.stl");
