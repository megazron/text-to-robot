// concept part: right_chest_door (armor)
// units: mm. Mesh with: openscad -o right_chest_door.stl right_chest_door.scad
import("../stl/parts/right_chest_door.stl");
