// concept part: left_boot_trim (armor)
// units: mm. Mesh with: openscad -o left_boot_trim.stl left_boot_trim.scad
import("../stl/parts/left_boot_trim.stl");
