// concept part: right_chest_inlay_centre (armor)
// units: mm. Mesh with: openscad -o right_chest_inlay_centre.stl right_chest_inlay_centre.scad
import("../stl/parts/right_chest_inlay_centre.stl");
