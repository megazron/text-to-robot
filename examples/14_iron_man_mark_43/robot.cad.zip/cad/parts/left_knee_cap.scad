// concept part: left_knee_cap (armor)
// units: mm. Mesh with: openscad -o left_knee_cap.stl left_knee_cap.scad
import("../stl/parts/left_knee_cap.stl");
