// concept part: right_elbow_module (link)
// units: mm. Mesh with: openscad -o right_elbow_module.stl right_elbow_module.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, -35], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=70, r=45, center=true, $fn=48);
