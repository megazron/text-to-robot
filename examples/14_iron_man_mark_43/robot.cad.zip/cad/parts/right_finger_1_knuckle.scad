// concept part: right_finger_1_knuckle (armor)
// units: mm. Mesh with: openscad -o right_finger_1_knuckle.stl right_finger_1_knuckle.scad
import("../stl/parts/right_finger_1_knuckle.stl");
