// concept part: right_thigh_clamshell_fixed_knuckle_upper (armor)
// units: mm. Mesh with: openscad -o right_thigh_clamshell_fixed_knuckle_upper.stl right_thigh_clamshell_fixed_knuckle_upper.scad
import("../stl/parts/right_thigh_clamshell_fixed_knuckle_upper.stl");
