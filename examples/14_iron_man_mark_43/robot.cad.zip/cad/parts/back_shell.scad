// concept part: back_shell (armor)
// units: mm. Mesh with: openscad -o back_shell.stl back_shell.scad
import("../stl/parts/back_shell.stl");
