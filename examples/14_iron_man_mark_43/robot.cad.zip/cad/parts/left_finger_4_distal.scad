// concept part: left_finger_4_distal (armor)
// units: mm. Mesh with: openscad -o left_finger_4_distal.stl left_finger_4_distal.scad
import("../stl/parts/left_finger_4_distal.stl");
