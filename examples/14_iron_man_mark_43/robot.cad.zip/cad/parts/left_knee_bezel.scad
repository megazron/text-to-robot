// concept part: left_knee_bezel (armor)
// units: mm. Mesh with: openscad -o left_knee_bezel.stl left_knee_bezel.scad
import("../stl/parts/left_knee_bezel.stl");
