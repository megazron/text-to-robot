// concept part: right_finger_4_knuckle (armor)
// units: mm. Mesh with: openscad -o right_finger_4_knuckle.stl right_finger_4_knuckle.scad
import("../stl/parts/right_finger_4_knuckle.stl");
