// concept part: left_forearm_strut (forearm)
// units: mm. Mesh with: openscad -o left_forearm_strut.stl left_forearm_strut.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -127.75], [0, 0, 0, 1]])
  cube([35, 30, 251.5], center=true);
