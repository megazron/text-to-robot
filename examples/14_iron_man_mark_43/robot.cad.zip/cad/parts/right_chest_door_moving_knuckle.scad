// concept part: right_chest_door_moving_knuckle (armor)
// units: mm. Mesh with: openscad -o right_chest_door_moving_knuckle.stl right_chest_door_moving_knuckle.scad
import("../stl/parts/right_chest_door_moving_knuckle.stl");
