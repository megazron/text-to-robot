// concept part: right_hip_flap (armor)
// units: mm. Mesh with: openscad -o right_hip_flap.stl right_hip_flap.scad
import("../stl/parts/right_hip_flap.stl");
