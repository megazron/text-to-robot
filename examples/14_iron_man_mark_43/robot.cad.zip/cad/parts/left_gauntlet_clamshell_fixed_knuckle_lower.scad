// concept part: left_gauntlet_clamshell_fixed_knuckle_lower (armor)
// units: mm. Mesh with: openscad -o left_gauntlet_clamshell_fixed_knuckle_lower.stl left_gauntlet_clamshell_fixed_knuckle_lower.scad
import("../stl/parts/left_gauntlet_clamshell_fixed_knuckle_lower.stl");
