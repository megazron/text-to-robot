// concept part: left_shin_guard (armor)
// units: mm. Mesh with: openscad -o left_shin_guard.stl left_shin_guard.scad
import("../stl/parts/left_shin_guard.stl");
