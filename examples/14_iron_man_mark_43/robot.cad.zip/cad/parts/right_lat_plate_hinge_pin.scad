// concept part: right_lat_plate_hinge_pin (armor)
// units: mm. Mesh with: openscad -o right_lat_plate_hinge_pin.stl right_lat_plate_hinge_pin.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=34, r=1.5, center=true, $fn=48);
