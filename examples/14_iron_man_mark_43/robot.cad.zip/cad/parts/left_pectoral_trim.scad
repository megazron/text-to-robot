// concept part: left_pectoral_trim (armor)
// units: mm. Mesh with: openscad -o left_pectoral_trim.stl left_pectoral_trim.scad
import("../stl/parts/left_pectoral_trim.stl");
