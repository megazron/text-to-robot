// concept part: left_finger_1 (armor)
// units: mm. Mesh with: openscad -o left_finger_1.stl left_finger_1.scad
import("../stl/parts/left_finger_1.stl");
