// concept part: belt_plate (armor)
// units: mm. Mesh with: openscad -o belt_plate.stl belt_plate.scad
import("../stl/parts/belt_plate.stl");
