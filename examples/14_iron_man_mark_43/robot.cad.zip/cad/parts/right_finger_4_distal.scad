// concept part: right_finger_4_distal (armor)
// units: mm. Mesh with: openscad -o right_finger_4_distal.stl right_finger_4_distal.scad
import("../stl/parts/right_finger_4_distal.stl");
