// concept part: right_flight_flap (armor)
// units: mm. Mesh with: openscad -o right_flight_flap.stl right_flight_flap.scad
import("../stl/parts/right_flight_flap.stl");
