// concept part: left_hand_plate (armor)
// units: mm. Mesh with: openscad -o left_hand_plate.stl left_hand_plate.scad
import("../stl/parts/left_hand_plate.stl");
