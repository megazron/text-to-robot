// concept part: right_hip_outer_plate (armor)
// units: mm. Mesh with: openscad -o right_hip_outer_plate.stl right_hip_outer_plate.scad
import("../stl/parts/right_hip_outer_plate.stl");
