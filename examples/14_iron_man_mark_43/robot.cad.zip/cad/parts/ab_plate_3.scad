// concept part: ab_plate_3 (armor)
// units: mm. Mesh with: openscad -o ab_plate_3.stl ab_plate_3.scad
import("../stl/parts/ab_plate_3.stl");
