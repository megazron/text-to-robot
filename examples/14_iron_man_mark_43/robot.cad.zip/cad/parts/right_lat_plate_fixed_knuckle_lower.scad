// concept part: right_lat_plate_fixed_knuckle_lower (armor)
// units: mm. Mesh with: openscad -o right_lat_plate_fixed_knuckle_lower.stl right_lat_plate_fixed_knuckle_lower.scad
import("../stl/parts/right_lat_plate_fixed_knuckle_lower.stl");
