// concept part: left_eye_socket (armor)
// units: mm. Mesh with: openscad -o left_eye_socket.stl left_eye_socket.scad
import("../stl/parts/left_eye_socket.stl");
