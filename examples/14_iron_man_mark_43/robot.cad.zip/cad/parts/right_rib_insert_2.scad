// concept part: right_rib_insert_2 (armor)
// units: mm. Mesh with: openscad -o right_rib_insert_2.stl right_rib_insert_2.scad
import("../stl/parts/right_rib_insert_2.stl");
