// concept part: left_lat_plate_moving_knuckle (armor)
// units: mm. Mesh with: openscad -o left_lat_plate_moving_knuckle.stl left_lat_plate_moving_knuckle.scad
import("../stl/parts/left_lat_plate_moving_knuckle.stl");
