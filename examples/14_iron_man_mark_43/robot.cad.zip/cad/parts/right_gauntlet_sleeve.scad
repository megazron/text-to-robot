// concept part: right_gauntlet_sleeve (armor)
// units: mm. Mesh with: openscad -o right_gauntlet_sleeve.stl right_gauntlet_sleeve.scad
import("../stl/parts/right_gauntlet_sleeve.stl");
