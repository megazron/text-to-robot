// concept part: right_hand_plate (armor)
// units: mm. Mesh with: openscad -o right_hand_plate.stl right_hand_plate.scad
import("../stl/parts/right_hand_plate.stl");
