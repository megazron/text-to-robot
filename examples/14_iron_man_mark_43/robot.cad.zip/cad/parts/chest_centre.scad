// concept part: chest_centre (armor)
// units: mm. Mesh with: openscad -o chest_centre.stl chest_centre.scad
import("../stl/parts/chest_centre.stl");
