// concept part: right_bicep_sleeve (armor)
// units: mm. Mesh with: openscad -o right_bicep_sleeve.stl right_bicep_sleeve.scad
import("../stl/parts/right_bicep_sleeve.stl");
