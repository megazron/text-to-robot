// concept part: neck_ring (armor)
// units: mm. Mesh with: openscad -o neck_ring.stl neck_ring.scad
import("../stl/parts/neck_ring.stl");
