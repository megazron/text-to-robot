// concept part: left_cheek_panel (armor)
// units: mm. Mesh with: openscad -o left_cheek_panel.stl left_cheek_panel.scad
import("../stl/parts/left_cheek_panel.stl");
