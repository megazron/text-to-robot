// concept part: left_elbow_cap (armor)
// units: mm. Mesh with: openscad -o left_elbow_cap.stl left_elbow_cap.scad
import("../stl/parts/left_elbow_cap.stl");
