// concept part: left_thumb (armor)
// units: mm. Mesh with: openscad -o left_thumb.stl left_thumb.scad
import("../stl/parts/left_thumb.stl");
