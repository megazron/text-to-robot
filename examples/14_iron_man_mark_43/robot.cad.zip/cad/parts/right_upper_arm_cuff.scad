// concept part: right_upper_arm_cuff (link)
// units: mm. Mesh with: openscad -o right_upper_arm_cuff.stl right_upper_arm_cuff.scad
import("../stl/parts/right_upper_arm_cuff.stl");
