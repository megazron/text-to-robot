// concept part: left_chest_inlay_centre (armor)
// units: mm. Mesh with: openscad -o left_chest_inlay_centre.stl left_chest_inlay_centre.scad
import("../stl/parts/left_chest_inlay_centre.stl");
