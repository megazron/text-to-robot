// concept part: right_shank_strut (link)
// units: mm. Mesh with: openscad -o right_shank_strut.stl right_shank_strut.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -215.25], [0, 0, 0, 1]])
  cube([50, 35, 430.5], center=true);
