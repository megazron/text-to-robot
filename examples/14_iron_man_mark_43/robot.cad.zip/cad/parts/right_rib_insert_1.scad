// concept part: right_rib_insert_1 (armor)
// units: mm. Mesh with: openscad -o right_rib_insert_1.stl right_rib_insert_1.scad
import("../stl/parts/right_rib_insert_1.stl");
