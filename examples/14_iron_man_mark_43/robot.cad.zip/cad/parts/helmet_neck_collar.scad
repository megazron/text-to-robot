// concept part: helmet_neck_collar (armor)
// units: mm. Mesh with: openscad -o helmet_neck_collar.stl helmet_neck_collar.scad
import("../stl/parts/helmet_neck_collar.stl");
