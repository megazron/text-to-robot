// concept part: right_finger_3_distal (armor)
// units: mm. Mesh with: openscad -o right_finger_3_distal.stl right_finger_3_distal.scad
import("../stl/parts/right_finger_3_distal.stl");
