// concept part: helmet (armor)
// units: mm. Mesh with: openscad -o helmet.stl helmet.scad
import("../stl/parts/helmet.stl");
