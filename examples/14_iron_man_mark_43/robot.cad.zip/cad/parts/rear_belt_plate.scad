// concept part: rear_belt_plate (armor)
// units: mm. Mesh with: openscad -o rear_belt_plate.stl rear_belt_plate.scad
import("../stl/parts/rear_belt_plate.stl");
