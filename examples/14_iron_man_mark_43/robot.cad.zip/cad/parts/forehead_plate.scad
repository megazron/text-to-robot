// concept part: forehead_plate (armor)
// units: mm. Mesh with: openscad -o forehead_plate.stl forehead_plate.scad
import("../stl/parts/forehead_plate.stl");
