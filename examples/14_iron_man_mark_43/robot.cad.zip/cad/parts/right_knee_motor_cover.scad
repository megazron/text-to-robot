// concept part: right_knee_motor_cover (armor)
// units: mm. Mesh with: openscad -o right_knee_motor_cover.stl right_knee_motor_cover.scad
import("../stl/parts/right_knee_motor_cover.stl");
