// concept part: left_flight_flap (armor)
// units: mm. Mesh with: openscad -o left_flight_flap.stl left_flight_flap.scad
import("../stl/parts/left_flight_flap.stl");
