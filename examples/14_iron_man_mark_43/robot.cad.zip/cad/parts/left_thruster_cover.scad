// concept part: left_thruster_cover (armor)
// units: mm. Mesh with: openscad -o left_thruster_cover.stl left_thruster_cover.scad
import("../stl/parts/left_thruster_cover.stl");
