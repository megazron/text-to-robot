// concept part: left_clavicle_cover (armor)
// units: mm. Mesh with: openscad -o left_clavicle_cover.stl left_clavicle_cover.scad
import("../stl/parts/left_clavicle_cover.stl");
