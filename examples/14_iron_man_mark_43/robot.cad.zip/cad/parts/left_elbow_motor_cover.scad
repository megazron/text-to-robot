// concept part: left_elbow_motor_cover (armor)
// units: mm. Mesh with: openscad -o left_elbow_motor_cover.stl left_elbow_motor_cover.scad
import("../stl/parts/left_elbow_motor_cover.stl");
