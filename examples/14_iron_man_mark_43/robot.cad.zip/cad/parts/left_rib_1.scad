// concept part: left_rib_1 (armor)
// units: mm. Mesh with: openscad -o left_rib_1.stl left_rib_1.scad
import("../stl/parts/left_rib_1.stl");
