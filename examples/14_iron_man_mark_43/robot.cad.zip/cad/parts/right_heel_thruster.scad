// concept part: right_heel_thruster (armor)
// units: mm. Mesh with: openscad -o right_heel_thruster.stl right_heel_thruster.scad
import("../stl/parts/right_heel_thruster.stl");
