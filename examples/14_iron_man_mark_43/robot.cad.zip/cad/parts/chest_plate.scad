// concept part: chest_plate (link)
// units: mm. Mesh with: openscad -o chest_plate.stl chest_plate.scad
multmatrix([[1, 0, 0, 125], [0, 1, 0, 0], [0, 0, 1, 357.72], [0, 0, 0, 1]])
  cube([20, 280, 240], center=true);
