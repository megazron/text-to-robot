// concept part: left_finger_2_knuckle_0 (armor)
// units: mm. Mesh with: openscad -o left_finger_2_knuckle_0.stl left_finger_2_knuckle_0.scad
import("../stl/parts/left_finger_2_knuckle_0.stl");
