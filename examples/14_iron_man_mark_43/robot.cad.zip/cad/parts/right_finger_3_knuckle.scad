// concept part: right_finger_3_knuckle (armor)
// units: mm. Mesh with: openscad -o right_finger_3_knuckle.stl right_finger_3_knuckle.scad
import("../stl/parts/right_finger_3_knuckle.stl");
