// concept part: right_thigh_stripe (armor)
// units: mm. Mesh with: openscad -o right_thigh_stripe.stl right_thigh_stripe.scad
import("../stl/parts/right_thigh_stripe.stl");
