// concept part: left_shin_edge (armor)
// units: mm. Mesh with: openscad -o left_shin_edge.stl left_shin_edge.scad
import("../stl/parts/left_shin_edge.stl");
