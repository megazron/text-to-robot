// concept part: left_gauntlet_sleeve (armor)
// units: mm. Mesh with: openscad -o left_gauntlet_sleeve.stl left_gauntlet_sleeve.scad
import("../stl/parts/left_gauntlet_sleeve.stl");
