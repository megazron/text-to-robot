// concept part: left_ankle_motor_cover (armor)
// units: mm. Mesh with: openscad -o left_ankle_motor_cover.stl left_ankle_motor_cover.scad
import("../stl/parts/left_ankle_motor_cover.stl");
