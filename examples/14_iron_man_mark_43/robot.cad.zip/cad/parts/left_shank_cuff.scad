// concept part: left_shank_cuff (link)
// units: mm. Mesh with: openscad -o left_shank_cuff.stl left_shank_cuff.scad
import("../stl/parts/left_shank_cuff.stl");
