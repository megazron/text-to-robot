// concept part: left_thigh_clamshell_moving_knuckle (armor)
// units: mm. Mesh with: openscad -o left_thigh_clamshell_moving_knuckle.stl left_thigh_clamshell_moving_knuckle.scad
import("../stl/parts/left_thigh_clamshell_moving_knuckle.stl");
