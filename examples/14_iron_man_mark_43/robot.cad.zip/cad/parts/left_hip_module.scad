// concept part: left_hip_module (link)
// units: mm. Mesh with: openscad -o left_hip_module.stl left_hip_module.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 45], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=90, r=65, center=true, $fn=48);
