// concept part: right_forearm_crest (armor)
// units: mm. Mesh with: openscad -o right_forearm_crest.stl right_forearm_crest.scad
import("../stl/parts/right_forearm_crest.stl");
