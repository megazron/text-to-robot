// concept part: right_lat_plate_moving_knuckle (armor)
// units: mm. Mesh with: openscad -o right_lat_plate_moving_knuckle.stl right_lat_plate_moving_knuckle.scad
import("../stl/parts/right_lat_plate_moving_knuckle.stl");
