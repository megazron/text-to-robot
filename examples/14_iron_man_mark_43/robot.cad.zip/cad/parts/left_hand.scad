// concept part: left_hand (gripper)
// units: mm. Mesh with: openscad -o left_hand.stl left_hand.scad
multmatrix([[1, 0, 0, 20], [0, 1, 0, -45], [0, 0, 1, -40], [0, 0, 0, 1]])
  cube([100, 70, 30], center=true);
