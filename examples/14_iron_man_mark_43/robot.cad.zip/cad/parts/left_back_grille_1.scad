// concept part: left_back_grille_1 (armor)
// units: mm. Mesh with: openscad -o left_back_grille_1.stl left_back_grille_1.scad
import("../stl/parts/left_back_grille_1.stl");
