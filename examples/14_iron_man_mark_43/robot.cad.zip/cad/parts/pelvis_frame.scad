// concept part: pelvis_frame (base)
// units: mm. Mesh with: openscad -o pelvis_frame.stl pelvis_frame.scad
import("../stl/parts/pelvis_frame.stl");
