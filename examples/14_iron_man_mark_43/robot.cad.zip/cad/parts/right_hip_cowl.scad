// concept part: right_hip_cowl (armor)
// units: mm. Mesh with: openscad -o right_hip_cowl.stl right_hip_cowl.scad
import("../stl/parts/right_hip_cowl.stl");
