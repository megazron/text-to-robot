// concept part: left_ankle_flap (armor)
// units: mm. Mesh with: openscad -o left_ankle_flap.stl left_ankle_flap.scad
import("../stl/parts/left_ankle_flap.stl");
