// concept part: right_back_grille_2 (armor)
// units: mm. Mesh with: openscad -o right_back_grille_2.stl right_back_grille_2.scad
import("../stl/parts/right_back_grille_2.stl");
