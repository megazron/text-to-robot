// concept part: right_knee_cap (armor)
// units: mm. Mesh with: openscad -o right_knee_cap.stl right_knee_cap.scad
import("../stl/parts/right_knee_cap.stl");
