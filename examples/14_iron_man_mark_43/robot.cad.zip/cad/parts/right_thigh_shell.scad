// concept part: right_thigh_shell (armor)
// units: mm. Mesh with: openscad -o right_thigh_shell.stl right_thigh_shell.scad
import("../stl/parts/right_thigh_shell.stl");
