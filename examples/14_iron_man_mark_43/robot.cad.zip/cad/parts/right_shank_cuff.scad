// concept part: right_shank_cuff (link)
// units: mm. Mesh with: openscad -o right_shank_cuff.stl right_shank_cuff.scad
import("../stl/parts/right_shank_cuff.stl");
