// concept part: faceplate (armor)
// units: mm. Mesh with: openscad -o faceplate.stl faceplate.scad
import("../stl/parts/faceplate.stl");
