// concept part: right_gauntlet_clamshell_fixed_knuckle_lower (armor)
// units: mm. Mesh with: openscad -o right_gauntlet_clamshell_fixed_knuckle_lower.stl right_gauntlet_clamshell_fixed_knuckle_lower.scad
import("../stl/parts/right_gauntlet_clamshell_fixed_knuckle_lower.stl");
