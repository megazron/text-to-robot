// concept part: right_knee_module (link)
// units: mm. Mesh with: openscad -o right_knee_module.stl right_knee_module.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, -40], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=80, r=60, center=true, $fn=48);
