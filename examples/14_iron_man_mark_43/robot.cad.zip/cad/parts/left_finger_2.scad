// concept part: left_finger_2 (armor)
// units: mm. Mesh with: openscad -o left_finger_2.stl left_finger_2.scad
import("../stl/parts/left_finger_2.stl");
