// concept part: left_calf_clamshell (armor)
// units: mm. Mesh with: openscad -o left_calf_clamshell.stl left_calf_clamshell.scad
import("../stl/parts/left_calf_clamshell.stl");
