// concept part: right_eye_lens (armor)
// units: mm. Mesh with: openscad -o right_eye_lens.stl right_eye_lens.scad
import("../stl/parts/right_eye_lens.stl");
