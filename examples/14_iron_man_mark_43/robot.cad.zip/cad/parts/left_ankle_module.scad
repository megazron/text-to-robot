// concept part: left_ankle_module (link)
// units: mm. Mesh with: openscad -o left_ankle_module.stl left_ankle_module.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 35], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=70, r=50, center=true, $fn=48);
