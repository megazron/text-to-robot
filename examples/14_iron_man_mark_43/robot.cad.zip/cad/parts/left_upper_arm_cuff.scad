// concept part: left_upper_arm_cuff (link)
// units: mm. Mesh with: openscad -o left_upper_arm_cuff.stl left_upper_arm_cuff.scad
import("../stl/parts/left_upper_arm_cuff.stl");
