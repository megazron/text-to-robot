// concept part: chin_guard (armor)
// units: mm. Mesh with: openscad -o chin_guard.stl chin_guard.scad
import("../stl/parts/chin_guard.stl");
