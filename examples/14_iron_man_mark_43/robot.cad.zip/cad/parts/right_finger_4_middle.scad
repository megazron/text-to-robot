// concept part: right_finger_4_middle (armor)
// units: mm. Mesh with: openscad -o right_finger_4_middle.stl right_finger_4_middle.scad
import("../stl/parts/right_finger_4_middle.stl");
