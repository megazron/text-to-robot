// concept part: right_back_scapula (armor)
// units: mm. Mesh with: openscad -o right_back_scapula.stl right_back_scapula.scad
import("../stl/parts/right_back_scapula.stl");
