// concept part: left_forearm_cuff (link)
// units: mm. Mesh with: openscad -o left_forearm_cuff.stl left_forearm_cuff.scad
import("../stl/parts/left_forearm_cuff.stl");
