// concept part: right_thigh_clamshell_moving_knuckle (armor)
// units: mm. Mesh with: openscad -o right_thigh_clamshell_moving_knuckle.stl right_thigh_clamshell_moving_knuckle.scad
import("../stl/parts/right_thigh_clamshell_moving_knuckle.stl");
