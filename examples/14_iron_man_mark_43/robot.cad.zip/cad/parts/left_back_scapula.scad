// concept part: left_back_scapula (armor)
// units: mm. Mesh with: openscad -o left_back_scapula.stl left_back_scapula.scad
import("../stl/parts/left_back_scapula.stl");
