// concept part: left_shin_ridge (armor)
// units: mm. Mesh with: openscad -o left_shin_ridge.stl left_shin_ridge.scad
import("../stl/parts/left_shin_ridge.stl");
