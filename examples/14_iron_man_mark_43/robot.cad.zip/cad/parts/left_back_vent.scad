// concept part: left_back_vent (armor)
// units: mm. Mesh with: openscad -o left_back_vent.stl left_back_vent.scad
import("../stl/parts/left_back_vent.stl");
