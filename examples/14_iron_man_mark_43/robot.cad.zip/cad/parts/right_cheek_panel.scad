// concept part: right_cheek_panel (armor)
// units: mm. Mesh with: openscad -o right_cheek_panel.stl right_cheek_panel.scad
import("../stl/parts/right_cheek_panel.stl");
