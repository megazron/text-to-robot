// concept part: right_gauntlet_hatch (armor)
// units: mm. Mesh with: openscad -o right_gauntlet_hatch.stl right_gauntlet_hatch.scad
import("../stl/parts/right_gauntlet_hatch.stl");
