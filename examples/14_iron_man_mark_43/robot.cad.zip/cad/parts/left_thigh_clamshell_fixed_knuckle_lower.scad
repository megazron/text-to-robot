// concept part: left_thigh_clamshell_fixed_knuckle_lower (armor)
// units: mm. Mesh with: openscad -o left_thigh_clamshell_fixed_knuckle_lower.stl left_thigh_clamshell_fixed_knuckle_lower.scad
import("../stl/parts/left_thigh_clamshell_fixed_knuckle_lower.stl");
