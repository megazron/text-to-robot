// concept part: right_rib_edge_0 (armor)
// units: mm. Mesh with: openscad -o right_rib_edge_0.stl right_rib_edge_0.scad
import("../stl/parts/right_rib_edge_0.stl");
