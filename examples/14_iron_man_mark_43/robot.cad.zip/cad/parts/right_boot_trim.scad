// concept part: right_boot_trim (armor)
// units: mm. Mesh with: openscad -o right_boot_trim.stl right_boot_trim.scad
import("../stl/parts/right_boot_trim.stl");
