// concept part: right_chest_door_fixed_knuckle_lower (armor)
// units: mm. Mesh with: openscad -o right_chest_door_fixed_knuckle_lower.stl right_chest_door_fixed_knuckle_lower.scad
import("../stl/parts/right_chest_door_fixed_knuckle_lower.stl");
