// concept part: left_lat_plate (armor)
// units: mm. Mesh with: openscad -o left_lat_plate.stl left_lat_plate.scad
import("../stl/parts/left_lat_plate.stl");
