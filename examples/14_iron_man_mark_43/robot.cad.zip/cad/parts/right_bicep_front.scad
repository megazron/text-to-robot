// concept part: right_bicep_front (armor)
// units: mm. Mesh with: openscad -o right_bicep_front.stl right_bicep_front.scad
import("../stl/parts/right_bicep_front.stl");
