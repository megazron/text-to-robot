// concept part: right_chest_inlay (armor)
// units: mm. Mesh with: openscad -o right_chest_inlay.stl right_chest_inlay.scad
import("../stl/parts/right_chest_inlay.stl");
