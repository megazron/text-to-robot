// concept part: left_boot_toe (armor)
// units: mm. Mesh with: openscad -o left_boot_toe.stl left_boot_toe.scad
import("../stl/parts/left_boot_toe.stl");
