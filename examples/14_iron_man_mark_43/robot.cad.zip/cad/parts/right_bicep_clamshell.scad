// concept part: right_bicep_clamshell (armor)
// units: mm. Mesh with: openscad -o right_bicep_clamshell.stl right_bicep_clamshell.scad
import("../stl/parts/right_bicep_clamshell.stl");
