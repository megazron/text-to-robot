// concept part: left_gauntlet_hatch (armor)
// units: mm. Mesh with: openscad -o left_gauntlet_hatch.stl left_gauntlet_hatch.scad
import("../stl/parts/left_gauntlet_hatch.stl");
