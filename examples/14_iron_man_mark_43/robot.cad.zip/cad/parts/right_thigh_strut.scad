// concept part: right_thigh_strut (link)
// units: mm. Mesh with: openscad -o right_thigh_strut.stl right_thigh_strut.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -214.375], [0, 0, 0, 1]])
  cube([55, 40, 428.75], center=true);
