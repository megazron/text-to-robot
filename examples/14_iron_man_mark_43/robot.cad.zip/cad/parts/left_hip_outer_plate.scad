// concept part: left_hip_outer_plate (armor)
// units: mm. Mesh with: openscad -o left_hip_outer_plate.stl left_hip_outer_plate.scad
import("../stl/parts/left_hip_outer_plate.stl");
