// concept part: left_thigh_stripe (armor)
// units: mm. Mesh with: openscad -o left_thigh_stripe.stl left_thigh_stripe.scad
import("../stl/parts/left_thigh_stripe.stl");
