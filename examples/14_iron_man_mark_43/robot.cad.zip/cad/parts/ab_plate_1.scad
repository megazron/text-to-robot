// concept part: ab_plate_1 (armor)
// units: mm. Mesh with: openscad -o ab_plate_1.stl ab_plate_1.scad
import("../stl/parts/ab_plate_1.stl");
