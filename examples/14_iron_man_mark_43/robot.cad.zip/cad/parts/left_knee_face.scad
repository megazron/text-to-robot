// concept part: left_knee_face (armor)
// units: mm. Mesh with: openscad -o left_knee_face.stl left_knee_face.scad
import("../stl/parts/left_knee_face.stl");
