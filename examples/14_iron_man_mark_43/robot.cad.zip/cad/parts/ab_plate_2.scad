// concept part: ab_plate_2 (armor)
// units: mm. Mesh with: openscad -o ab_plate_2.stl ab_plate_2.scad
import("../stl/parts/ab_plate_2.stl");
