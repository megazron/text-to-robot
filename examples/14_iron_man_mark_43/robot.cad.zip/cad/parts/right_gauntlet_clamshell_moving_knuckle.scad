// concept part: right_gauntlet_clamshell_moving_knuckle (armor)
// units: mm. Mesh with: openscad -o right_gauntlet_clamshell_moving_knuckle.stl right_gauntlet_clamshell_moving_knuckle.scad
import("../stl/parts/right_gauntlet_clamshell_moving_knuckle.stl");
