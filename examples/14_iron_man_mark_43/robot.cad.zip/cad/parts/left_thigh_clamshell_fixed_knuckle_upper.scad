// concept part: left_thigh_clamshell_fixed_knuckle_upper (armor)
// units: mm. Mesh with: openscad -o left_thigh_clamshell_fixed_knuckle_upper.stl left_thigh_clamshell_fixed_knuckle_upper.scad
import("../stl/parts/left_thigh_clamshell_fixed_knuckle_upper.stl");
