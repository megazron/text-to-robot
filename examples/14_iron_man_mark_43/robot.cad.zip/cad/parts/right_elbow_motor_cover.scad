// concept part: right_elbow_motor_cover (armor)
// units: mm. Mesh with: openscad -o right_elbow_motor_cover.stl right_elbow_motor_cover.scad
import("../stl/parts/right_elbow_motor_cover.stl");
