// concept part: right_gauntlet_clamshell (armor)
// units: mm. Mesh with: openscad -o right_gauntlet_clamshell.stl right_gauntlet_clamshell.scad
import("../stl/parts/right_gauntlet_clamshell.stl");
