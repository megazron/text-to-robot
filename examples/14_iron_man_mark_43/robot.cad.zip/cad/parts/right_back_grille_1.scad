// concept part: right_back_grille_1 (armor)
// units: mm. Mesh with: openscad -o right_back_grille_1.stl right_back_grille_1.scad
import("../stl/parts/right_back_grille_1.stl");
