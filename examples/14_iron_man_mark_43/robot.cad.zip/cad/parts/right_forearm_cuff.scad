// concept part: right_forearm_cuff (link)
// units: mm. Mesh with: openscad -o right_forearm_cuff.stl right_forearm_cuff.scad
import("../stl/parts/right_forearm_cuff.stl");
