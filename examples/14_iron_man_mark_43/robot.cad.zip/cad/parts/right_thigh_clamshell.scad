// concept part: right_thigh_clamshell (armor)
// units: mm. Mesh with: openscad -o right_thigh_clamshell.stl right_thigh_clamshell.scad
import("../stl/parts/right_thigh_clamshell.stl");
