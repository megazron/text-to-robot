// concept part: backpack (link)
// units: mm. Mesh with: openscad -o backpack.stl backpack.scad
multmatrix([[1, 0, 0, -200], [0, 1, 0, 0], [0, 0, 1, 277.2], [0, 0, 0, 1]])
  cube([160, 320, 420], center=true);
