// concept part: neck_yaw_carrier (link)
// units: mm. Mesh with: openscad -o neck_yaw_carrier.stl neck_yaw_carrier.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cylinder(h=12, r=35, center=true, $fn=48);
