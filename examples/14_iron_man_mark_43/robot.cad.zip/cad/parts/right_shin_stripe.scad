// concept part: right_shin_stripe (armor)
// units: mm. Mesh with: openscad -o right_shin_stripe.stl right_shin_stripe.scad
import("../stl/parts/right_shin_stripe.stl");
