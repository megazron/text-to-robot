// concept part: right_thigh_clamshell_fixed_knuckle_lower (armor)
// units: mm. Mesh with: openscad -o right_thigh_clamshell_fixed_knuckle_lower.stl right_thigh_clamshell_fixed_knuckle_lower.scad
import("../stl/parts/right_thigh_clamshell_fixed_knuckle_lower.stl");
