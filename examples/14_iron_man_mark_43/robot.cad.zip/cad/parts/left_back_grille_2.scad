// concept part: left_back_grille_2 (armor)
// units: mm. Mesh with: openscad -o left_back_grille_2.stl left_back_grille_2.scad
import("../stl/parts/left_back_grille_2.stl");
