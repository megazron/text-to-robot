// concept part: right_finger_2_middle (armor)
// units: mm. Mesh with: openscad -o right_finger_2_middle.stl right_finger_2_middle.scad
import("../stl/parts/right_finger_2_middle.stl");
