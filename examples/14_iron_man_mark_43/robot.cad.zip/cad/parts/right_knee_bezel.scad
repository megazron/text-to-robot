// concept part: right_knee_bezel (armor)
// units: mm. Mesh with: openscad -o right_knee_bezel.stl right_knee_bezel.scad
import("../stl/parts/right_knee_bezel.stl");
