// concept part: right_pauldron (armor)
// units: mm. Mesh with: openscad -o right_pauldron.stl right_pauldron.scad
import("../stl/parts/right_pauldron.stl");
