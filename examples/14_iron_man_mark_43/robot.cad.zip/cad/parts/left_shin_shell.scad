// concept part: left_shin_shell (armor)
// units: mm. Mesh with: openscad -o left_shin_shell.stl left_shin_shell.scad
import("../stl/parts/left_shin_shell.stl");
