// concept part: right_shoulder_module (link)
// units: mm. Mesh with: openscad -o right_shoulder_module.stl right_shoulder_module.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, -40], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=80, r=55, center=true, $fn=48);
