// concept part: right_hand (gripper)
// units: mm. Mesh with: openscad -o right_hand.stl right_hand.scad
multmatrix([[1, 0, 0, 45], [0, 1, 0, 45], [0, 0, 1, -40], [0, 0, 0, 1]])
  cube([90, 70, 30], center=true);
