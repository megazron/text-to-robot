// concept part: left_rib_0 (armor)
// units: mm. Mesh with: openscad -o left_rib_0.stl left_rib_0.scad
import("../stl/parts/left_rib_0.stl");
