// concept part: left_pauldron (armor)
// units: mm. Mesh with: openscad -o left_pauldron.stl left_pauldron.scad
import("../stl/parts/left_pauldron.stl");
