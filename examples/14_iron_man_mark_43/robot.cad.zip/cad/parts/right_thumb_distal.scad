// concept part: right_thumb_distal (armor)
// units: mm. Mesh with: openscad -o right_thumb_distal.stl right_thumb_distal.scad
import("../stl/parts/right_thumb_distal.stl");
