// concept part: right_finger_3_middle_knuckle (armor)
// units: mm. Mesh with: openscad -o right_finger_3_middle_knuckle.stl right_finger_3_middle_knuckle.scad
import("../stl/parts/right_finger_3_middle_knuckle.stl");
