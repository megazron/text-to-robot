// concept part: right_gauntlet_stripe (armor)
// units: mm. Mesh with: openscad -o right_gauntlet_stripe.stl right_gauntlet_stripe.scad
import("../stl/parts/right_gauntlet_stripe.stl");
