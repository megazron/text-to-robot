// concept part: right_thigh_cuff (link)
// units: mm. Mesh with: openscad -o right_thigh_cuff.stl right_thigh_cuff.scad
import("../stl/parts/right_thigh_cuff.stl");
