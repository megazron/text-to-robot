// concept part: left_chest_door_fixed_knuckle_lower (armor)
// units: mm. Mesh with: openscad -o left_chest_door_fixed_knuckle_lower.stl left_chest_door_fixed_knuckle_lower.scad
import("../stl/parts/left_chest_door_fixed_knuckle_lower.stl");
