// concept part: right_finger_3 (armor)
// units: mm. Mesh with: openscad -o right_finger_3.stl right_finger_3.scad
import("../stl/parts/right_finger_3.stl");
