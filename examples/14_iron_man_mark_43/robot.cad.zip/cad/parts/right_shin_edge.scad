// concept part: right_shin_edge (armor)
// units: mm. Mesh with: openscad -o right_shin_edge.stl right_shin_edge.scad
import("../stl/parts/right_shin_edge.stl");
