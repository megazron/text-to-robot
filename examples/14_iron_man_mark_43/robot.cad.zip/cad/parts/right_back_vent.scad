// concept part: right_back_vent (armor)
// units: mm. Mesh with: openscad -o right_back_vent.stl right_back_vent.scad
import("../stl/parts/right_back_vent.stl");
