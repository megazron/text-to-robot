// concept part: left_thigh_clamshell (armor)
// units: mm. Mesh with: openscad -o left_thigh_clamshell.stl left_thigh_clamshell.scad
import("../stl/parts/left_thigh_clamshell.stl");
