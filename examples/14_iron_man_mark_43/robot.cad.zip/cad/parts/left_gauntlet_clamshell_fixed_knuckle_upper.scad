// concept part: left_gauntlet_clamshell_fixed_knuckle_upper (armor)
// units: mm. Mesh with: openscad -o left_gauntlet_clamshell_fixed_knuckle_upper.stl left_gauntlet_clamshell_fixed_knuckle_upper.scad
import("../stl/parts/left_gauntlet_clamshell_fixed_knuckle_upper.stl");
