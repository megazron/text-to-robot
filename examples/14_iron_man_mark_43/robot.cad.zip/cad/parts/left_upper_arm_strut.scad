// concept part: left_upper_arm_strut (upper_arm)
// units: mm. Mesh with: openscad -o left_upper_arm_strut.stl left_upper_arm_strut.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -162.75], [0, 0, 0, 1]])
  cube([40, 35, 321.5], center=true);
