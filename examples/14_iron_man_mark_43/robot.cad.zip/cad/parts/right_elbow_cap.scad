// concept part: right_elbow_cap (armor)
// units: mm. Mesh with: openscad -o right_elbow_cap.stl right_elbow_cap.scad
import("../stl/parts/right_elbow_cap.stl");
