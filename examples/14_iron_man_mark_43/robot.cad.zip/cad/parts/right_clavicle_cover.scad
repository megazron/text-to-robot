// concept part: right_clavicle_cover (armor)
// units: mm. Mesh with: openscad -o right_clavicle_cover.stl right_clavicle_cover.scad
import("../stl/parts/right_clavicle_cover.stl");
