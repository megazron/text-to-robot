// concept part: left_finger_3 (armor)
// units: mm. Mesh with: openscad -o left_finger_3.stl left_finger_3.scad
import("../stl/parts/left_finger_3.stl");
