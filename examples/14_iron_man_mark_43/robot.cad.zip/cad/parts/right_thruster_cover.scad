// concept part: right_thruster_cover (armor)
// units: mm. Mesh with: openscad -o right_thruster_cover.stl right_thruster_cover.scad
import("../stl/parts/right_thruster_cover.stl");
