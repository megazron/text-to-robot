# Assembly — iron_man_mark_43

Start from **base_link**.

1. Bolt **pelvis** to **base_link**.
2. Bolt **head** to **pelvis**.
3. Bolt **ear_pod_left** to **head**.
4. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (faceplate_servo_left) in **ear_pod_left** with its case screws.
5. Set joint `faceplate` to zero (centre the servo first), then screw **helmet_faceplate** to the actuator output in **ear_pod_left**; it moves -57° … 0°.
6. Bolt **faceplate_arm_left** to **helmet_faceplate**.
7. Bolt **faceplate_arm_right** to **helmet_faceplate**.
8. Bolt **eye_lens_1** to **helmet_faceplate**.
9. Bolt **eye_lens_2** to **helmet_faceplate**.
10. Bolt **helmet_faceplate_shell** to **helmet_faceplate**.
11. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_right) in **helmet_faceplate** with its case screws.
12. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_left) in **helmet_faceplate** with its case screws.
13. Bolt **ear_pod_right** to **head**.
14. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (faceplate_servo_right) in **ear_pod_right** with its case screws.
15. Bolt **helmet_back** to **head**.
16. Bolt **helmet_top** to **head**.
17. Bolt **helmet_chin** to **head**.
18. Set joint `left_shoulder` to zero (centre the servo first), then screw **left_upper_arm** to the actuator output in **pelvis**; it moves -80° … 11°.
19. Set joint `left_elbow` to zero (centre the servo first), then screw **left_forearm** to the actuator output in **left_upper_arm**; it moves -109° … 0°.
20. Bolt **left_hand** to **left_forearm**.
21. Bolt **left_hand_4** to **left_hand**.
22. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (left_repulsor) in **left_hand_4** with its case screws.
23. Bolt **left_hand_1** to **left_hand**.
24. Bolt **left_hand_2** to **left_hand**.
25. Bolt **left_hand_3** to **left_hand**.
26. Bolt **left_forearm_1** to **left_forearm**.
27. Bolt **left_forearm_2** to **left_forearm**.
28. Bolt **left_forearm_3** to **left_forearm**.
29. Bolt **left_forearm_4** to **left_forearm**.
30. Bolt **left_forearm_5** to **left_forearm**.
31. Bolt **left_upper_arm_1** to **left_upper_arm**.
32. Bolt **left_upper_arm_2** to **left_upper_arm**.
33. Bolt **left_upper_arm_3** to **left_upper_arm**.
34. Bolt **left_upper_arm_4** to **left_upper_arm**.
35. Bolt **left_upper_arm_5** to **left_upper_arm**.
36. Bolt **left_upper_arm_6** to **left_upper_arm**.
37. Bolt **left_upper_arm_7** to **left_upper_arm**.
38. Bolt **left_upper_arm_8** to **left_upper_arm**.
39. Bolt **left_upper_arm_9** to **left_upper_arm**.
40. Bolt **left_upper_arm_10** to **left_upper_arm**.
41. Bolt **left_upper_arm_11** to **left_upper_arm**.
42. Bolt **left_upper_arm_12** to **left_upper_arm**.
43. Bolt **left_upper_arm_13** to **left_upper_arm**.
44. Bolt **left_upper_arm_14** to **left_upper_arm**.
45. Bolt **left_upper_arm_15** to **left_upper_arm**.
46. Set joint `left_hip` to zero (centre the servo first), then screw **left_thigh** to the actuator output in **pelvis**; it moves -63° … 11°.
47. Set joint `left_knee` to zero (centre the servo first), then screw **left_shin** to the actuator output in **left_thigh**; it moves 0° … 92°.
48. Bolt **left_foot** to **left_shin**.
49. Bolt **left_foot_1** to **left_foot**.
50. Bolt **left_foot_2** to **left_foot**.
51. Bolt **left_shin_1** to **left_shin**.
52. Bolt **left_shin_2** to **left_shin**.
53. Bolt **left_shin_3** to **left_shin**.
54. Bolt **left_shin_4** to **left_shin**.
55. Bolt **left_shin_5** to **left_shin**.
56. Bolt **left_shin_6** to **left_shin**.
57. Bolt **left_thigh_1** to **left_thigh**.
58. Bolt **left_thigh_2** to **left_thigh**.
59. Bolt **left_thigh_3** to **left_thigh**.
60. Bolt **left_thigh_4** to **left_thigh**.
61. Bolt **left_thigh_5** to **left_thigh**.
62. Bolt **left_thigh_6** to **left_thigh**.
63. Bolt **left_thigh_7** to **left_thigh**.
64. Bolt **left_thigh_8** to **left_thigh**.
65. Bolt **left_thigh_9** to **left_thigh**.
66. Set joint `right_shoulder` to zero (centre the servo first), then screw **right_upper_arm** to the actuator output in **pelvis**; it moves -80° … 11°.
67. Set joint `right_elbow` to zero (centre the servo first), then screw **right_forearm** to the actuator output in **right_upper_arm**; it moves -109° … 0°.
68. Bolt **right_hand** to **right_forearm**.
69. Bolt **right_hand_5** to **right_hand**.
70. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (right_repulsor) in **right_hand_5** with its case screws.
71. Bolt **right_hand_1** to **right_hand**.
72. Bolt **right_hand_2** to **right_hand**.
73. Bolt **right_hand_3** to **right_hand**.
74. Bolt **right_forearm_1** to **right_forearm**.
75. Bolt **right_forearm_2** to **right_forearm**.
76. Bolt **right_forearm_3** to **right_forearm**.
77. Bolt **right_forearm_4** to **right_forearm**.
78. Bolt **right_forearm_5** to **right_forearm**.
79. Bolt **right_upper_arm_1** to **right_upper_arm**.
80. Bolt **right_upper_arm_2** to **right_upper_arm**.
81. Bolt **right_upper_arm_3** to **right_upper_arm**.
82. Bolt **right_upper_arm_4** to **right_upper_arm**.
83. Bolt **right_upper_arm_5** to **right_upper_arm**.
84. Bolt **right_upper_arm_6** to **right_upper_arm**.
85. Bolt **right_upper_arm_7** to **right_upper_arm**.
86. Bolt **right_upper_arm_8** to **right_upper_arm**.
87. Bolt **right_upper_arm_9** to **right_upper_arm**.
88. Bolt **right_upper_arm_10** to **right_upper_arm**.
89. Bolt **right_upper_arm_11** to **right_upper_arm**.
90. Bolt **right_upper_arm_12** to **right_upper_arm**.
91. Bolt **right_upper_arm_13** to **right_upper_arm**.
92. Bolt **right_upper_arm_14** to **right_upper_arm**.
93. Bolt **right_upper_arm_15** to **right_upper_arm**.
94. Set joint `right_hip` to zero (centre the servo first), then screw **right_thigh** to the actuator output in **pelvis**; it moves -63° … 11°.
95. Set joint `right_knee` to zero (centre the servo first), then screw **right_shin** to the actuator output in **right_thigh**; it moves 0° … 92°.
96. Bolt **right_foot** to **right_shin**.
97. Bolt **right_foot_1** to **right_foot**.
98. Bolt **right_foot_2** to **right_foot**.
99. Bolt **right_shin_1** to **right_shin**.
100. Bolt **right_shin_2** to **right_shin**.
101. Bolt **right_shin_3** to **right_shin**.
102. Bolt **right_shin_4** to **right_shin**.
103. Bolt **right_shin_5** to **right_shin**.
104. Bolt **right_shin_6** to **right_shin**.
105. Bolt **right_thigh_1** to **right_thigh**.
106. Bolt **right_thigh_2** to **right_thigh**.
107. Bolt **right_thigh_3** to **right_thigh**.
108. Bolt **right_thigh_4** to **right_thigh**.
109. Bolt **right_thigh_5** to **right_thigh**.
110. Bolt **right_thigh_6** to **right_thigh**.
111. Bolt **right_thigh_7** to **right_thigh**.
112. Bolt **right_thigh_8** to **right_thigh**.
113. Bolt **right_thigh_9** to **right_thigh**.
114. Bolt **torso_37** to **pelvis**.
115. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (arc_reactor) in **torso_37** with its case screws.
116. Bolt **torso_46** to **pelvis**.
117. Bolt **torso_1** to **pelvis**.
118. Bolt **torso_2** to **pelvis**.
119. Bolt **torso_3** to **pelvis**.
120. Bolt **torso_4** to **pelvis**.
121. Bolt **torso_5** to **pelvis**.
122. Bolt **torso_6** to **pelvis**.
123. Bolt **torso_7** to **pelvis**.
124. Bolt **torso_8** to **pelvis**.
125. Bolt **torso_9** to **pelvis**.
126. Bolt **torso_10** to **pelvis**.
127. Bolt **torso_11** to **pelvis**.
128. Bolt **torso_12** to **pelvis**.
129. Bolt **torso_13** to **pelvis**.
130. Bolt **torso_14** to **pelvis**.
131. Bolt **torso_15** to **pelvis**.
132. Bolt **torso_16** to **pelvis**.
133. Bolt **torso_17** to **pelvis**.
134. Bolt **torso_18** to **pelvis**.
135. Bolt **torso_19** to **pelvis**.
136. Bolt **torso_20** to **pelvis**.
137. Bolt **torso_21** to **pelvis**.
138. Bolt **torso_22** to **pelvis**.
139. Bolt **torso_23** to **pelvis**.
140. Bolt **torso_24** to **pelvis**.
141. Bolt **torso_25** to **pelvis**.
142. Bolt **torso_26** to **pelvis**.
143. Bolt **torso_27** to **pelvis**.
144. Bolt **torso_28** to **pelvis**.
145. Bolt **torso_29** to **pelvis**.
146. Bolt **torso_30** to **pelvis**.
147. Bolt **torso_31** to **pelvis**.
148. Bolt **torso_32** to **pelvis**.
149. Bolt **torso_33** to **pelvis**.
150. Bolt **torso_34** to **pelvis**.
151. Bolt **torso_35** to **pelvis**.
152. Bolt **torso_36** to **pelvis**.
153. Bolt **torso_38** to **pelvis**.
154. Bolt **torso_39** to **pelvis**.
155. Bolt **torso_40** to **pelvis**.
156. Bolt **torso_41** to **pelvis**.
157. Bolt **torso_42** to **pelvis**.
158. Bolt **torso_43** to **pelvis**.
159. Bolt **torso_44** to **pelvis**.
160. Bolt **torso_45** to **pelvis**.
161. Bolt **electronics_box** to **pelvis**.
162. Mount the **2S 18650 pack: two 2500 mAh 20 A cells (Samsung 25R class) in a plain two-cell holder** (battery) in **electronics_box** with its case screws.
163. Mount the **Arduino Nano compatible board (ATmega328P, CH340, USB-C)** (controller) in **electronics_box** with its case screws.
164. Mount the **LM2596S adjustable buck module (3 A, 43 x 21 mm)** (regulator) in **electronics_box** with its case screws.

## Fasteners

- 4 × M2 self-tapping (servo tabs, from the servo kits)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
