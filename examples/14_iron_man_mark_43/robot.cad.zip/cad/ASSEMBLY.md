# Assembly — iron_man_mark_43

Start from **base_link**.

1. Bolt **pelvis** to **base_link**.
2. Bolt **head** to **pelvis**.
3. Bolt **helmet_cranium_1** to **head**.
4. Bolt **helmet_cranium_2** to **head**.
5. Bolt **helmet_cranium_3** to **head**.
6. Bolt **helmet_cranium_4** to **head**.
7. Bolt **helmet_cranium_5** to **head**.
8. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (faceplate_servo_left) in **helmet_cranium_5** with its case screws.
9. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (faceplate_servo_right) in **helmet_cranium_5** with its case screws.
10. Set joint `faceplate` to zero (centre the servo first), then screw **helmet_faceplate** to the actuator output in **helmet_cranium_5**; it moves -69° … 0°.
11. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_left) in **helmet_faceplate** with its case screws.
12. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_right) in **helmet_faceplate** with its case screws.
13. Bolt **helmet_cranium_6** to **head**.
14. Bolt **helmet_cranium_7** to **head**.
15. Bolt **helmet_cranium_8** to **head**.
16. Set joint `left_shoulder` to zero (centre the servo first), then screw **left_upper_arm** to the actuator output in **pelvis**; it moves -149° … 34°.
17. Set joint `left_elbow` to zero (centre the servo first), then screw **left_forearm** to the actuator output in **left_upper_arm**; it moves -104° … 0°.
18. Bolt **left_hand** to **left_forearm**.
19. Bolt **left_hand_armour_1** to **left_hand**.
20. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (left_repulsor) in **left_hand_armour_1** with its case screws.
21. Bolt **left_hand_armour_2** to **left_hand**.
22. Bolt **left_gauntlet_1** to **left_forearm**.
23. Bolt **left_gauntlet_2** to **left_forearm**.
24. Bolt **left_shoulder_bell_1** to **left_upper_arm**.
25. Bolt **left_shoulder_bell_2** to **left_upper_arm**.
26. Bolt **left_bicep_1** to **left_upper_arm**.
27. Bolt **left_bicep_2** to **left_upper_arm**.
28. Set joint `left_hip` to zero (centre the servo first), then screw **left_thigh** to the actuator output in **pelvis**; it moves -88° … 23°.
29. Set joint `left_knee` to zero (centre the servo first), then screw **left_shin** to the actuator output in **left_thigh**; it moves 0° … 106°.
30. Bolt **left_foot** to **left_shin**.
31. Bolt **left_boot_1** to **left_foot**.
32. Bolt **left_boot_2** to **left_foot**.
33. Bolt **left_boot_3** to **left_foot**.
34. Bolt **left_boot_4** to **left_foot**.
35. Bolt **left_shin_armour_1** to **left_shin**.
36. Bolt **left_shin_armour_2** to **left_shin**.
37. Bolt **left_shin_armour_3** to **left_shin**.
38. Bolt **left_shin_armour_4** to **left_shin**.
39. Bolt **left_thigh_armour_1** to **left_thigh**.
40. Bolt **left_thigh_armour_2** to **left_thigh**.
41. Bolt **left_thigh_armour_3** to **left_thigh**.
42. Bolt **left_thigh_armour_4** to **left_thigh**.
43. Set joint `right_shoulder` to zero (centre the servo first), then screw **right_upper_arm** to the actuator output in **pelvis**; it moves -149° … 34°.
44. Set joint `right_elbow` to zero (centre the servo first), then screw **right_forearm** to the actuator output in **right_upper_arm**; it moves -104° … 0°.
45. Bolt **right_hand** to **right_forearm**.
46. Bolt **right_hand_armour_1** to **right_hand**.
47. Bolt **right_hand_armour_2** to **right_hand**.
48. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (right_repulsor) in **right_hand_armour_2** with its case screws.
49. Bolt **right_gauntlet_1** to **right_forearm**.
50. Bolt **right_gauntlet_2** to **right_forearm**.
51. Bolt **right_shoulder_bell_1** to **right_upper_arm**.
52. Bolt **right_shoulder_bell_2** to **right_upper_arm**.
53. Bolt **right_bicep_1** to **right_upper_arm**.
54. Bolt **right_bicep_2** to **right_upper_arm**.
55. Set joint `right_hip` to zero (centre the servo first), then screw **right_thigh** to the actuator output in **pelvis**; it moves -88° … 23°.
56. Set joint `right_knee` to zero (centre the servo first), then screw **right_shin** to the actuator output in **right_thigh**; it moves 0° … 106°.
57. Bolt **right_foot** to **right_shin**.
58. Bolt **right_boot_1** to **right_foot**.
59. Bolt **right_boot_2** to **right_foot**.
60. Bolt **right_boot_3** to **right_foot**.
61. Bolt **right_boot_4** to **right_foot**.
62. Bolt **right_shin_armour_1** to **right_shin**.
63. Bolt **right_shin_armour_2** to **right_shin**.
64. Bolt **right_shin_armour_3** to **right_shin**.
65. Bolt **right_shin_armour_4** to **right_shin**.
66. Bolt **right_thigh_armour_1** to **right_thigh**.
67. Bolt **right_thigh_armour_2** to **right_thigh**.
68. Bolt **right_thigh_armour_3** to **right_thigh**.
69. Bolt **right_thigh_armour_4** to **right_thigh**.
70. Bolt **chest_1** to **pelvis**.
71. Bolt **chest_2** to **pelvis**.
72. Bolt **chest_3** to **pelvis**.
73. Bolt **chest_4** to **pelvis**.
74. Bolt **chest_5** to **pelvis**.
75. Bolt **chest_6** to **pelvis**.
76. Bolt **chest_7** to **pelvis**.
77. Bolt **chest_8** to **pelvis**.
78. Bolt **chest_9** to **pelvis**.
79. Bolt **chest_10** to **pelvis**.
80. Bolt **chest_11** to **pelvis**.
81. Bolt **chest_12** to **pelvis**.
82. Bolt **chest_13** to **pelvis**.
83. Bolt **chest_14** to **pelvis**.
84. Bolt **chest_15** to **pelvis**.
85. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (arc_reactor) in **chest_15** with its case screws.
86. Bolt **chest_16** to **pelvis**.
87. Bolt **chest_17** to **pelvis**.
88. Bolt **chest_18** to **pelvis**.
89. Bolt **electronics_box** to **pelvis**.
90. Mount the **2S 18650 pack: two 2500 mAh 20 A cells (Samsung 25R class) in a holder with switch** (battery) in **electronics_box** with its case screws.
91. Mount the **Arduino Nano compatible board (ATmega328P, CH340, USB-C)** (controller) in **electronics_box** with its case screws.
92. Mount the **LM2596S adjustable buck module (3 A, 43 x 21 mm)** (regulator) in **electronics_box** with its case screws.
93. Bolt **belt_1** to **pelvis**.
94. Bolt **belt_2** to **pelvis**.

## Fasteners

- 4 × M2 self-tapping (servo tabs, from the servo kits)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
