# Assembly — iron_man_mark_43

Start from **base_link**.

1. Bolt **pelvis** to **base_link**.
2. Bolt **head** to **pelvis**.
3. Bolt **ear_pod_left** to **head**.
4. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (faceplate_servo_left) in **ear_pod_left** with its case screws.
5. Set joint `faceplate` to zero (centre the servo first), then screw **helmet_faceplate** to the actuator output in **ear_pod_left**; it moves -57° … 0°.
6. Bolt **faceplate_arm_left** to **helmet_faceplate**.
7. Bolt **faceplate_arm_right** to **helmet_faceplate**.
8. Bolt **eye_lens_1** to **helmet_faceplate**.
9. Bolt **eye_lens_2** to **helmet_faceplate**.
10. Bolt **helmet_faceplate_shell** to **helmet_faceplate**.
11. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_right) in **helmet_faceplate** with its case screws.
12. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_left) in **helmet_faceplate** with its case screws.
13. Bolt **ear_pod_right** to **head**.
14. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (faceplate_servo_right) in **ear_pod_right** with its case screws.
15. Bolt **helmet_back** to **head**.
16. Bolt **helmet_top** to **head**.
17. Bolt **helmet_chin** to **head**.
18. Set joint `left_shoulder` to zero (centre the servo first), then screw **left_upper_arm** to the actuator output in **pelvis**; it moves -69° … 17°.
19. Set joint `left_elbow` to zero (centre the servo first), then screw **left_forearm** to the actuator output in **left_upper_arm**; it moves -103° … 0°.
20. Bolt **left_hand** to **left_forearm**.
21. Bolt **left_hand_4** to **left_hand**.
22. Bolt **left_hand_6** to **left_hand**.
23. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (left_repulsor) in **left_hand_6** with its case screws.
24. Bolt **left_hand_1** to **left_hand**.
25. Bolt **left_hand_2** to **left_hand**.
26. Bolt **left_hand_3** to **left_hand**.
27. Bolt **left_hand_5** to **left_hand**.
28. Bolt **left_forearm_1** to **left_forearm**.
29. Bolt **left_forearm_2** to **left_forearm**.
30. Bolt **left_forearm_3** to **left_forearm**.
31. Bolt **left_forearm_4** to **left_forearm**.
32. Bolt **left_forearm_5** to **left_forearm**.
33. Bolt **left_forearm_6** to **left_forearm**.
34. Bolt **left_forearm_7** to **left_forearm**.
35. Bolt **left_forearm_8** to **left_forearm**.
36. Bolt **left_upper_arm_1** to **left_upper_arm**.
37. Bolt **left_upper_arm_2** to **left_upper_arm**.
38. Bolt **left_upper_arm_3** to **left_upper_arm**.
39. Bolt **left_upper_arm_4** to **left_upper_arm**.
40. Bolt **left_upper_arm_5** to **left_upper_arm**.
41. Bolt **left_upper_arm_6** to **left_upper_arm**.
42. Bolt **left_upper_arm_7** to **left_upper_arm**.
43. Bolt **left_upper_arm_8** to **left_upper_arm**.
44. Bolt **left_upper_arm_9** to **left_upper_arm**.
45. Bolt **left_upper_arm_10** to **left_upper_arm**.
46. Bolt **left_upper_arm_11** to **left_upper_arm**.
47. Bolt **left_upper_arm_12** to **left_upper_arm**.
48. Bolt **left_upper_arm_13** to **left_upper_arm**.
49. Bolt **left_upper_arm_14** to **left_upper_arm**.
50. Bolt **left_upper_arm_15** to **left_upper_arm**.
51. Set joint `left_hip` to zero (centre the servo first), then screw **left_thigh** to the actuator output in **pelvis**; it moves -109° … 11°.
52. Set joint `left_knee` to zero (centre the servo first), then screw **left_shin** to the actuator output in **left_thigh**; it moves 0° … 92°.
53. Bolt **left_foot** to **left_shin**.
54. Bolt **left_foot_1** to **left_foot**.
55. Bolt **left_foot_2** to **left_foot**.
56. Bolt **left_foot_3** to **left_foot**.
57. Bolt **left_shin_1** to **left_shin**.
58. Bolt **left_shin_2** to **left_shin**.
59. Bolt **left_shin_3** to **left_shin**.
60. Bolt **left_shin_4** to **left_shin**.
61. Bolt **left_shin_5** to **left_shin**.
62. Bolt **left_shin_6** to **left_shin**.
63. Bolt **left_shin_7** to **left_shin**.
64. Bolt **left_shin_8** to **left_shin**.
65. Bolt **left_shin_9** to **left_shin**.
66. Bolt **left_shin_10** to **left_shin**.
67. Bolt **left_shin_11** to **left_shin**.
68. Bolt **left_shin_12** to **left_shin**.
69. Bolt **left_thigh_1** to **left_thigh**.
70. Bolt **left_thigh_2** to **left_thigh**.
71. Bolt **left_thigh_3** to **left_thigh**.
72. Bolt **left_thigh_4** to **left_thigh**.
73. Bolt **left_thigh_5** to **left_thigh**.
74. Bolt **left_thigh_6** to **left_thigh**.
75. Bolt **left_thigh_7** to **left_thigh**.
76. Bolt **left_thigh_8** to **left_thigh**.
77. Set joint `right_shoulder` to zero (centre the servo first), then screw **right_upper_arm** to the actuator output in **pelvis**; it moves -69° … 17°.
78. Set joint `right_elbow` to zero (centre the servo first), then screw **right_forearm** to the actuator output in **right_upper_arm**; it moves -103° … 0°.
79. Bolt **right_hand** to **right_forearm**.
80. Bolt **right_hand_4** to **right_hand**.
81. Bolt **right_hand_6** to **right_hand**.
82. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (right_repulsor) in **right_hand_6** with its case screws.
83. Bolt **right_hand_1** to **right_hand**.
84. Bolt **right_hand_2** to **right_hand**.
85. Bolt **right_hand_3** to **right_hand**.
86. Bolt **right_hand_5** to **right_hand**.
87. Bolt **right_forearm_1** to **right_forearm**.
88. Bolt **right_forearm_2** to **right_forearm**.
89. Bolt **right_forearm_3** to **right_forearm**.
90. Bolt **right_forearm_4** to **right_forearm**.
91. Bolt **right_forearm_5** to **right_forearm**.
92. Bolt **right_forearm_6** to **right_forearm**.
93. Bolt **right_forearm_7** to **right_forearm**.
94. Bolt **right_forearm_8** to **right_forearm**.
95. Bolt **right_forearm_9** to **right_forearm**.
96. Bolt **right_upper_arm_1** to **right_upper_arm**.
97. Bolt **right_upper_arm_1p1** to **right_upper_arm**.
98. Bolt **right_upper_arm_2** to **right_upper_arm**.
99. Bolt **right_upper_arm_3** to **right_upper_arm**.
100. Bolt **right_upper_arm_4** to **right_upper_arm**.
101. Bolt **right_upper_arm_5** to **right_upper_arm**.
102. Bolt **right_upper_arm_6** to **right_upper_arm**.
103. Bolt **right_upper_arm_7** to **right_upper_arm**.
104. Bolt **right_upper_arm_8** to **right_upper_arm**.
105. Bolt **right_upper_arm_9** to **right_upper_arm**.
106. Bolt **right_upper_arm_10** to **right_upper_arm**.
107. Bolt **right_upper_arm_11** to **right_upper_arm**.
108. Bolt **right_upper_arm_12** to **right_upper_arm**.
109. Bolt **right_upper_arm_13** to **right_upper_arm**.
110. Bolt **right_upper_arm_14** to **right_upper_arm**.
111. Bolt **right_upper_arm_15** to **right_upper_arm**.
112. Bolt **right_upper_arm_16** to **right_upper_arm**.
113. Bolt **right_upper_arm_17** to **right_upper_arm**.
114. Set joint `right_hip` to zero (centre the servo first), then screw **right_thigh** to the actuator output in **pelvis**; it moves -97° … 11°.
115. Set joint `right_knee` to zero (centre the servo first), then screw **right_shin** to the actuator output in **right_thigh**; it moves 0° … 92°.
116. Bolt **right_foot** to **right_shin**.
117. Bolt **right_foot_1** to **right_foot**.
118. Bolt **right_foot_2** to **right_foot**.
119. Bolt **right_foot_3** to **right_foot**.
120. Bolt **right_shin_1** to **right_shin**.
121. Bolt **right_shin_2** to **right_shin**.
122. Bolt **right_shin_3** to **right_shin**.
123. Bolt **right_shin_4** to **right_shin**.
124. Bolt **right_shin_5** to **right_shin**.
125. Bolt **right_shin_6** to **right_shin**.
126. Bolt **right_thigh_1** to **right_thigh**.
127. Bolt **right_thigh_2** to **right_thigh**.
128. Bolt **right_thigh_3** to **right_thigh**.
129. Bolt **right_thigh_4** to **right_thigh**.
130. Bolt **right_thigh_5** to **right_thigh**.
131. Bolt **right_thigh_6** to **right_thigh**.
132. Bolt **right_thigh_7** to **right_thigh**.
133. Bolt **right_thigh_8** to **right_thigh**.
134. Bolt **torso_29** to **pelvis**.
135. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (arc_reactor) in **torso_29** with its case screws.
136. Bolt **torso_38** to **pelvis**.
137. Bolt **torso_1** to **pelvis**.
138. Bolt **torso_2** to **pelvis**.
139. Bolt **torso_3** to **pelvis**.
140. Bolt **torso_4** to **pelvis**.
141. Bolt **torso_5** to **pelvis**.
142. Bolt **torso_6** to **pelvis**.
143. Bolt **torso_7** to **pelvis**.
144. Bolt **torso_8** to **pelvis**.
145. Bolt **torso_9** to **pelvis**.
146. Bolt **torso_10** to **pelvis**.
147. Bolt **torso_11** to **pelvis**.
148. Bolt **torso_12** to **pelvis**.
149. Bolt **torso_13** to **pelvis**.
150. Bolt **torso_14** to **pelvis**.
151. Bolt **torso_15** to **pelvis**.
152. Bolt **torso_16** to **pelvis**.
153. Bolt **torso_17** to **pelvis**.
154. Bolt **torso_18** to **pelvis**.
155. Bolt **torso_19** to **pelvis**.
156. Bolt **torso_21** to **pelvis**.
157. Bolt **torso_22** to **pelvis**.
158. Bolt **torso_23** to **pelvis**.
159. Bolt **torso_24** to **pelvis**.
160. Bolt **torso_25** to **pelvis**.
161. Bolt **torso_26** to **pelvis**.
162. Bolt **torso_27** to **pelvis**.
163. Bolt **torso_28** to **pelvis**.
164. Bolt **torso_30** to **pelvis**.
165. Bolt **torso_31** to **pelvis**.
166. Bolt **torso_32** to **pelvis**.
167. Bolt **torso_33** to **pelvis**.
168. Bolt **torso_34** to **pelvis**.
169. Bolt **torso_35** to **pelvis**.
170. Bolt **torso_36** to **pelvis**.
171. Bolt **torso_37** to **pelvis**.
172. Bolt **torso_40** to **pelvis**.
173. Bolt **electronics_box** to **pelvis**.
174. Mount the **2S 18650 pack: two 2500 mAh 20 A cells (Samsung 25R class) in a holder with switch** (battery) in **electronics_box** with its case screws.
175. Mount the **Arduino Nano compatible board (ATmega328P, CH340, USB-C)** (controller) in **electronics_box** with its case screws.
176. Mount the **LM2596S adjustable buck module (3 A, 43 x 21 mm)** (regulator) in **electronics_box** with its case screws.

## Fasteners

- 4 × M2 self-tapping (servo tabs, from the servo kits)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
