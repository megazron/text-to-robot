# Assembly — iron_man_mark_43

Start from **base_link**.

1. Bolt **pelvis** to **base_link**.
2. Bolt **head** to **pelvis**.
3. Bolt **ear_pod_left** to **head**.
4. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (faceplate_servo_left) in **ear_pod_left** with its case screws.
5. Set joint `faceplate` to zero (centre the servo first), then screw **helmet_faceplate** to the actuator output in **ear_pod_left**; it moves -57° … 0°.
6. Bolt **faceplate_arm_left** to **helmet_faceplate**.
7. Bolt **faceplate_arm_right** to **helmet_faceplate**.
8. Bolt **eye_lens_1** to **helmet_faceplate**.
9. Bolt **eye_lens_2** to **helmet_faceplate**.
10. Bolt **helmet_faceplate_a** to **helmet_faceplate**.
11. Bolt **helmet_faceplate_b** to **helmet_faceplate**.
12. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_right) in **helmet_faceplate** with its case screws.
13. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_left) in **helmet_faceplate** with its case screws.
14. Bolt **ear_pod_right** to **head**.
15. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (faceplate_servo_right) in **ear_pod_right** with its case screws.
16. Bolt **helmet_back_lf** to **head**.
17. Bolt **helmet_back_lb** to **head**.
18. Bolt **helmet_back_rf** to **head**.
19. Bolt **helmet_back_rb** to **head**.
20. Bolt **helmet_top_l** to **head**.
21. Bolt **helmet_top_r** to **head**.
22. Bolt **helmet_chin** to **head**.
23. Bolt **helmet_chinp1** to **head**.
24. Set joint `left_shoulder` to zero (centre the servo first), then screw **left_upper_arm** to the actuator output in **pelvis**; it moves -63° … 34°.
25. Set joint `left_elbow` to zero (centre the servo first), then screw **left_forearm** to the actuator output in **left_upper_arm**; it moves -132° … 0°.
26. Bolt **left_hand** to **left_forearm**.
27. Bolt **left_hand_2** to **left_hand**.
28. Bolt **left_hand_4** to **left_hand**.
29. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (left_repulsor) in **left_hand_4** with its case screws.
30. Bolt **left_hand_10** to **left_hand**.
31. Bolt **left_hand_1** to **left_hand**.
32. Bolt **left_hand_3** to **left_hand**.
33. Bolt **left_hand_5** to **left_hand**.
34. Bolt **left_hand_6** to **left_hand**.
35. Bolt **left_hand_7** to **left_hand**.
36. Bolt **left_hand_8** to **left_hand**.
37. Bolt **left_hand_9** to **left_hand**.
38. Bolt **left_hand_11** to **left_hand**.
39. Bolt **left_hand_12** to **left_hand**.
40. Bolt **left_forearm_1** to **left_forearm**.
41. Bolt **left_forearm_2** to **left_forearm**.
42. Bolt **left_forearm_3** to **left_forearm**.
43. Bolt **left_forearm_4** to **left_forearm**.
44. Bolt **left_forearm_5** to **left_forearm**.
45. Bolt **left_forearm_6** to **left_forearm**.
46. Bolt **left_forearm_7** to **left_forearm**.
47. Bolt **left_forearm_8** to **left_forearm**.
48. Bolt **left_forearm_9** to **left_forearm**.
49. Bolt **left_forearm_10** to **left_forearm**.
50. Bolt **left_forearm_11** to **left_forearm**.
51. Bolt **left_upper_arm_1** to **left_upper_arm**.
52. Bolt **left_upper_arm_2** to **left_upper_arm**.
53. Bolt **left_upper_arm_3** to **left_upper_arm**.
54. Bolt **left_upper_arm_4** to **left_upper_arm**.
55. Bolt **left_upper_arm_5** to **left_upper_arm**.
56. Bolt **left_upper_arm_6** to **left_upper_arm**.
57. Bolt **left_upper_arm_7** to **left_upper_arm**.
58. Bolt **left_upper_arm_8** to **left_upper_arm**.
59. Bolt **left_upper_arm_9** to **left_upper_arm**.
60. Bolt **left_upper_arm_10** to **left_upper_arm**.
61. Bolt **left_upper_arm_11** to **left_upper_arm**.
62. Bolt **left_upper_arm_12** to **left_upper_arm**.
63. Bolt **left_upper_arm_13** to **left_upper_arm**.
64. Bolt **left_upper_arm_14** to **left_upper_arm**.
65. Set joint `left_hip` to zero (centre the servo first), then screw **left_thigh** to the actuator output in **pelvis**; it moves -57° … 23°.
66. Set joint `left_knee` to zero (centre the servo first), then screw **left_shin** to the actuator output in **left_thigh**; it moves 0° … 97°.
67. Bolt **left_foot** to **left_shin**.
68. Bolt **left_foot_1** to **left_foot**.
69. Bolt **left_foot_2** to **left_foot**.
70. Bolt **left_shin_1** to **left_shin**.
71. Bolt **left_shin_1p1** to **left_shin**.
72. Bolt **left_shin_2** to **left_shin**.
73. Bolt **left_shin_3** to **left_shin**.
74. Bolt **left_shin_4** to **left_shin**.
75. Bolt **left_shin_4p1** to **left_shin**.
76. Bolt **left_shin_5** to **left_shin**.
77. Bolt **left_shin_6** to **left_shin**.
78. Bolt **left_thigh_1** to **left_thigh**.
79. Bolt **left_thigh_2** to **left_thigh**.
80. Bolt **left_thigh_3** to **left_thigh**.
81. Bolt **left_thigh_4** to **left_thigh**.
82. Bolt **left_thigh_5** to **left_thigh**.
83. Bolt **left_thigh_6** to **left_thigh**.
84. Bolt **left_thigh_7** to **left_thigh**.
85. Bolt **left_thigh_8** to **left_thigh**.
86. Bolt **left_thigh_9** to **left_thigh**.
87. Bolt **left_thigh_10** to **left_thigh**.
88. Bolt **left_thigh_11** to **left_thigh**.
89. Bolt **left_thigh_12** to **left_thigh**.
90. Set joint `right_shoulder` to zero (centre the servo first), then screw **right_upper_arm** to the actuator output in **pelvis**; it moves -63° … 34°.
91. Set joint `right_elbow` to zero (centre the servo first), then screw **right_forearm** to the actuator output in **right_upper_arm**; it moves -126° … 0°.
92. Bolt **right_hand** to **right_forearm**.
93. Bolt **right_hand_4** to **right_hand**.
94. Bolt **right_hand_6** to **right_hand**.
95. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (right_repulsor) in **right_hand_6** with its case screws.
96. Bolt **right_hand_13** to **right_hand**.
97. Bolt **right_hand_1** to **right_hand**.
98. Bolt **right_hand_2** to **right_hand**.
99. Bolt **right_hand_3** to **right_hand**.
100. Bolt **right_hand_5** to **right_hand**.
101. Bolt **right_hand_7** to **right_hand**.
102. Bolt **right_hand_8** to **right_hand**.
103. Bolt **right_hand_9** to **right_hand**.
104. Bolt **right_hand_10** to **right_hand**.
105. Bolt **right_hand_11** to **right_hand**.
106. Bolt **right_hand_12** to **right_hand**.
107. Bolt **right_forearm_1** to **right_forearm**.
108. Bolt **right_forearm_2** to **right_forearm**.
109. Bolt **right_forearm_3** to **right_forearm**.
110. Bolt **right_forearm_4** to **right_forearm**.
111. Bolt **right_forearm_5** to **right_forearm**.
112. Bolt **right_forearm_6** to **right_forearm**.
113. Bolt **right_forearm_7** to **right_forearm**.
114. Bolt **right_upper_arm_1** to **right_upper_arm**.
115. Bolt **right_upper_arm_2** to **right_upper_arm**.
116. Bolt **right_upper_arm_3** to **right_upper_arm**.
117. Bolt **right_upper_arm_4** to **right_upper_arm**.
118. Bolt **right_upper_arm_5** to **right_upper_arm**.
119. Bolt **right_upper_arm_6** to **right_upper_arm**.
120. Bolt **right_upper_arm_7** to **right_upper_arm**.
121. Bolt **right_upper_arm_8** to **right_upper_arm**.
122. Bolt **right_upper_arm_9** to **right_upper_arm**.
123. Bolt **right_upper_arm_10** to **right_upper_arm**.
124. Bolt **right_upper_arm_11** to **right_upper_arm**.
125. Bolt **right_upper_arm_12** to **right_upper_arm**.
126. Bolt **right_upper_arm_13** to **right_upper_arm**.
127. Bolt **right_upper_arm_14** to **right_upper_arm**.
128. Set joint `right_hip` to zero (centre the servo first), then screw **right_thigh** to the actuator output in **pelvis**; it moves -57° … 23°.
129. Set joint `right_knee` to zero (centre the servo first), then screw **right_shin** to the actuator output in **right_thigh**; it moves 0° … 97°.
130. Bolt **right_foot** to **right_shin**.
131. Bolt **right_foot_1** to **right_foot**.
132. Bolt **right_foot_2** to **right_foot**.
133. Bolt **right_shin_1** to **right_shin**.
134. Bolt **right_shin_1p1** to **right_shin**.
135. Bolt **right_shin_2** to **right_shin**.
136. Bolt **right_shin_3** to **right_shin**.
137. Bolt **right_shin_4** to **right_shin**.
138. Bolt **right_shin_4p1** to **right_shin**.
139. Bolt **right_shin_5** to **right_shin**.
140. Bolt **right_shin_6** to **right_shin**.
141. Bolt **right_thigh_1** to **right_thigh**.
142. Bolt **right_thigh_2** to **right_thigh**.
143. Bolt **right_thigh_3** to **right_thigh**.
144. Bolt **right_thigh_4** to **right_thigh**.
145. Bolt **right_thigh_5** to **right_thigh**.
146. Bolt **right_thigh_6** to **right_thigh**.
147. Bolt **right_thigh_7** to **right_thigh**.
148. Bolt **right_thigh_8** to **right_thigh**.
149. Bolt **right_thigh_9** to **right_thigh**.
150. Bolt **right_thigh_10** to **right_thigh**.
151. Bolt **right_thigh_11** to **right_thigh**.
152. Bolt **right_thigh_12** to **right_thigh**.
153. Bolt **torso_42** to **pelvis**.
154. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (arc_reactor) in **torso_42** with its case screws.
155. Bolt **torso_52** to **pelvis**.
156. Bolt **torso_1** to **pelvis**.
157. Bolt **torso_2** to **pelvis**.
158. Bolt **torso_3** to **pelvis**.
159. Bolt **torso_4** to **pelvis**.
160. Bolt **torso_5** to **pelvis**.
161. Bolt **torso_6** to **pelvis**.
162. Bolt **torso_7** to **pelvis**.
163. Bolt **torso_8** to **pelvis**.
164. Bolt **torso_9** to **pelvis**.
165. Bolt **torso_10** to **pelvis**.
166. Bolt **torso_11** to **pelvis**.
167. Bolt **torso_12** to **pelvis**.
168. Bolt **torso_13** to **pelvis**.
169. Bolt **torso_14** to **pelvis**.
170. Bolt **torso_15** to **pelvis**.
171. Bolt **torso_16** to **pelvis**.
172. Bolt **torso_17** to **pelvis**.
173. Bolt **torso_18** to **pelvis**.
174. Bolt **torso_19** to **pelvis**.
175. Bolt **torso_20** to **pelvis**.
176. Bolt **torso_21** to **pelvis**.
177. Bolt **torso_22** to **pelvis**.
178. Bolt **torso_23** to **pelvis**.
179. Bolt **torso_24** to **pelvis**.
180. Bolt **torso_25** to **pelvis**.
181. Bolt **torso_26** to **pelvis**.
182. Bolt **torso_27** to **pelvis**.
183. Bolt **torso_28** to **pelvis**.
184. Bolt **torso_29** to **pelvis**.
185. Bolt **torso_30** to **pelvis**.
186. Bolt **torso_31** to **pelvis**.
187. Bolt **torso_32** to **pelvis**.
188. Bolt **torso_33** to **pelvis**.
189. Bolt **torso_34** to **pelvis**.
190. Bolt **torso_35** to **pelvis**.
191. Bolt **torso_36** to **pelvis**.
192. Bolt **torso_37** to **pelvis**.
193. Bolt **torso_38** to **pelvis**.
194. Bolt **torso_39** to **pelvis**.
195. Bolt **torso_40** to **pelvis**.
196. Bolt **torso_41** to **pelvis**.
197. Bolt **torso_43** to **pelvis**.
198. Bolt **torso_44** to **pelvis**.
199. Bolt **torso_45** to **pelvis**.
200. Bolt **torso_46** to **pelvis**.
201. Bolt **torso_47** to **pelvis**.
202. Bolt **torso_48** to **pelvis**.
203. Bolt **torso_49** to **pelvis**.
204. Bolt **torso_50** to **pelvis**.
205. Bolt **torso_51** to **pelvis**.
206. Bolt **torso_53** to **pelvis**.
207. Bolt **electronics_box** to **pelvis**.
208. Mount the **2S 18650 pack: two 2500 mAh 20 A cells (Samsung 25R class) in a plain two-cell holder** (battery) in **electronics_box** with its case screws.
209. Mount the **Arduino Nano compatible board (ATmega328P, CH340, USB-C)** (controller) in **electronics_box** with its case screws.
210. Mount the **LM2596S adjustable buck module (3 A, 43 x 21 mm)** (regulator) in **electronics_box** with its case screws.

## Fasteners

- 4 × M2 self-tapping (servo tabs, from the servo kits)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
