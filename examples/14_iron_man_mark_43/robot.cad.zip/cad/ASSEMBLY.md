# Assembly: iron_man_mark_43

Start from **base_link**.

1. Bolt **pelvis** to **base_link**.
2. Set joint `neck` to zero (centre the servo first), then screw **head** to the actuator output in **pelvis**; it moves -69° … 69°.
3. Bolt **ear_pod_left** to **head**.
4. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (faceplate_servo_left) in **ear_pod_left** with its case screws.
5. Set joint `faceplate` to zero (centre the servo first), then screw **helmet_faceplate** to the actuator output in **ear_pod_left**; it moves -57° … 0°.
6. Bolt **faceplate_arm_left** to **helmet_faceplate**.
7. Bolt **faceplate_arm_right** to **helmet_faceplate**.
8. Bolt **helmet_8** to **helmet_faceplate**.
9. Bolt **helmet_9** to **helmet_faceplate**.
10. Bolt **helmet_0** to **helmet_faceplate**.
11. Bolt **helmet_1** to **helmet_faceplate**.
12. Bolt **helmet_2** to **helmet_faceplate**.
13. Bolt **helmet_3** to **helmet_faceplate**.
14. Bolt **helmet_4** to **helmet_faceplate**.
15. Bolt **helmet_5** to **helmet_faceplate**.
16. Bolt **helmet_6** to **helmet_faceplate**.
17. Bolt **helmet_7** to **helmet_faceplate**.
18. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_right) in **helmet_faceplate** with its case screws.
19. Mount the **5 mm white LED + 100 ohm resistor (eye / accent light)** (eye_led_left) in **helmet_faceplate** with its case screws.
20. Bolt **ear_pod_right** to **head**.
21. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (faceplate_servo_right) in **ear_pod_right** with its case screws.
22. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (helmet_left_servo) in **head** with its case screws.
23. Set joint `helmet_door_left_hinge` to zero (centre the servo first), then screw **helmet_door_left** to the actuator output in **head**; it moves -80° … 0°.
24. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_helmet_left_0_servo) in **helmet_door_left** with its case screws.
25. Set joint `latch_helmet_left_0_pawl` to zero (centre the servo first), then screw **latch_helmet_left_0_pawl_link** to the actuator output in **helmet_door_left**; it moves 0° … 11°.
26. Bolt **latch_helmet_left_0_pawl** to **latch_helmet_left_0_pawl_link**.
27. Bolt **helmet_14** to **helmet_door_left**.
28. Bolt **helmet_15** to **helmet_door_left**.
29. Bolt **hinge_helmet_left_0_knuckle** to **helmet_door_left**.
30. Bolt **hinge_helmet_left_1_knuckle** to **helmet_door_left**.
31. Bolt **arm_helmet_left** to **helmet_door_left**.
32. Bolt **latch_helmet_left_0_block** to **helmet_door_left**.
33. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (helmet_right_servo) in **head** with its case screws.
34. Set joint `helmet_door_right_hinge` to zero (centre the servo first), then screw **helmet_door_right** to the actuator output in **head**; it moves 0° … 80°.
35. Bolt **helmet_16** to **helmet_door_right**.
36. Bolt **helmet_17** to **helmet_door_right**.
37. Bolt **hinge_helmet_right_0_knuckle** to **helmet_door_right**.
38. Bolt **hinge_helmet_right_1_knuckle** to **helmet_door_right**.
39. Bolt **arm_helmet_right** to **helmet_door_right**.
40. Bolt **latch_helmet_left_0_ledge** to **helmet_door_right**.
41. Bolt **helmet_10** to **head**.
42. Bolt **helmet_11** to **head**.
43. Bolt **helmet_12** to **head**.
44. Bolt **helmet_13** to **head**.
45. Bolt **hinge_helmet_left_0** to **head**.
46. Bolt **hinge_helmet_left_1** to **head**.
47. Bolt **pod_helmet_left** to **head**.
48. Bolt **hinge_helmet_right_0** to **head**.
49. Bolt **hinge_helmet_right_1** to **head**.
50. Bolt **pod_helmet_right** to **head**.
51. Bolt **chan_left_helmet_0** to **head**.
52. Bolt **chan_right_helmet_0** to **head**.
53. Set joint `left_shoulder` to zero (centre the servo first), then screw **left_upper_arm** to the actuator output in **pelvis**; it moves -57° … 11°.
54. Set joint `left_elbow` to zero (centre the servo first), then screw **left_forearm** to the actuator output in **left_upper_arm**; it moves -112° … 0°.
55. Bolt **left_hand** to **left_forearm**.
56. Bolt **left_palm_lens** to **left_hand**.
57. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (left_repulsor) in **left_palm_lens** with its case screws.
58. Bolt **left_hand_0** to **left_hand**.
59. Bolt **left_hand_1** to **left_hand**.
60. Bolt **left_hand_2** to **left_hand**.
61. Bolt **left_hand_3** to **left_hand**.
62. Bolt **left_hand_4** to **left_hand**.
63. Bolt **left_hand_5** to **left_hand**.
64. Bolt **left_hand_6** to **left_hand**.
65. Bolt **left_hand_7** to **left_hand**.
66. Bolt **left_hand_8** to **left_hand**.
67. Bolt **left_hand_9** to **left_hand**.
68. Bolt **left_hand_10** to **left_hand**.
69. Bolt **left_hand_11** to **left_hand**.
70. Bolt **left_hand_12** to **left_hand**.
71. Bolt **left_hand_13** to **left_hand**.
72. Bolt **left_hand_14** to **left_hand**.
73. Bolt **left_hand_15** to **left_hand**.
74. Bolt **left_hand_16** to **left_hand**.
75. Bolt **left_hand_17** to **left_hand**.
76. Bolt **left_hand_18** to **left_hand**.
77. Bolt **left_mech_wrist_0** to **left_hand**.
78. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (left_forearm_servo) in **left_forearm** with its case screws.
79. Set joint `left_forearm_door_hinge` to zero (centre the servo first), then screw **left_forearm_door** to the actuator output in **left_forearm**; it moves -80° … 0°.
80. Bolt **left_forearm_0** to **left_forearm_door**.
81. Bolt **left_forearm_1** to **left_forearm_door**.
82. Bolt **left_forearm_2** to **left_forearm_door**.
83. Bolt **left_forearm_3** to **left_forearm_door**.
84. Bolt **left_mech_elbow_0** to **left_forearm_door**.
85. Bolt **hinge_left_forearm_0_knuckle** to **left_forearm_door**.
86. Bolt **hinge_left_forearm_1_knuckle** to **left_forearm_door**.
87. Bolt **arm_left_forearm** to **left_forearm_door**.
88. Bolt **latch_left_forearm_0_ledge** to **left_forearm_door**.
89. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_left_forearm_0_servo) in **left_forearm** with its case screws.
90. Set joint `latch_left_forearm_0_pawl` to zero (centre the servo first), then screw **latch_left_forearm_0_pawl_link** to the actuator output in **left_forearm**; it moves -11° … 0°.
91. Bolt **latch_left_forearm_0_pawl** to **latch_left_forearm_0_pawl_link**.
92. Bolt **left_forearm_4** to **left_forearm**.
93. Bolt **left_forearm_5** to **left_forearm**.
94. Bolt **left_forearm_6** to **left_forearm**.
95. Bolt **left_forearm_7** to **left_forearm**.
96. Bolt **left_forearm_8** to **left_forearm**.
97. Bolt **left_forearm_9** to **left_forearm**.
98. Bolt **left_mech_elbow_1** to **left_forearm**.
99. Bolt **left_mech_elbow_1p1** to **left_forearm**.
100. Bolt **left_mech_elbow_2** to **left_forearm**.
101. Bolt **hinge_left_forearm_0** to **left_forearm**.
102. Bolt **hinge_left_forearm_1** to **left_forearm**.
103. Bolt **pod_left_forearm** to **left_forearm**.
104. Bolt **latch_left_forearm_0_block** to **left_forearm**.
105. Bolt **chan_left_forearm_0** to **left_forearm**.
106. Bolt **chan_left_forearm_1** to **left_forearm**.
107. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (left_upper_arm_servo) in **left_upper_arm** with its case screws.
108. Set joint `left_upper_arm_door_hinge` to zero (centre the servo first), then screw **left_upper_arm_door** to the actuator output in **left_upper_arm**; it moves -80° … 0°.
109. Bolt **left_upper_arm_0** to **left_upper_arm_door**.
110. Bolt **left_upper_arm_1** to **left_upper_arm_door**.
111. Bolt **left_upper_arm_2** to **left_upper_arm_door**.
112. Bolt **left_upper_arm_3** to **left_upper_arm_door**.
113. Bolt **left_mech_shoulder_0** to **left_upper_arm_door**.
114. Bolt **hinge_left_upper_arm_0_knuckle** to **left_upper_arm_door**.
115. Bolt **hinge_left_upper_arm_1_knuckle** to **left_upper_arm_door**.
116. Bolt **arm_left_upper_arm** to **left_upper_arm_door**.
117. Bolt **latch_left_upper_arm_0_ledge** to **left_upper_arm_door**.
118. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_left_upper_arm_0_servo) in **left_upper_arm** with its case screws.
119. Set joint `latch_left_upper_arm_0_pawl` to zero (centre the servo first), then screw **latch_left_upper_arm_0_pawl_link** to the actuator output in **left_upper_arm**; it moves -11° … 0°.
120. Bolt **latch_left_upper_arm_0_pawl** to **latch_left_upper_arm_0_pawl_link**.
121. Bolt **left_upper_arm_4** to **left_upper_arm**.
122. Bolt **left_upper_arm_5** to **left_upper_arm**.
123. Bolt **left_upper_arm_6** to **left_upper_arm**.
124. Bolt **left_upper_arm_7** to **left_upper_arm**.
125. Bolt **left_mech_shoulder_1** to **left_upper_arm**.
126. Bolt **hinge_left_upper_arm_0** to **left_upper_arm**.
127. Bolt **hinge_left_upper_arm_1** to **left_upper_arm**.
128. Bolt **pod_left_upper_arm** to **left_upper_arm**.
129. Bolt **latch_left_upper_arm_0_block** to **left_upper_arm**.
130. Bolt **chan_left_upper_arm_0** to **left_upper_arm**.
131. Set joint `left_hip` to zero (centre the servo first), then screw **left_thigh** to the actuator output in **pelvis**; it moves -57° … 11°.
132. Set joint `left_knee` to zero (centre the servo first), then screw **left_shin** to the actuator output in **left_thigh**; it moves 0° … 100°.
133. Bolt **left_foot** to **left_shin**.
134. Bolt **left_foot_0** to **left_foot**.
135. Bolt **left_foot_1** to **left_foot**.
136. Bolt **left_foot_2** to **left_foot**.
137. Bolt **left_foot_3** to **left_foot**.
138. Bolt **left_mech_ankle_0** to **left_foot**.
139. Bolt **left_mech_ankle_0p1** to **left_foot**.
140. Bolt **left_mech_ankle_0p2** to **left_foot**.
141. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (left_shin_servo) in **left_shin** with its case screws.
142. Set joint `left_shin_door_hinge` to zero (centre the servo first), then screw **left_shin_door** to the actuator output in **left_shin**; it moves -80° … 0°.
143. Bolt **left_shin_0** to **left_shin_door**.
144. Bolt **left_shin_1** to **left_shin_door**.
145. Bolt **left_mech_knee_0** to **left_shin_door**.
146. Bolt **left_mech_knee_0p1** to **left_shin_door**.
147. Bolt **left_mech_knee_1** to **left_shin_door**.
148. Bolt **hinge_left_shin_0_knuckle** to **left_shin_door**.
149. Bolt **hinge_left_shin_1_knuckle** to **left_shin_door**.
150. Bolt **arm_left_shin** to **left_shin_door**.
151. Bolt **latch_left_shin_0_ledge** to **left_shin_door**.
152. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_left_shin_0_servo) in **left_shin** with its case screws.
153. Set joint `latch_left_shin_0_pawl` to zero (centre the servo first), then screw **latch_left_shin_0_pawl_link** to the actuator output in **left_shin**; it moves -11° … 0°.
154. Bolt **latch_left_shin_0_pawl** to **latch_left_shin_0_pawl_link**.
155. Bolt **left_shin_2** to **left_shin**.
156. Bolt **left_shin_3** to **left_shin**.
157. Bolt **left_shin_4** to **left_shin**.
158. Bolt **left_shin_5** to **left_shin**.
159. Bolt **left_mech_knee_2** to **left_shin**.
160. Bolt **hinge_left_shin_0** to **left_shin**.
161. Bolt **hinge_left_shin_1** to **left_shin**.
162. Bolt **pod_left_shin** to **left_shin**.
163. Bolt **latch_left_shin_0_block** to **left_shin**.
164. Bolt **chan_left_shin_0** to **left_shin**.
165. Bolt **chan_left_shin_1** to **left_shin**.
166. Bolt **chan_left_shin_2** to **left_shin**.
167. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (left_thigh_servo) in **left_thigh** with its case screws.
168. Set joint `left_thigh_door_hinge` to zero (centre the servo first), then screw **left_thigh_door** to the actuator output in **left_thigh**; it moves -80° … 0°.
169. Bolt **left_thigh_0** to **left_thigh_door**.
170. Bolt **left_thigh_1** to **left_thigh_door**.
171. Bolt **left_thigh_2** to **left_thigh_door**.
172. Bolt **left_thigh_2w1** to **left_thigh_door**.
173. Bolt **left_thigh_3** to **left_thigh_door**.
174. Bolt **left_thigh_4** to **left_thigh_door**.
175. Bolt **left_thigh_5** to **left_thigh_door**.
176. Bolt **left_thigh_6** to **left_thigh_door**.
177. Bolt **left_mech_hip_0** to **left_thigh_door**.
178. Bolt **left_mech_hip_0p1** to **left_thigh_door**.
179. Bolt **hinge_left_thigh_0_knuckle** to **left_thigh_door**.
180. Bolt **hinge_left_thigh_1_knuckle** to **left_thigh_door**.
181. Bolt **arm_left_thigh** to **left_thigh_door**.
182. Bolt **latch_left_thigh_0_ledge** to **left_thigh_door**.
183. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_left_thigh_0_servo) in **left_thigh** with its case screws.
184. Set joint `latch_left_thigh_0_pawl` to zero (centre the servo first), then screw **latch_left_thigh_0_pawl_link** to the actuator output in **left_thigh**; it moves -11° … 0°.
185. Bolt **latch_left_thigh_0_pawl** to **latch_left_thigh_0_pawl_link**.
186. Bolt **left_thigh_7** to **left_thigh**.
187. Bolt **left_thigh_8** to **left_thigh**.
188. Bolt **left_thigh_9** to **left_thigh**.
189. Bolt **left_thigh_10** to **left_thigh**.
190. Bolt **left_thigh_11** to **left_thigh**.
191. Bolt **left_thigh_12** to **left_thigh**.
192. Bolt **left_thigh_12w1** to **left_thigh**.
193. Bolt **left_thigh_13** to **left_thigh**.
194. Bolt **left_thigh_14** to **left_thigh**.
195. Bolt **left_thigh_15** to **left_thigh**.
196. Bolt **left_thigh_16** to **left_thigh**.
197. Bolt **left_thigh_17** to **left_thigh**.
198. Bolt **left_mech_hip_1** to **left_thigh**.
199. Bolt **left_mech_hip_1p1** to **left_thigh**.
200. Bolt **left_mech_hip_2** to **left_thigh**.
201. Bolt **hinge_left_thigh_0** to **left_thigh**.
202. Bolt **hinge_left_thigh_1** to **left_thigh**.
203. Bolt **pod_left_thigh** to **left_thigh**.
204. Bolt **latch_left_thigh_0_block** to **left_thigh**.
205. Bolt **chan_left_thigh_0** to **left_thigh**.
206. Bolt **chan_left_thigh_1** to **left_thigh**.
207. Bolt **chan_left_thigh_2** to **left_thigh**.
208. Set joint `right_shoulder` to zero (centre the servo first), then screw **right_upper_arm** to the actuator output in **pelvis**; it moves -57° … 11°.
209. Set joint `right_elbow` to zero (centre the servo first), then screw **right_forearm** to the actuator output in **right_upper_arm**; it moves -112° … 0°.
210. Bolt **right_hand** to **right_forearm**.
211. Bolt **right_palm_lens** to **right_hand**.
212. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (right_repulsor) in **right_palm_lens** with its case screws.
213. Bolt **right_hand_0** to **right_hand**.
214. Bolt **right_hand_1** to **right_hand**.
215. Bolt **right_hand_2** to **right_hand**.
216. Bolt **right_hand_3** to **right_hand**.
217. Bolt **right_hand_4** to **right_hand**.
218. Bolt **right_hand_5** to **right_hand**.
219. Bolt **right_hand_6** to **right_hand**.
220. Bolt **right_hand_7** to **right_hand**.
221. Bolt **right_hand_8** to **right_hand**.
222. Bolt **right_hand_9** to **right_hand**.
223. Bolt **right_hand_10** to **right_hand**.
224. Bolt **right_hand_11** to **right_hand**.
225. Bolt **right_hand_12** to **right_hand**.
226. Bolt **right_hand_13** to **right_hand**.
227. Bolt **right_hand_14** to **right_hand**.
228. Bolt **right_hand_15** to **right_hand**.
229. Bolt **right_hand_16** to **right_hand**.
230. Bolt **right_hand_17** to **right_hand**.
231. Bolt **right_hand_18** to **right_hand**.
232. Bolt **right_mech_wrist_0** to **right_hand**.
233. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (right_forearm_servo) in **right_forearm** with its case screws.
234. Set joint `right_forearm_door_hinge` to zero (centre the servo first), then screw **right_forearm_door** to the actuator output in **right_forearm**; it moves 0° … 80°.
235. Bolt **right_forearm_0** to **right_forearm_door**.
236. Bolt **right_forearm_1** to **right_forearm_door**.
237. Bolt **right_forearm_2** to **right_forearm_door**.
238. Bolt **right_forearm_3** to **right_forearm_door**.
239. Bolt **right_mech_elbow_0** to **right_forearm_door**.
240. Bolt **hinge_right_forearm_0_knuckle** to **right_forearm_door**.
241. Bolt **hinge_right_forearm_1_knuckle** to **right_forearm_door**.
242. Bolt **arm_right_forearm** to **right_forearm_door**.
243. Bolt **latch_right_forearm_0_ledge** to **right_forearm_door**.
244. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_right_forearm_0_servo) in **right_forearm** with its case screws.
245. Set joint `latch_right_forearm_0_pawl` to zero (centre the servo first), then screw **latch_right_forearm_0_pawl_link** to the actuator output in **right_forearm**; it moves 0° … 11°.
246. Bolt **latch_right_forearm_0_pawl** to **latch_right_forearm_0_pawl_link**.
247. Bolt **right_forearm_4** to **right_forearm**.
248. Bolt **right_forearm_5** to **right_forearm**.
249. Bolt **right_forearm_6** to **right_forearm**.
250. Bolt **right_forearm_7** to **right_forearm**.
251. Bolt **right_forearm_8** to **right_forearm**.
252. Bolt **right_forearm_9** to **right_forearm**.
253. Bolt **right_mech_elbow_1** to **right_forearm**.
254. Bolt **right_mech_elbow_1p1** to **right_forearm**.
255. Bolt **right_mech_elbow_2** to **right_forearm**.
256. Bolt **hinge_right_forearm_0** to **right_forearm**.
257. Bolt **hinge_right_forearm_1** to **right_forearm**.
258. Bolt **pod_right_forearm** to **right_forearm**.
259. Bolt **latch_right_forearm_0_block** to **right_forearm**.
260. Bolt **chan_right_forearm_0** to **right_forearm**.
261. Bolt **chan_right_forearm_1** to **right_forearm**.
262. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (right_upper_arm_servo) in **right_upper_arm** with its case screws.
263. Set joint `right_upper_arm_door_hinge` to zero (centre the servo first), then screw **right_upper_arm_door** to the actuator output in **right_upper_arm**; it moves 0° … 80°.
264. Bolt **right_upper_arm_0** to **right_upper_arm_door**.
265. Bolt **right_upper_arm_1** to **right_upper_arm_door**.
266. Bolt **right_upper_arm_2** to **right_upper_arm_door**.
267. Bolt **right_upper_arm_3** to **right_upper_arm_door**.
268. Bolt **right_mech_shoulder_0** to **right_upper_arm_door**.
269. Bolt **hinge_right_upper_arm_0_knuckle** to **right_upper_arm_door**.
270. Bolt **hinge_right_upper_arm_1_knuckle** to **right_upper_arm_door**.
271. Bolt **arm_right_upper_arm** to **right_upper_arm_door**.
272. Bolt **latch_right_upper_arm_0_ledge** to **right_upper_arm_door**.
273. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_right_upper_arm_0_servo) in **right_upper_arm** with its case screws.
274. Set joint `latch_right_upper_arm_0_pawl` to zero (centre the servo first), then screw **latch_right_upper_arm_0_pawl_link** to the actuator output in **right_upper_arm**; it moves 0° … 11°.
275. Bolt **latch_right_upper_arm_0_pawl** to **latch_right_upper_arm_0_pawl_link**.
276. Bolt **right_upper_arm_4** to **right_upper_arm**.
277. Bolt **right_upper_arm_5** to **right_upper_arm**.
278. Bolt **right_upper_arm_6** to **right_upper_arm**.
279. Bolt **right_upper_arm_7** to **right_upper_arm**.
280. Bolt **right_mech_shoulder_1** to **right_upper_arm**.
281. Bolt **hinge_right_upper_arm_0** to **right_upper_arm**.
282. Bolt **hinge_right_upper_arm_1** to **right_upper_arm**.
283. Bolt **pod_right_upper_arm** to **right_upper_arm**.
284. Bolt **latch_right_upper_arm_0_block** to **right_upper_arm**.
285. Bolt **chan_right_upper_arm_0** to **right_upper_arm**.
286. Set joint `right_hip` to zero (centre the servo first), then screw **right_thigh** to the actuator output in **pelvis**; it moves -57° … 11°.
287. Set joint `right_knee` to zero (centre the servo first), then screw **right_shin** to the actuator output in **right_thigh**; it moves 0° … 100°.
288. Bolt **right_foot** to **right_shin**.
289. Bolt **right_foot_0** to **right_foot**.
290. Bolt **right_foot_1** to **right_foot**.
291. Bolt **right_foot_2** to **right_foot**.
292. Bolt **right_foot_3** to **right_foot**.
293. Bolt **right_mech_ankle_0** to **right_foot**.
294. Bolt **right_mech_ankle_0p1** to **right_foot**.
295. Bolt **right_mech_ankle_0p2** to **right_foot**.
296. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (right_shin_servo) in **right_shin** with its case screws.
297. Set joint `right_shin_door_hinge` to zero (centre the servo first), then screw **right_shin_door** to the actuator output in **right_shin**; it moves 0° … 80°.
298. Bolt **right_shin_0** to **right_shin_door**.
299. Bolt **right_shin_1** to **right_shin_door**.
300. Bolt **right_mech_knee_0** to **right_shin_door**.
301. Bolt **right_mech_knee_0p1** to **right_shin_door**.
302. Bolt **right_mech_knee_1** to **right_shin_door**.
303. Bolt **hinge_right_shin_0_knuckle** to **right_shin_door**.
304. Bolt **hinge_right_shin_1_knuckle** to **right_shin_door**.
305. Bolt **arm_right_shin** to **right_shin_door**.
306. Bolt **latch_right_shin_0_ledge** to **right_shin_door**.
307. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_right_shin_0_servo) in **right_shin** with its case screws.
308. Set joint `latch_right_shin_0_pawl` to zero (centre the servo first), then screw **latch_right_shin_0_pawl_link** to the actuator output in **right_shin**; it moves 0° … 11°.
309. Bolt **latch_right_shin_0_pawl** to **latch_right_shin_0_pawl_link**.
310. Bolt **right_shin_2** to **right_shin**.
311. Bolt **right_shin_3** to **right_shin**.
312. Bolt **right_shin_4** to **right_shin**.
313. Bolt **right_shin_5** to **right_shin**.
314. Bolt **right_mech_knee_2** to **right_shin**.
315. Bolt **hinge_right_shin_0** to **right_shin**.
316. Bolt **hinge_right_shin_1** to **right_shin**.
317. Bolt **pod_right_shin** to **right_shin**.
318. Bolt **latch_right_shin_0_block** to **right_shin**.
319. Bolt **chan_right_shin_0** to **right_shin**.
320. Bolt **chan_right_shin_1** to **right_shin**.
321. Bolt **chan_right_shin_2** to **right_shin**.
322. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (right_thigh_servo) in **right_thigh** with its case screws.
323. Set joint `right_thigh_door_hinge` to zero (centre the servo first), then screw **right_thigh_door** to the actuator output in **right_thigh**; it moves 0° … 80°.
324. Bolt **right_thigh_0** to **right_thigh_door**.
325. Bolt **right_thigh_1** to **right_thigh_door**.
326. Bolt **right_thigh_2** to **right_thigh_door**.
327. Bolt **right_thigh_2w1** to **right_thigh_door**.
328. Bolt **right_thigh_3** to **right_thigh_door**.
329. Bolt **right_thigh_4** to **right_thigh_door**.
330. Bolt **right_thigh_5** to **right_thigh_door**.
331. Bolt **right_thigh_6** to **right_thigh_door**.
332. Bolt **right_mech_hip_0** to **right_thigh_door**.
333. Bolt **right_mech_hip_0p1** to **right_thigh_door**.
334. Bolt **hinge_right_thigh_0_knuckle** to **right_thigh_door**.
335. Bolt **hinge_right_thigh_1_knuckle** to **right_thigh_door**.
336. Bolt **arm_right_thigh** to **right_thigh_door**.
337. Bolt **latch_right_thigh_0_ledge** to **right_thigh_door**.
338. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_right_thigh_0_servo) in **right_thigh** with its case screws.
339. Set joint `latch_right_thigh_0_pawl` to zero (centre the servo first), then screw **latch_right_thigh_0_pawl_link** to the actuator output in **right_thigh**; it moves 0° … 11°.
340. Bolt **latch_right_thigh_0_pawl** to **latch_right_thigh_0_pawl_link**.
341. Bolt **right_thigh_7** to **right_thigh**.
342. Bolt **right_thigh_8** to **right_thigh**.
343. Bolt **right_thigh_9** to **right_thigh**.
344. Bolt **right_thigh_10** to **right_thigh**.
345. Bolt **right_thigh_11** to **right_thigh**.
346. Bolt **right_thigh_12** to **right_thigh**.
347. Bolt **right_thigh_12w1** to **right_thigh**.
348. Bolt **right_thigh_13** to **right_thigh**.
349. Bolt **right_thigh_14** to **right_thigh**.
350. Bolt **right_thigh_15** to **right_thigh**.
351. Bolt **right_thigh_16** to **right_thigh**.
352. Bolt **right_thigh_17** to **right_thigh**.
353. Bolt **right_mech_hip_1** to **right_thigh**.
354. Bolt **right_mech_hip_1p1** to **right_thigh**.
355. Bolt **right_mech_hip_2** to **right_thigh**.
356. Bolt **hinge_right_thigh_0** to **right_thigh**.
357. Bolt **hinge_right_thigh_1** to **right_thigh**.
358. Bolt **pod_right_thigh** to **right_thigh**.
359. Bolt **latch_right_thigh_0_block** to **right_thigh**.
360. Bolt **chan_right_thigh_0** to **right_thigh**.
361. Bolt **chan_right_thigh_1** to **right_thigh**.
362. Bolt **chan_right_thigh_2** to **right_thigh**.
363. Mount the **DSSERVO DS3218 20 kg digital servo (metal gears) + round horn** (back_left_servo) in **pelvis** with its case screws.
364. Set joint `back_door_left_hinge` to zero (centre the servo first), then screw **back_door_left** to the actuator output in **pelvis**; it moves -80° … 0°.
365. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_back_left_0_servo) in **back_door_left** with its case screws.
366. Set joint `latch_back_left_0_pawl` to zero (centre the servo first), then screw **latch_back_left_0_pawl_link** to the actuator output in **back_door_left**; it moves 0° … 11°.
367. Bolt **latch_back_left_0_pawl** to **latch_back_left_0_pawl_link**.
368. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (latch_back_left_1_servo) in **back_door_left** with its case screws.
369. Set joint `latch_back_left_1_pawl` to zero (centre the servo first), then screw **latch_back_left_1_pawl_link** to the actuator output in **back_door_left**; it moves 0° … 11°.
370. Bolt **latch_back_left_1_pawl** to **latch_back_left_1_pawl_link**.
371. Bolt **torso_0** to **back_door_left**.
372. Bolt **torso_1** to **back_door_left**.
373. Bolt **torso_2** to **back_door_left**.
374. Bolt **torso_3** to **back_door_left**.
375. Bolt **torso_4** to **back_door_left**.
376. Bolt **torso_5** to **back_door_left**.
377. Bolt **torso_6** to **back_door_left**.
378. Bolt **torso_7** to **back_door_left**.
379. Bolt **torso_8** to **back_door_left**.
380. Bolt **hinge_back_left_0_knuckle** to **back_door_left**.
381. Bolt **hinge_back_left_1_knuckle** to **back_door_left**.
382. Bolt **arm_back_left** to **back_door_left**.
383. Bolt **latch_back_left_0_block** to **back_door_left**.
384. Bolt **latch_back_left_1_block** to **back_door_left**.
385. Bolt **bay_saddle** to **back_door_left**.
386. Bolt **chan_door_left_0** to **back_door_left**.
387. Bolt **back_bay** to **back_door_left**.
388. Bolt **back_bay_lid** to **back_bay**.
389. Mount the **2S 18650 pack: two 2500 mAh 20 A cells (Samsung 25R class) in a plain two-cell holder** (battery) in **back_bay** with its case screws.
390. Mount the **LM2596S adjustable buck module (3 A, 43 x 21 mm)** (regulator) in **back_bay** with its case screws.
391. Mount the **LM2596S adjustable buck module (3 A, 43 x 21 mm)** (regulator_lights) in **back_bay** with its case screws.
392. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_doors) in **back_bay** with its case screws.
393. Mount the **Arduino Nano compatible board (ATmega328P, CH340, USB-C)** (controller) in **back_bay** with its case screws.
394. Mount the **KCD1 rocker switch, SPST, 6 A 250 VAC / 10 A 125 VAC** (main_switch) in **back_bay** with its case screws.
395. Mount the **DSSERVO DS3218 20 kg digital servo (metal gears) + round horn** (back_right_servo) in **pelvis** with its case screws.
396. Set joint `back_door_right_hinge` to zero (centre the servo first), then screw **back_door_right** to the actuator output in **pelvis**; it moves 0° … 80°.
397. Bolt **torso_9** to **back_door_right**.
398. Bolt **torso_10** to **back_door_right**.
399. Bolt **torso_11** to **back_door_right**.
400. Bolt **torso_12** to **back_door_right**.
401. Bolt **torso_13** to **back_door_right**.
402. Bolt **torso_14** to **back_door_right**.
403. Bolt **torso_15** to **back_door_right**.
404. Bolt **torso_16** to **back_door_right**.
405. Bolt **torso_17** to **back_door_right**.
406. Bolt **hinge_back_right_0_knuckle** to **back_door_right**.
407. Bolt **hinge_back_right_1_knuckle** to **back_door_right**.
408. Bolt **arm_back_right** to **back_door_right**.
409. Bolt **latch_back_left_0_ledge** to **back_door_right**.
410. Bolt **latch_back_left_1_ledge** to **back_door_right**.
411. Bolt **reactor_lens** to **pelvis**.
412. Mount the **WS2812B RGB LED ring, 12 LEDs, 37 mm (NeoPixel-compatible)** (arc_reactor) in **reactor_lens** with its case screws.
413. Bolt **torso_18** to **pelvis**.
414. Bolt **torso_19** to **pelvis**.
415. Bolt **torso_20** to **pelvis**.
416. Bolt **torso_21** to **pelvis**.
417. Bolt **torso_22** to **pelvis**.
418. Bolt **torso_23** to **pelvis**.
419. Bolt **torso_24** to **pelvis**.
420. Bolt **torso_25** to **pelvis**.
421. Bolt **torso_26** to **pelvis**.
422. Bolt **torso_27** to **pelvis**.
423. Bolt **torso_28** to **pelvis**.
424. Bolt **torso_29** to **pelvis**.
425. Bolt **torso_30** to **pelvis**.
426. Bolt **torso_31** to **pelvis**.
427. Bolt **torso_32** to **pelvis**.
428. Bolt **torso_33** to **pelvis**.
429. Bolt **torso_34** to **pelvis**.
430. Bolt **torso_35** to **pelvis**.
431. Bolt **torso_36** to **pelvis**.
432. Bolt **torso_37** to **pelvis**.
433. Bolt **torso_38** to **pelvis**.
434. Bolt **torso_39** to **pelvis**.
435. Bolt **torso_40** to **pelvis**.
436. Bolt **torso_41** to **pelvis**.
437. Bolt **torso_42** to **pelvis**.
438. Bolt **torso_43** to **pelvis**.
439. Bolt **torso_44** to **pelvis**.
440. Bolt **torso_45** to **pelvis**.
441. Bolt **torso_46** to **pelvis**.
442. Bolt **torso_47** to **pelvis**.
443. Bolt **torso_48** to **pelvis**.
444. Bolt **torso_49** to **pelvis**.
445. Bolt **torso_50** to **pelvis**.
446. Bolt **torso_51** to **pelvis**.
447. Bolt **torso_52** to **pelvis**.
448. Bolt **torso_53** to **pelvis**.
449. Bolt **hinge_back_left_0** to **pelvis**.
450. Bolt **hinge_back_left_1** to **pelvis**.
451. Bolt **pod_back_left** to **pelvis**.
452. Bolt **hinge_back_right_0** to **pelvis**.
453. Bolt **hinge_back_right_1** to **pelvis**.
454. Bolt **pod_back_right** to **pelvis**.
455. Bolt **drive_left_saddle** to **pelvis**.
456. Bolt **drive_right_saddle** to **pelvis**.
457. Bolt **chan_belt_0** to **pelvis**.
458. Bolt **chan_belt_1** to **pelvis**.
459. Bolt **chan_chest_0** to **pelvis**.
460. Bolt **chan_chest_1** to **pelvis**.
461. Bolt **chan_chest_2** to **pelvis**.
462. Bolt **chan_collar_0** to **pelvis**.
463. Bolt **chan_left_flank_low_0** to **pelvis**.
464. Bolt **chan_left_flank_high_0** to **pelvis**.
465. Bolt **chan_right_flank_low_0** to **pelvis**.
466. Bolt **chan_right_flank_high_0** to **pelvis**.
467. Bolt **drive_left** to **pelvis**.
468. Bolt **drive_left_lid** to **drive_left**.
469. Mount the **PCA9685 16-channel PWM servo driver board (generic, I2C)** (servo_driver_left) in **drive_left** with its case screws.
470. Bolt **drive_right** to **pelvis**.
471. Bolt **drive_right_lid** to **drive_right**.
472. Mount the **PCA9685 16-channel PWM servo driver board (generic, I2C)** (servo_driver_right) in **drive_right** with its case screws.

## Fasteners

- 12 × M3 x 10 self-tapping (lid to compartment)
- 2 × M3 x 6 self-tapping (2S 18650 pack: two 2500 mAh 20 A cells to standoffs)
- 4 × M3 x 6 self-tapping (LM2596S adjustable buck module to standoffs)
- 3 × M2 x 6 self-tapping (Pololu D36V50F5 5 V 5.5 A step-down regulator to standoffs)
- 4 × M3 x 16 self-tapping (compartment floor into the saddle, from inside the compartment)
- 8 × M2.5 x 6 self-tapping (PCA9685 16-channel PWM servo driver board to standoffs)
- 4 × M3 x 16 self-tapping (driver bay floor into its saddle)
- 24 × M4 x 40 stainless shoulder pin with nyloc nut (door hinge)
- 96 × M3 x 10 screw and washer (hinge leaf through the shell)
- 24 × M6 ball-nose spring plunger, 20 N (clutch between servo horn and drive arm)
- 11 × torsion spring, 0.05 N·m (latch pawl, sprung shut)
- 11 × 1.5 mm braided cord in 2 mm PTFE sleeve, 1 m (hand release, one per latch)
- 4 × M2 self-tapping (servo tabs, from the servo kits)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
