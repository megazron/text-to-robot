# MoveIt 2

No serial arm chain with 2+ actuated joints was found in iron_man_mark_43, so no MoveIt config was generated.
