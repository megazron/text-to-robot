# Gazebo — iron_man_mark_43

```bash
sudo apt install ros-${ROS_DISTRO}-ros-gz
ros2 launch iron_man_mark_43 gazebo.launch.py
```

Spawns the robot from `robot_description` into `worlds/iron_man_mark_43.sdf` (ground plane + sun) with a /clock bridge.
Add `gz_ros2_control` to drive the joints from ros2_control.
