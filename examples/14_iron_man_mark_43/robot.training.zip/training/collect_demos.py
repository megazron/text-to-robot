"""Collect expert demonstrations with a scripted controller (PyBullet inverse
kinematics toward the task target). Saves demos.npz for imitation learning.

    python collect_demos.py --task reach --episodes 50
"""
import argparse
import numpy as np
import gymnasium as gym
import pybullet as p
import robot_env, tasks as T


def expert_action(env):
    # simple IK expert: drive the tip toward the target, mapped to normalized targets
    ik = p.calculateInverseKinematics(env.robot, env.tip_index, list(env.target))
    action = []
    for idx, j in enumerate(env.joints):
        lo, hi = env.limits[idx]
        q = ik[idx] if idx < len(ik) else 0.0
        action.append(2.0 * (q - lo) / (hi - lo) - 1.0)
    return np.clip(np.array(action, dtype=np.float32), -1, 1)


def main(task, episodes):
    env = gym.make(f"IronManMark43-{task}-v0").unwrapped
    O, A = [], []
    for _ in range(episodes):
        obs, _ = env.reset()
        for _ in range(env.max_steps):
            a = expert_action(env)
            O.append(obs); A.append(a)
            obs, r, term, trunc, _ = env.step(a)
            if term or trunc: break
    np.savez("demos.npz", obs=np.array(O), act=np.array(A))
    print("saved demos.npz", len(O), "transitions")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", default=T.DEFAULT_TASK)
    ap.add_argument("--episodes", type=int, default=50)
    a = ap.parse_args(); main(a.task, a.episodes)
