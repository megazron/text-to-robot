# Printability — mecanum_robot

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 400 × 300 × 3 | ❌ |
| base_link_service_lid | 400 × 300 × 3 | ❌ |
| base_link_rear_panel | 3 × 300 × 114 | ❌ |
| base_link_right_panel | 394 × 3 × 114 | ❌ |
| base_link_front_panel | 3 × 300 × 114 | ❌ |
| base_link_left_panel | 394 × 3 × 114 | ❌ |
| base_link_standoff_rr | 8 × 8 × 114 | ✅ |
| base_link_standoff_rl | 8 × 8 × 114 | ✅ |
| base_link_standoff_fr | 8 × 8 × 114 | ✅ |
| base_link_standoff_fl | 8 × 8 × 114 | ✅ |
| front_left_wheel | 86 × 86 × 40 | ✅ |
| front_right_wheel | 86 × 86 × 40 | ✅ |
| rear_left_wheel | 86 × 86 × 40 | ✅ |
| rear_right_wheel | 86 × 86 × 40 | ✅ |
| front_left_wheel_roller_0 | 24 × 24 × 26 | ✅ |
| front_left_wheel_roller_1 | 24 × 24 × 26 | ✅ |
| front_left_wheel_roller_2 | 24 × 24 × 26 | ✅ |
| front_left_wheel_roller_3 | 24 × 24 × 26 | ✅ |
| front_left_wheel_roller_4 | 24 × 24 × 26 | ✅ |
| front_left_wheel_roller_5 | 24 × 24 × 26 | ✅ |
| front_left_wheel_roller_6 | 24 × 24 × 26 | ✅ |
| front_left_wheel_roller_7 | 24 × 24 × 26 | ✅ |
| front_right_wheel_roller_0 | 24 × 24 × 26 | ✅ |
| front_right_wheel_roller_1 | 24 × 24 × 26 | ✅ |
| front_right_wheel_roller_2 | 24 × 24 × 26 | ✅ |
| front_right_wheel_roller_3 | 24 × 24 × 26 | ✅ |
| front_right_wheel_roller_4 | 24 × 24 × 26 | ✅ |
| front_right_wheel_roller_5 | 24 × 24 × 26 | ✅ |
| front_right_wheel_roller_6 | 24 × 24 × 26 | ✅ |
| front_right_wheel_roller_7 | 24 × 24 × 26 | ✅ |
| rear_left_wheel_roller_0 | 24 × 24 × 26 | ✅ |
| rear_left_wheel_roller_1 | 24 × 24 × 26 | ✅ |
| rear_left_wheel_roller_2 | 24 × 24 × 26 | ✅ |
| rear_left_wheel_roller_3 | 24 × 24 × 26 | ✅ |
| rear_left_wheel_roller_4 | 24 × 24 × 26 | ✅ |
| rear_left_wheel_roller_5 | 24 × 24 × 26 | ✅ |
| rear_left_wheel_roller_6 | 24 × 24 × 26 | ✅ |
| rear_left_wheel_roller_7 | 24 × 24 × 26 | ✅ |
| rear_right_wheel_roller_0 | 24 × 24 × 26 | ✅ |
| rear_right_wheel_roller_1 | 24 × 24 × 26 | ✅ |
| rear_right_wheel_roller_2 | 24 × 24 × 26 | ✅ |
| rear_right_wheel_roller_3 | 24 × 24 × 26 | ✅ |
| rear_right_wheel_roller_4 | 24 × 24 × 26 | ✅ |
| rear_right_wheel_roller_5 | 24 × 24 × 26 | ✅ |
| rear_right_wheel_roller_6 | 24 × 24 × 26 | ✅ |
| rear_right_wheel_roller_7 | 24 × 24 × 26 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_service_lid**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_rear_panel**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_right_panel**: longest dimension 394 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_front_panel**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_left_panel**: longest dimension 394 mm exceeds the 220 mm build volume — split the part or print diagonally
