# Printability — mecanum_robot

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 400 × 300 × 120 | ❌ |
| front_left_wheel | 120 × 120 × 40 | ✅ |
| front_right_wheel | 120 × 120 × 40 | ✅ |
| rear_left_wheel | 120 × 120 × 40 | ✅ |
| rear_right_wheel | 120 × 120 × 40 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
