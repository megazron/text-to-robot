# Print list — mecanum_robot

15 parts, about 344 g of PETG and 31.4 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| front_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| battery_tray | 110.6 × 40.7 × 16.2 | 17 | 1.5 | yes |
| computer_tray | 90 × 59.2 × 7 | 15 | 1.4 | yes |
| motor_driver_1_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| motor_driver_2_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| imu_tray | 27.6 × 24.7 × 7 | 2 | 0.2 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| electronics_enclosure_front | 157.4 × 214.4 × 33 | 35 | 3.1 | yes |
| electronics_enclosure_rear | 157.4 × 214.4 × 33 | 43 | 3.9 | yes |
| electronics_lid_front | 144.4 × 188.4 × 5.4 | 59 | 5.4 | yes |
| electronics_lid_rear | 144.4 × 188.4 × 5.4 | 48 | 4.4 | yes |
| lidar_mast | 62 × 62 × 12.6 | 30 | 2.7 | yes |
