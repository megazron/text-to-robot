# Print list: mecanum_robot

15 parts, about 364 g of PETG and 33.2 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| front_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| battery_tray | 40.7 × 125.6 × 16.2 | 18 | 1.7 | yes |
| computer_tray | 59.2 × 90 × 7 | 15 | 1.4 | yes |
| motor_driver_1_tray | 64 × 87 × 7 | 16 | 1.4 | yes |
| motor_driver_2_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| imu_tray | 24.7 × 27.6 × 7 | 2 | 0.2 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| electronics_enclosure_front | 152.8 × 215.8 × 45.1 | 49 | 4.5 | yes |
| electronics_enclosure_rear | 152.8 × 215.8 × 45.1 | 59 | 5.4 | yes |
| electronics_lid_front | 139.8 × 205.6 × 5.4 | 46 | 4.2 | yes |
| electronics_lid_rear | 139.8 × 205.6 × 5.4 | 38 | 3.5 | yes |
| lidar_mast | 62 × 62 × 24.7 | 41 | 3.7 | yes |
