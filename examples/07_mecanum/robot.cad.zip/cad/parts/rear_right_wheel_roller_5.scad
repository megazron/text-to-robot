// concept part: rear_right_wheel_roller_5 (roller)
// units: mm. Mesh with: openscad -o rear_right_wheel_roller_5.stl rear_right_wheel_roller_5.scad
multmatrix([[-0.28868, -0.8165, -0.5, 0], [0.40825, -0.57735, 0.70711, 0], [-0.86603, 0, 0.5, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=12, center=true, $fn=48);
