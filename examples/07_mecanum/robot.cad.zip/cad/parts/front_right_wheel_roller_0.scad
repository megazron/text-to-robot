// concept part: front_right_wheel_roller_0 (roller)
// units: mm. Mesh with: openscad -o front_right_wheel_roller_0.stl front_right_wheel_roller_0.scad
multmatrix([[0, 0.70711, 0.70711, 0], [0, 0.70711, -0.70711, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=12, center=true, $fn=48);
