// concept part: rear_right_wheel_roller_6 (roller)
// units: mm. Mesh with: openscad -o rear_right_wheel_roller_6.stl rear_right_wheel_roller_6.scad
multmatrix([[0, -1, 0, 0], [0.70711, 0, 0.70711, 0], [-0.70711, 0, 0.70711, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=12, center=true, $fn=48);
