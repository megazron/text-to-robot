// concept part: front_left_wheel_roller_1 (roller)
// units: mm. Mesh with: openscad -o front_left_wheel_roller_1.stl front_left_wheel_roller_1.scad
multmatrix([[-0.28868, -0.8165, 0.5, 0], [-0.40825, 0.57735, 0.70711, 0], [-0.86603, 0, -0.5, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=12, center=true, $fn=48);
