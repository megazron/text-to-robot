// concept part: front_left_wheel_roller_4 (roller)
// units: mm. Mesh with: openscad -o front_left_wheel_roller_4.stl front_left_wheel_roller_4.scad
multmatrix([[0, -0.70711, -0.70711, 0], [0, -0.70711, 0.70711, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=12, center=true, $fn=48);
