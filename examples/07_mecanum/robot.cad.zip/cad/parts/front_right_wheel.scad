// concept part: front_right_wheel (wheel)
// units: mm. Mesh with: openscad -o front_right_wheel.stl front_right_wheel.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=40, r=43, center=true, $fn=48);
