// concept part: front_right_wheel_roller_3 (roller)
// units: mm. Mesh with: openscad -o front_right_wheel_roller_3.stl front_right_wheel_roller_3.scad
multmatrix([[0.28868, 0.8165, -0.5, 0], [0.40825, -0.57735, -0.70711, 0], [-0.86603, 0, -0.5, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=12, center=true, $fn=48);
