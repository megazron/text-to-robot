# Fabricated parts — mecanum_robot

Not printed: made from sheet, tube or fabric (see BOM.md for the exact item and cost). Each STL is the finished shape; plates are 2D-cut from it (export the top face as DXF for laser or waterjet cutting).

| Part | Material | Mass (g) |
|---|---|--:|
| base_link | aluminium | 480 |
