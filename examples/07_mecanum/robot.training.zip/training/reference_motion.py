"""Reference motions made by Text to Robot: joint positions over time, for imitation or a tracking reward."""
import csv


class ReferenceMotion:
    def __init__(self, path, loop=True):
        with open(path) as f:
            rows = list(csv.reader(f))
        self.joints = rows[0][1:]
        self.t = [float(r[0]) for r in rows[1:]]
        self.q = [[float(x) for x in r[1:]] for r in rows[1:]]
        self.loop = loop
        self.duration = self.t[-1]

    def at(self, t):
        """joint positions at time t (s), linearly interpolated; looped or held at the end"""
        if self.loop and self.duration > 0:
            t = t % self.duration
        t = min(max(t, 0.0), self.duration)
        k = min(len(self.t) - 2, max(0, int(t / (self.duration or 1) * (len(self.t) - 1))))
        while k > 0 and self.t[k] > t: k -= 1
        while k < len(self.t) - 2 and self.t[k + 1] < t: k += 1
        a, b = self.t[k], self.t[k + 1] if len(self.t) > 1 else self.t[k]
        s = 0.0 if b == a else (t - a) / (b - a)
        return {n: self.q[k][i] + (self.q[min(k + 1, len(self.q) - 1)][i] - self.q[k][i]) * s for i, n in enumerate(self.joints)}
