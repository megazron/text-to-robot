# Build package: robot_hand

Five-finger tendon hand: 5 MG996R flexion servos in the forearm, an MG90S thumb swing, 16 joints, squeezes about 10 N, holds about 1.17 kg

1. **Buy** everything in `BOM.md` (supplier links included).
2. **Print** every STL in `print/` (see `print/PRINT_LIST.md`).
3. **Assemble** in the order of `ASSEMBLY.md`.
   **Wire** from `WIRING.md` (pin-to-pin table, cut list, power budget, battery runtime, regulator heat, logic levels), `schematic.svg` / `schematic.pdf` the picture view `breadboard.svg` and the harness in 3D `electronics.glb`.
4. **Check** against `design.json`: each actuator's required vs rated torque, the speed it reaches loaded, battery runtime, stability and every other check the design passed.

`reference/` holds the bought parts' models (from their datasheet drawings) for your own CAD; `robot_hand_assembly.stl` is the whole robot in its build pose.

## Assumptions

- Each finger is underactuated: one tendon over three joints, elastic cord on the back to open it. The middle and end joints are modelled as following the base joint (mimic); a real tendon finger also wraps round an object's shape.
- Fingertip forces use the MG996R's rated torque (not its stall torque) through a 6 mm spool: a household-object hand (cups, fruit, small tools), not a crushing grip.
- Glue silicone pads (or print TPU caps) on the fingertips and palm: the grip numbers assume friction 0.6.
