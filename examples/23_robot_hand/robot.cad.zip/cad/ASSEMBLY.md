# Assembly: robot_hand

Start from **stand**.

1. Bolt **base_link** to **stand**.
2. Bolt **forearm_lid** to **base_link**.
3. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (index_servo) in **base_link** with its case screws.
4. Bolt **spool_1** to **index_servo**.
5. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (middle_servo) in **base_link** with its case screws.
6. Bolt **spool_2** to **middle_servo**.
7. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (ring_servo) in **base_link** with its case screws.
8. Bolt **spool_3** to **ring_servo**.
9. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (little_servo) in **base_link** with its case screws.
10. Bolt **spool_4** to **little_servo**.
11. Mount the **TowerPro MG996R standard servo (metal gears) + round horn** (thumb_servo) in **base_link** with its case screws.
12. Bolt **spool_5** to **thumb_servo**.
13. Bolt **palm** to **base_link**.
14. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (thumb_swing_servo) in **palm** with its case screws.
15. Set joint `index_mcp` to zero (centre the servo first), then screw **index_proximal** to the actuator output in **palm**; it moves 0° … 83°.
16. Set joint `index_pip` to zero (centre the servo first), then screw **index_middle** to the actuator output in **index_proximal**; it moves 0° … 86°.
17. Set joint `index_dip` to zero (centre the servo first), then screw **index_distal** to the actuator output in **index_middle**; it moves 0° … 86°.
18. Set joint `middle_mcp` to zero (centre the servo first), then screw **middle_proximal** to the actuator output in **palm**; it moves 0° … 83°.
19. Set joint `middle_pip` to zero (centre the servo first), then screw **middle_middle** to the actuator output in **middle_proximal**; it moves 0° … 86°.
20. Set joint `middle_dip` to zero (centre the servo first), then screw **middle_distal** to the actuator output in **middle_middle**; it moves 0° … 86°.
21. Set joint `ring_mcp` to zero (centre the servo first), then screw **ring_proximal** to the actuator output in **palm**; it moves 0° … 83°.
22. Set joint `ring_pip` to zero (centre the servo first), then screw **ring_middle** to the actuator output in **ring_proximal**; it moves 0° … 86°.
23. Set joint `ring_dip` to zero (centre the servo first), then screw **ring_distal** to the actuator output in **ring_middle**; it moves 0° … 86°.
24. Set joint `little_mcp` to zero (centre the servo first), then screw **little_proximal** to the actuator output in **palm**; it moves 0° … 83°.
25. Set joint `little_pip` to zero (centre the servo first), then screw **little_middle** to the actuator output in **little_proximal**; it moves 0° … 86°.
26. Set joint `little_dip` to zero (centre the servo first), then screw **little_distal** to the actuator output in **little_middle**; it moves 0° … 86°.
27. Set joint `thumb_swing` to zero (centre the servo first), then screw **thumb_base** to the actuator output in **palm**; it moves 0° … 57°.
28. Set joint `thumb_mcp` to zero (centre the servo first), then screw **thumb_proximal** to the actuator output in **thumb_base**; it moves 0° … 69°.
29. Set joint `thumb_ip` to zero (centre the servo first), then screw **thumb_distal** to the actuator output in **thumb_proximal**; it moves 0° … 74°.
30. Bolt **control_case** to **stand**.
31. Bolt **control_case_lid** to **control_case**.
32. Mount the **Mean Well LRS-50-5 enclosed PSU, 5 V 10 A (50 W)** (power_supply) in **control_case** with its case screws.
33. Mount the **Arduino Nano compatible board (ATmega328P, CH340, USB-C)** (controller) in **control_case** with its case screws.
34. Mount the **PCA9685 16-channel PWM servo driver board (generic, I2C)** (servo_driver) in **control_case** with its case screws.
35. Mount the **IEC C14 panel inlet with fuse drawer and rocker switch, 10 A** (mains_inlet) in **control_case** with its case screws.

## Fasteners

- 20 × M4 x 12 (servo ears)
- 1 × braided fishing line 0.5 mm (40 kg), 2 m (tendons)
- 4 × M3 x 8 (lid)
- 4 × M3 x 12 (palm to forearm)
- 12 × 2 mm steel pin, 18 mm (finger joints)
- 4 × elastic cord (finger return), 0.3 m
- 4 × M3 x 10 self-tapping (lid to compartment)
- 2 × M3 x 6 self-tapping (Mean Well LRS-50-5 enclosed PSU, 5 V 10 A to standoffs)
- 4 × M2.5 x 6 self-tapping (PCA9685 16-channel PWM servo driver board to standoffs)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
