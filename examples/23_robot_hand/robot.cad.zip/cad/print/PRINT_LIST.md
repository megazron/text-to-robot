# Print list: robot_hand

25 parts, about 613 g of PETG and 55.8 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 236.7 × 84 × 60 | 224 | 20.4 | yes |
| forearm_lid | 222.7 × 84 × 2.4 | 33 | 3.0 | yes |
| spool_1 | 18 × 18 × 5.6 | 1 | 0.1 | yes |
| spool_2 | 18 × 18 × 5.6 | 1 | 0.1 | yes |
| spool_3 | 18 × 18 × 5.6 | 1 | 0.1 | yes |
| spool_4 | 18 × 18 × 5.6 | 1 | 0.1 | yes |
| spool_5 | 18 × 18 × 5.6 | 1 | 0.1 | yes |
| palm | 96 × 80 × 43 | 139 | 12.7 | yes |
| index_proximal | 55.5 × 14 × 12 | 6 | 0.5 | yes |
| index_middle | 37.5 × 12 × 11 | 3 | 0.2 | yes |
| index_distal | 27 × 12 × 10 | 2 | 0.2 | yes |
| middle_proximal | 58.5 × 14 × 12 | 6 | 0.6 | yes |
| middle_middle | 39.5 × 12 × 11 | 3 | 0.3 | yes |
| middle_distal | 28 × 12 × 10 | 2 | 0.2 | yes |
| ring_proximal | 55.5 × 14 × 12 | 6 | 0.5 | yes |
| ring_middle | 37.5 × 12 × 11 | 3 | 0.2 | yes |
| ring_distal | 27 × 12 × 10 | 2 | 0.2 | yes |
| little_proximal | 47.5 × 14 × 12 | 5 | 0.4 | yes |
| little_middle | 33.5 × 12 × 11 | 2 | 0.2 | yes |
| little_distal | 25 × 12 × 10 | 2 | 0.1 | yes |
| thumb_base | 53.7 × 33.5 × 36.7 | 7 | 0.6 | yes |
| thumb_proximal | 45.5 × 14 × 12 | 4 | 0.4 | yes |
| thumb_distal | 33 × 12 × 11 | 3 | 0.2 | yes |
| control_case | 204.7 × 135.1 × 44.4 | 115 | 10.5 | yes |
| control_case_lid | 204.7 × 135.1 × 5.8 | 44 | 4.0 | yes |
