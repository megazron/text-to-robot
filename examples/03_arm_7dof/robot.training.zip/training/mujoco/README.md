# arm_7dof in MuJoCo

Test, render and train this exact robot in MuJoCo with the text-to-robot Python layer:

```bash
pip install -r requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cpu    # CPU torch on GPU-less machines

python -m ttr_mujoco test   ../arm_7dof.urdf --self-collision                       # settle / hold / actuator sweep / disturbance
python -m ttr_mujoco render ../arm_7dof.urdf --self-collision -o arm_7dof.gif --motion sweep
python -m ttr_mujoco train  ../arm_7dof.urdf --self-collision --task reach --tip-body gripper_base --steps 400000
```

Mesh-based exports first prepare approximate convex collision hulls. This preserves
hollow regions better than bounding boxes; inspect the generated collision report.
Simulation and training do not validate hardware fit or a learned policy.

Or from Python:

```python
from ttr_mujoco import urdf_to_mjcf, run_tests, render_gif
from ttr_mujoco.env import MujocoRobotEnv
report = run_tests(urdf_to_mjcf("../arm_7dof.urdf", self_collision=True))              # dict with per-test pass/fail + metrics
env = MujocoRobotEnv("../arm_7dof.urdf", self_collision=True, task="reach", tip_body="gripper_base")
```
