// concept part: link_4 (link_4)
// units: mm. Mesh with: openscad -o link_4.stl link_4.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 45], [0, 0, 0, 1]])
  cylinder(h=36, r=21.6, center=true, $fn=48);
