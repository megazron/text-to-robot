// concept part: link_4 (link_4)
// units: mm. Mesh with: openscad -o link_4.stl link_4.scad
import("../stl/parts/link_4.stl");
