// concept part: link_4_joint_hub (joint_housing)
// units: mm. Mesh with: openscad -o link_4_joint_hub.stl link_4_joint_hub.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=26, r=25.488, center=true, $fn=48);
