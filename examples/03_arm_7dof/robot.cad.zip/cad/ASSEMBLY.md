# Assembly: arm_7dof

Start from **base_link**.

1. Mount the **DYNAMIXEL XL430-W250-T** (base_yaw_actuator) in **base_link** with its case screws.
2. Set joint `base_yaw` to zero (centre the servo first), then screw **turret** to the actuator output in **base_link**; it moves -170° … 170°.
3. Mount the **DYNAMIXEL XH540-W270-T(R)** (shoulder_pitch_actuator) in **turret** with its case screws.
4. Set joint `shoulder_pitch` to zero (centre the servo first), then screw **upper_arm** to the actuator output in **turret**; it moves -100° … 64°.
5. Mount the **DYNAMIXEL XL430-W250-T** (upper_arm_roll_actuator) in **upper_arm** with its case screws.
6. Set joint `upper_arm_roll` to zero (centre the servo first), then screw **upper_arm_rotator** to the actuator output in **upper_arm**; it moves -170° … 170°.
7. Mount the **DYNAMIXEL XM430-W350-T(R)** (elbow_pitch_actuator) in **upper_arm_rotator** with its case screws.
8. Set joint `elbow_pitch` to zero (centre the servo first), then screw **forearm** to the actuator output in **upper_arm_rotator**; it moves -109° … 111°.
9. Mount the **DYNAMIXEL XL430-W250-T** (forearm_roll_actuator) in **forearm** with its case screws.
10. Set joint `forearm_roll` to zero (centre the servo first), then screw **forearm_rotator** to the actuator output in **forearm**; it moves -131° … 131°.
11. Mount the **DYNAMIXEL XL430-W250-T** (wrist_pitch_actuator) in **forearm_rotator** with its case screws.
12. Set joint `wrist_pitch` to zero (centre the servo first), then screw **wrist** to the actuator output in **forearm_rotator**; it moves -97° … 17°.
13. Mount the **DYNAMIXEL XL430-W250-T** (wrist_roll_actuator) in **wrist** with its case screws.
14. Set joint `wrist_roll` to zero (centre the servo first), then screw **wrist_rotator** to the actuator output in **wrist**; it moves -170° … 170°.
15. Mount the **DYNAMIXEL XL430-W250-T** (gripper_actuator) in **wrist_rotator** with its case screws.
16. Set joint `gripper` to zero (centre the servo first), then screw **gripper_jaw** to the actuator output in **wrist_rotator**; it moves -20° … 27°.
17. Bolt **control_case** to **base_link**.
18. Bolt **control_case_lid** to **control_case**.
19. Mount the **Mean Well LRS-75-12 enclosed PSU, 12 V 6 A (75 W)** (power_supply) in **control_case** with its case screws.
20. Mount the **ROBOTIS U2D2 USB to TTL/RS-485 interface** (servo_bus) in **control_case** with its case screws.
21. Mount the **IEC C14 panel inlet with fuse drawer and rocker switch, 10 A** (mains_inlet) in **control_case** with its case screws.

## Fasteners

- 4 × M5 x 12 socket head (base to bench)
- 28 × M2.5 x 6 case screws
- 60 × horn screws
- 3 × M5 x 16 socket head + M5 washer + M5 heat-set insert (clevis bearing axle)
- 4 × M3 x 10 self-tapping (lid to compartment)
- 2 × M3 x 6 self-tapping (Mean Well LRS-75-12 enclosed PSU, 12 V 6 A to standoffs)
- 1 × M2 x 6 self-tapping (ROBOTIS U2D2 USB to TTL/RS-485 interface to standoffs)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
