# Bill of materials: arm_7dof

**Estimated total: $1216.73**  ·  tier: prosumer

**Effort sizing: passes catalogue estimate; hardware verified: no.**

| Category | Component | Qty | Unit $ | Subtotal $ | Spec |
|---|---|--:|--:|--:|---|
| Mechanical | Ball bearing 625-2Z 5x16x5 mm _(clevis bearing, joint shoulder_pitch; clevis bearing, joint elbow_pitch; clevis bearing, joint wrist_pitch · https://www.vxb.com/search?q=625-2Z)_ | 3 | 0.55 | 1.65 | https://www.skf.com/group/products/rolling-bearings/ball-bearings/deep-groove-ball-bearings/productid-625-2Z |
| Electronics | ROBOTIS U2D2 USB to TTL/RS-485 interface _(USB to actuator bus · https://www.generationrobots.com/en/400848-usb2dynamixel-robotis.html)_ | 1 | 32.1 | 32.1 | 5 V |
| Actuator | DYNAMIXEL XH540-W270-T(R) _(joint shoulder_pitch · https://robotis.us/dynamixel-xh540-w270-t)_ | 1 | 539.9 | 539.9 | 2.97 N·m rated / 9.9 N·m peak, 12 V |
| Actuator | DYNAMIXEL XL430-W250-T _(joint base_yaw; joint upper_arm_roll; joint forearm_roll; joint wrist_pitch; … · https://robotis.us/dynamixel-xl430-w250-t)_ | 6 | 44.9 | 269.4 | 0.42 N·m rated / 1.4 N·m peak, 11.1 V |
| Actuator | DYNAMIXEL XM430-W350-T(R) _(joint elbow_pitch · https://www.robotshop.com/products/robotis-dynamixel-xm430-w350-t-smart-servo-actuator)_ | 1 | 310.39 | 310.39 | 1.23 N·m rated / 4.1 N·m peak, 12 V |
| Power | IEC C14 panel inlet with fuse drawer and rocker switch, 10 A _(fused, switched mains inlet · https://www.aliexpress.com/w/wholesale-iec-c14-inlet-fuse-switch.html)_ | 1 | 3 | 3 | https://www.aliexpress.com/w/wholesale-iec-c14-inlet-fuse-switch.html |
| Power | Mean Well LRS-75-12 enclosed PSU, 12 V 6 A (75 W) _(12 V actuator supply · https://www.digikey.com/en/products/result?keywords=LRS-75-12)_ | 1 | 22 | 22 | 12 V |
| Printed structure | PETG filament for 11 printed parts _(base_link, turret, upper_arm, upper_arm_rotator, forearm, forearm_rotator, wrist, wrist_rotator, gripper_jaw, control_case, control_case_lid)_ | 1 | 14.94 | 14.94 | 590 g of parts (+15 % supports/waste), about 53.8 h of printing |
| Fasteners | Screws, nuts and inserts | 102 | 0.12 | 12.24 | 4x M5 x 12 socket head (base to bench); 28x M2.5 x 6 case screws; 60x horn screws; 3x M5 x 16 socket head + M5 washer + M5 heat-set insert (clevis bearing axle); 4x M3 x 10 self-tapping (lid to compartment); 2x M3 x 6 self-tapping (Mean Well LRS-75-12 enclosed PSU, 12 V 6 A to standoffs); 1x M2 x 6 self-tapping (ROBOTIS U2D2 USB to TTL/RS-485 interface to standoffs) |
| Wiring | 18 AWG silicone wire _(price estimated)_ | 1 | 0.7 | 0.7 | 1 m: 0.823 mm2, rated 8 A in a bundle; 0.89 m cut + 10 % waste |
| Wiring | 20 AWG silicone wire _(price estimated)_ | 1.6 | 0.5 | 0.8 | 1.6 m: 0.519 mm2, rated 5.5 A in a bundle; 1.44 m cut + 10 % waste |
| Wiring | 22 AWG silicone wire _(price estimated)_ | 1.3 | 0.4 | 0.52 | 1.3 m: 0.327 mm2, rated 3.5 A in a bundle; 1.17 m cut + 10 % waste |
| Wiring | 24 AWG silicone wire _(price estimated)_ | 4.2 | 0.35 | 1.47 | 4.2 m: 0.205 mm2, rated 1.75 A in a bundle; 3.74 m cut + 10 % waste |
| Wiring | 26 AWG silicone wire _(price estimated)_ | 3.3 | 0.3 | 0.99 | 3.3 m: 0.128 mm2, rated 1.1 A in a bundle; 2.93 m cut + 10 % waste |
| Wiring | 6.3 mm spade contacts _(price estimated)_ | 3 | 0.08 | 0.24 | 3 pc: rated 15 A per contact |
| Wiring | Bootlace ferrule contacts _(price estimated)_ | 5 | 0.03 | 0.15 | 5 pc: rated 17.5 A per contact |
| Wiring | JST EH 2.5 mm contacts _(price estimated)_ | 48 | 0.03 | 1.44 | 48 pc: rated 3 A per contact |
| Wiring | JST EH 2.5 mm housings _(price estimated)_ | 17 | 0.05 | 0.85 | 17 pc: one per cable end |
| Wiring | Heat shrink 3 mm, 2:1 _(price estimated)_ | 0.6 | 0.2 | 0.12 | 0.6 m: 0 solder joints + a boot on each cable end |
| Wiring | Cable tie 100 x 2.5 mm _(price estimated)_ | 17 | 0.02 | 0.34 | 17 pc: at every clip, cable end and strain-relief anchor |
| Wiring | PG7 cable gland _(price estimated)_ | 1 | 2.97 | 2.97 | 1 pc: cable exit with strain relief |
| Wiring | Nylon braided sleeving 6 mm _(price estimated)_ | 1.3 | 0.4 | 0.52 | 1.3 m: over every cable where it crosses a joint |

## Actuator sizing

| Joint | Required effort | Unit | Chosen actuator | Margin |
|---|--:|---|---|--:|
| base_yaw | 0 | N·m | DYNAMIXEL XL430-W250-T | 99x |
| shoulder_pitch | 2.806 | N·m | DYNAMIXEL XH540-W270-T(R) | 3.53x |
| upper_arm_roll | 0.019 | N·m | DYNAMIXEL XL430-W250-T | 75.22x |
| elbow_pitch | 1.353 | N·m | DYNAMIXEL XM430-W350-T(R) | 3.03x |
| forearm_roll | 0.009 | N·m | DYNAMIXEL XL430-W250-T | 99x |
| wrist_pitch | 0.488 | N·m | DYNAMIXEL XL430-W250-T | 2.87x |
| wrist_roll | 0.001 | N·m | DYNAMIXEL XL430-W250-T | 99x |

## Notes
- 7-DOF arm, 500 mm reach, 0.1 kg payload, ROBOTIS DYNAMIXEL X-series (12 V)
- Sized for a 0.1 kg payload.
- Arm clamps or bolts to the bench through the four M5 holes in the base; it is not free-standing at full reach.
- Every pitch joint is a clevis: one cheek bolts to the servo horn, the other turns on a 625ZZ bearing on an M5 bolt screwed into a heat-set insert in a boss on the back of the servo's cradle, so the servo's own bearing carries no bending moment. An M5 washer sits between the boss and the bearing's inner race.
- Print the links in PETG or PLA+ with 4 perimeters and 30 % gyroid infill, cradle opening up; press the 625ZZ bearings into their seats (16.15 mm) and set the M5 inserts with a soldering iron.
- Torques are exact static gravity loads of this geometry: the worst pose (stretched out with the payload) must be held within each actuator's rated continuous torque, peaks get +30 %, and each joint must still reach >= 1 rad/s loaded on its torque-speed line.
- Prices are list/street prices from the linked suppliers at the time the catalog was written; check before ordering.
