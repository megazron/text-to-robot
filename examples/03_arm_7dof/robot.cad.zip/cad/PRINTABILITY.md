# Printability — arm_7dof

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 144 × 144 × 3 | ✅ |
| base_link_service_lid | 144 × 144 × 3 | ✅ |
| base_link_rear_panel | 3 × 144 × 114 | ✅ |
| base_link_right_panel | 138 × 3 × 114 | ✅ |
| base_link_front_panel | 3 × 144 × 114 | ✅ |
| base_link_left_panel | 138 × 3 × 114 | ✅ |
| base_link_standoff_rr | 8 × 8 × 114 | ✅ |
| base_link_standoff_rl | 8 × 8 × 114 | ✅ |
| base_link_standoff_fr | 8 × 8 × 114 | ✅ |
| base_link_standoff_fl | 8 × 8 × 114 | ✅ |
| shoulder | 48 × 48 × 40 | ✅ |
| shoulder_mount | 40 × 40 × 27 | ✅ |
| shoulder_joint_hub | 56.6 × 56.6 × 26 | ✅ |
| upper_arm | 57.6 × 57.6 × 170 | ✅ |
| upper_arm_joint_hub | 68 × 68 × 26 | ✅ |
| forearm | 57.6 × 57.6 × 170 | ✅ |
| forearm_joint_hub | 68 × 68 × 26 | ✅ |
| link_4 | 43.2 × 43.2 × 36 | ✅ |
| link_4_joint_hub | 51 × 51 × 26 | ✅ |
| wrist_1 | 26.9 × 26.9 × 22.4 | ✅ |
| wrist_1_joint_hub | 31.7 × 31.7 × 26 | ✅ |
| wrist_2 | 32.6 × 32.6 × 27.2 | ✅ |
| wrist_2_joint_hub | 38.5 × 38.5 × 26 | ✅ |
| wrist_3 | 38.4 × 38.4 × 32 | ✅ |
| wrist_3_joint_hub | 45.3 × 45.3 × 26 | ✅ |
| gripper_base | 60 × 80 × 30 | ✅ |
| left_finger | 15 × 20 × 60 | ✅ |
| right_finger | 15 × 20 × 60 | ✅ |
| left_finger_pad | 15 × 2 × 36 | ✅ |
| right_finger_pad | 15 × 2 × 36 | ✅ |

## Notes
- ⚠️ **left_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
