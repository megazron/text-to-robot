# Printability — arm_7dof

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 120 × 120 × 120 | ✅ |
| shoulder | 80 × 80 × 100 | ✅ |
| upper_arm | 80 × 80 × 250 | ❌ |
| forearm | 80 × 80 × 250 | ❌ |
| link_4 | 80 × 80 × 90 | ✅ |
| wrist_1 | 80 × 80 × 56 | ✅ |
| wrist_2 | 80 × 80 × 68 | ✅ |
| wrist_3 | 80 × 80 × 80 | ✅ |
| gripper_base | 60 × 80 × 30 | ✅ |
| left_finger | 15 × 20 × 60 | ✅ |
| right_finger | 15 × 20 × 60 | ✅ |

## Notes
- ⚠️ **upper_arm**: longest dimension 250 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **forearm**: longest dimension 250 mm exceeds the 220 mm build volume — split the part or print diagonally
