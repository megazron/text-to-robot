# arm_2dof in MuJoCo

Test, render and train this exact robot in MuJoCo with the text-to-robot Python layer:

```bash
pip install -r requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cpu    # CPU torch on GPU-less machines

python -m ttr_mujoco test   ../arm_2dof.urdf --self-collision                       # settle / hold / actuator sweep / disturbance
python -m ttr_mujoco render ../arm_2dof.urdf -o arm_2dof.gif --motion sweep
python -m ttr_mujoco train  ../arm_2dof.urdf --self-collision --task reach --tip-body gripper_base --steps 400000
```

Or from Python:

```python
from ttr_mujoco import urdf_to_mjcf, run_tests, render_gif
from ttr_mujoco.env import MujocoRobotEnv
report = run_tests("../arm_2dof.urdf")              # dict with per-test pass/fail + metrics
env = MujocoRobotEnv("../arm_2dof.urdf", task="reach", tip_body="gripper_base")
```
