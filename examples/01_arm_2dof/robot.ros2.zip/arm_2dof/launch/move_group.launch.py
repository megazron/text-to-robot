# Fixed-root planning with mock hardware, not physical simulation.
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from moveit_configs_utils import MoveItConfigsBuilder


def generate_launch_description():
    share = get_package_share_directory("arm_2dof")
    config = (MoveItConfigsBuilder("arm_2dof", package_name="arm_2dof")
        .robot_description(file_path="urdf/arm_2dof.urdf.xacro")
        .robot_description_semantic(file_path="moveit/arm_2dof.srdf")
        .robot_description_kinematics(file_path="moveit/kinematics.yaml")
        .joint_limits(file_path="config/joint_limits.yaml")
        .trajectory_execution(file_path="moveit/moveit_controllers.yaml")
        .planning_pipelines(pipelines=["ompl"])
        .to_moveit_configs())
    return LaunchDescription([
        DeclareLaunchArgument("rviz", default_value="true"),
        Node(package="robot_state_publisher", executable="robot_state_publisher", parameters=[config.robot_description]),
        Node(package="tf2_ros", executable="static_transform_publisher", arguments=["--frame-id", "world", "--child-frame-id", "base_link"]),
        Node(package="controller_manager", executable="ros2_control_node", parameters=[os.path.join(share,"config/controllers.yaml")], output="screen"),
        Node(package="controller_manager", executable="spawner", arguments=["joint_state_broadcaster", "joint_trajectory_controller", "--controller-manager-timeout", "60"]),
        Node(package="moveit_ros_move_group", executable="move_group", parameters=[config.to_dict()], output="screen"),
        Node(package="rviz2", executable="rviz2", arguments=["-d", os.path.join(share,"rviz/arm_2dof.rviz")], parameters=[config.to_dict()], condition=IfCondition(LaunchConfiguration("rviz"))),
    ])
