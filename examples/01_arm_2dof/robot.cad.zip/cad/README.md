# Build package: arm_2dof

2-DOF arm, 350 mm reach, 0.1 kg payload, Feetech STS serial-bus servos (12 V)

1. **Buy** everything in `BOM.md` (supplier links included).
2. **Print** every STL in `print/` (see `print/PRINT_LIST.md`).
3. **Assemble** in the order of `ASSEMBLY.md`.
   **Wire** from `WIRING.md` (pin-to-pin table, cut list, power budget, battery runtime, regulator heat, logic levels), `schematic.svg` / `schematic.pdf` and the picture view `breadboard.svg`.
4. **Check** against `design.json`: each actuator's required vs rated torque, the speed it reaches loaded, battery runtime, stability and every other check the design passed.

`reference/` holds the bought parts' models (from their datasheet drawings) for your own CAD; `arm_2dof_assembly.stl` is the whole robot in its build pose.

## Assumptions

- Arm clamps or bolts to the bench through the four M5 holes in the base; it is not free-standing at full reach.
- Every pitch joint is a clevis: one cheek bolts to the servo horn, the other turns on a 625ZZ bearing on an M5 bolt screwed into a heat-set insert in a boss on the back of the servo's cradle, so the servo's own bearing carries no bending moment. An M5 washer sits between the boss and the bearing's inner race.
- Print the links in PETG or PLA+ with 4 perimeters and 30 % gyroid infill, cradle opening up; press the 625ZZ bearings into their seats (16.15 mm) and set the M5 inserts with a soldering iron.
- Torques are exact static gravity loads of this geometry: the worst pose (stretched out with the payload) must be held within each actuator's rated continuous torque, peaks get +30 %, and each joint must still reach >= 1 rad/s loaded on its torque-speed line.
