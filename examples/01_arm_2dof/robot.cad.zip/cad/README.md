# CAD — arm_2dof

Two deliverables, both in millimetres:

- **STL (concept geometry)** — `stl/arm_2dof_assembly.stl` and one mesh per link in `stl/parts/`. See `PRINTABILITY.md`. Assembly STL is a visualization, not a mechanically assembled printable part.
- **OpenSCAD** — `arm_2dof.scad` (assembly) and `parts/*.scad`; primitives are parametric, recipe meshes are imported.

Hardware fit, fasteners, cable routing, material strength and moving-part clearances are not validated by this export. Bounding-box printability is not a manufacturing approval.

## Dimensioned electronics housing (optional Python backend)

Edit `hardware/example_enclosure.json` using your PCB envelope, hole coordinates and material density. Its defaults are synthetic, not a real vendor part.

```bash
cd hardware
python -m pip install -r requirements.txt
python enclosure.py example_enclosure.json --out enclosure
```

Outputs separate base/lid STEP and STL, board standoffs, through-bolt bores, cable opening, and a geometric-fit/mass-properties report.

To attach it to a robot, run `python attach.py --help`: supply the parent link, mount pose (metres/radians), and measured electronics mass. It writes an updated robot JSON with housing CAD and mass properties. Use **Import JSON** in the viewer to inspect/export it. Fasteners, mounting strength and assembly clearance still need verification.
