# Wiring: arm_2dof

5 cables, 14 conductors, 5.46 m of wire, wiring parts $7.37.

Diagram: [wiring.svg](wiring.svg). Cable routes in 3D: `design.wiring.cables[].path_mm` in `robot.json`.

## Power budget

| Rail | Volts | Source | Source limit A (cont / peak) | Load A (typical / peak) | Margin (typical) | Fuse A | Worst wire drop V |
|---|--:|---|--:|--:|--:|--:|--:|
| VBUS | 12 | power_supply | 6 / 6.6 | 1.55 / 5.1 | 3.9x | - | 0.261 |

**VBUS loads** (peak assumes two joints at peak at once, the rest at half load):

| Load | Typical A | Peak A |
|---|--:|--:|
| servo_bus | 1.55 | 5.1 |

## Protection

- Main switch: **mains_inlet** breaks the positive feed after the fuse. Ground is never switched.
- All grounds meet at one star point. Every signal has its return through that common ground.

## Pin-to-pin table

| Cable | Wire | Net | From | To | AWG | Colour | Typical A | Peak A |
|---|---|---|---|---|--:|---|--:|--:|
| C1 | W1 | MAINS_L | mains_inlet.L | power_supply.AC/L | 24 | red | 1 | 2 |
| C1 | W2 | MAINS_N | mains_inlet.N | power_supply.AC/N | 24 | red | 1 | 2 |
| C1 | W3 | MAINS_E | mains_inlet.E | power_supply.FG | 24 | red | 1 | 2 |
| C2 | W4 | BUS_SERVO_BUS | servo_bus.SIG | shoulder_pitch_actuator.DATA | 26 | yellow | 0.02 | 0.02 |
| C2 | W5 | GND | servo_bus.GND | shoulder_pitch_actuator.GND | 24 | black | 0.05 | 0.05 |
| C2 | W6 | VBUS | servo_bus.VIN | shoulder_pitch_actuator.VCC | 22 | red | 1.55 | 5.1 |
| C3 | W7 | VBUS | shoulder_pitch_actuator.VCC | elbow_pitch_actuator.VCC | 22 | red | 0.9 | 3.15 |
| C3 | W8 | GND | shoulder_pitch_actuator.GND | elbow_pitch_actuator.GND | 22 | black | 0.9 | 3.15 |
| C3 | W9 | BUS_SERVO_BUS | shoulder_pitch_actuator.DATA | elbow_pitch_actuator.DATA | 26 | yellow | 0.02 | 0.02 |
| C4 | W10 | VBUS | elbow_pitch_actuator.VCC | gripper_actuator.VCC | 24 | red | 0.45 | 2.7 |
| C4 | W11 | GND | elbow_pitch_actuator.GND | gripper_actuator.GND | 24 | black | 0.45 | 2.7 |
| C4 | W12 | BUS_SERVO_BUS | elbow_pitch_actuator.DATA | gripper_actuator.DATA | 26 | yellow | 0.02 | 0.02 |
| C5 | W13 | VBUS | power_supply.DC OUTPUT +V | servo_bus.VIN | 22 | red | 1.55 | 5.1 |
| C5 | W14 | GND | power_supply.DC OUTPUT -V | servo_bus.GND | 22 | black | 1.55 | 5.1 |

## Cut list

Length is route + service loop + joint slack + termination, rounded up to 5 mm; cut every conductor of a cable to it.

| Cable | What | Conductors | Length mm | Route | Service | Joint slack | Ends | Connectors | Exit |
|---|---|--:|--:|--:|--:|--:|--:|---|---|
| C1 | mains inlet to the supply (crimped, insulated spades; earth first) | 3 | 185 | 80.5 | 40 | 0 | 60 | 6.3 mm quick-connect tabs / barrier screw terminal | - |
| C2 | servo_bus to shoulder_pitch_actuator | 3 | 810 | 706.9 | 40 | 0 | 60 | 3-pin 2.5 mm bus servo header (5264 class) / Feetech 5264-3P | control_case.harness |
| C3 | shoulder_pitch_actuator to elbow_pitch_actuator | 3 | 340 | 178 | 40 | 60 | 60 | Feetech 5264-3P / Feetech 5264-3P | - |
| C4 | elbow_pitch_actuator to gripper_actuator | 3 | 350 | 177.9 | 40 | 70 | 60 | Feetech 5264-3P / Feetech 5264-3P | - |
| C5 | VBUS to servo_bus | 2 | 200 | 99.1 | 40 | 0 | 60 | barrier screw terminal / green screw terminal | - |

## Slack at the joints

Each loop is at least the extra length the joint needs at the far end of its travel, swept over its real limits.

| Cable | Joint | Travel rad | Length at home mm | Length at full travel mm | Slack loop mm |
|---|---|---|--:|--:|--:|
| C3 | shoulder_pitch | -1.75 to 1.75 | 44.3 | 68.3 | 60 |
| C4 | elbow_pitch | -2.3 to 2.3 | 44.2 | 75.8 | 70 |

## Wiring parts to buy

| Item | Qty | Unit | Unit $ | Subtotal $ | Spec | Price source |
|---|--:|---|--:|--:|---|---|
| 22 AWG silicone wire | 2.1 | m | 0.4 | 0.84 | 0.327 mm2, rated 3.5 A in a bundle; 1.89 m cut + 10 % waste | estimated |
| 24 AWG silicone wire | 2.3 | m | 0.35 | 0.80 | 0.205 mm2, rated 1.75 A in a bundle; 2.06 m cut + 10 % waste | estimated |
| 26 AWG silicone wire | 1.7 | m | 0.3 | 0.51 | 0.128 mm2, rated 1.1 A in a bundle; 1.50 m cut + 10 % waste | estimated |
| 6.3 mm spade contacts | 3 | pc | 0.08 | 0.24 | rated 15 A per contact | estimated |
| Bootlace ferrule contacts | 7 | pc | 0.03 | 0.21 | rated 17.5 A per contact | estimated |
| Molex 5264 contacts | 18 | pc | 0.05 | 0.90 | rated 3 A per contact | estimated |
| Molex 5264 housings | 6 | pc | 0.08 | 0.48 | one per cable end | estimated |
| Heat shrink 3 mm, 2:1 | 0.3 | m | 0.2 | 0.06 | 0 solder joints + a boot on each cable end | estimated |
| Cable tie 100 x 2.5 mm | 10 | pc | 0.02 | 0.20 | at every clip, cable end and strain-relief anchor | estimated |
| PG7 cable gland | 1 | pc | 2.97 | 2.97 | cable exit with strain relief | estimated |
| Nylon braided sleeving 6 mm | 0.4 | m | 0.4 | 0.16 | over every cable where it crosses a joint | estimated |

## Data sources

| Part | Voltage | Current | Pins | Connector |
|---|---|---|---|---|
| Feetech STS3215 C047 12 V 30 kg.cm | [datasheet](https://files.seeedstudio.com/Bazaar/product_pdf/108090003.pdf) | estimated | [datasheet](https://files.waveshare.com/wiki/Bus-Servo-Adapter-(A)/Bus%20Servo%20Adapter%20(A)-Sch.pdf) | estimated |
| Feetech STS3250 C002 12 V 50 kg.cm | [datasheet](https://evelta.com/12v-50kg-360deg-magnetic-encoder-double-shaft-ttl-servo) | estimated | [datasheet](https://files.waveshare.com/wiki/Bus-Servo-Adapter-(A)/Bus%20Servo%20Adapter%20(A)-Sch.pdf) | estimated |
| IEC C14 panel inlet with fuse drawer and rocker switch, 10 A | estimated | estimated | estimated | estimated |
| Mean Well LRS-75-12 enclosed PSU, 12 V 6 A | [datasheet](https://www.meanwell.com/Upload/PDF/LRS-75/LRS-75-SPEC.PDF) | [datasheet](https://www.meanwell.com/Upload/PDF/LRS-75/LRS-75-SPEC.PDF) | [datasheet](https://www.meanwell.com/Upload/PDF/LRS-75/LRS-75-SPEC.PDF) | [datasheet](https://www.meanwell.com/Upload/PDF/LRS-75/LRS-75-SPEC.PDF) |
| Waveshare Bus Servo Adapter | [datasheet](https://www.waveshare.com/bus-servo-adapter-a.htm) | estimated | estimated | [datasheet](https://www.waveshare.com/wiki/Bus_Servo_Adapter_(A)) |

## Notes

- Mains side: IEC inlet to the supply's AC terminals with insulated spades, earth wired first, case closed before plugging in. Have it checked if you are not qualified to wire mains.
