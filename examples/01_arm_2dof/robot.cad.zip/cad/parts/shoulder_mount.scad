// concept part: shoulder_mount (joint_mount)
// units: mm. Mesh with: openscad -o shoulder_mount.stl shoulder_mount.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 123.008], [0, 0, 0, 1]])
  cylinder(h=6.016, r=20, center=true, $fn=48);
