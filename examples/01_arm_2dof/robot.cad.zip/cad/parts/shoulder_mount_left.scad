// concept part: shoulder_mount_left (joint_mount)
// units: mm. Mesh with: openscad -o shoulder_mount_left.stl shoulder_mount_left.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 23], [0, 0, 1, 142], [0, 0, 0, 1]])
  cube([20, 8, 44], center=true);
