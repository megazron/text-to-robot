// concept part: shoulder (shoulder)
// units: mm. Mesh with: openscad -o shoulder.stl shoulder.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 125], [0, 0, 0, 1]])
  cylinder(h=170, r=28.8, center=true, $fn=48);
