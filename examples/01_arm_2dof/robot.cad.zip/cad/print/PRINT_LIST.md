# Print list: arm_2dof

6 parts, about 540 g of PETG and 49.2 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 110 × 110 × 58.4 | 85 | 7.7 | yes |
| upper_arm | 171.4 × 30.8 × 62.3 | 116 | 10.6 | yes |
| forearm | 228.2 × 49.6 × 60.3 | 153 | 14.0 | yes |
| gripper_jaw | 84 × 39 × 8.5 | 10 | 0.9 | yes |
| control_case | 204.7 × 154.7 × 44.4 | 125 | 11.4 | yes |
| control_case_lid | 204.7 × 154.7 × 5.8 | 51 | 4.6 | yes |
