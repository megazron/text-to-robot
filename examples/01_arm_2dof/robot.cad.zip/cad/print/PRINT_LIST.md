# Print list — arm_2dof

4 parts, about 362 g of PETG and 33.0 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 110 × 110 × 58.4 | 85 | 7.8 | yes |
| upper_arm | 171.4 × 30.8 × 62.3 | 117 | 10.7 | yes |
| forearm | 228.2 × 49.6 × 60.3 | 152 | 13.8 | yes |
| gripper_jaw | 84 × 39 × 8.5 | 8 | 0.8 | yes |
