# Print list — arm_2dof

4 parts, about 163 g of PETG and 14.8 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 110 × 110 × 58.4 | 81 | 7.4 | yes |
| upper_arm | 171.4 × 30.8 × 41.6 | 30 | 2.7 | yes |
| forearm | 228.2 × 47.6 × 40.4 | 47 | 4.3 | yes |
| gripper_jaw | 84 × 37 × 6.5 | 5 | 0.5 | yes |
