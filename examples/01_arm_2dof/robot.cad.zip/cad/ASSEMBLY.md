# Assembly — arm_2dof

Start from **base_link**.

1. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (shoulder_pitch_actuator) in **base_link** with its case screws.
2. Set joint `shoulder_pitch` to zero (centre the servo first), then screw **upper_arm** to the actuator output in **base_link**; it moves -100° … 100°.
3. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (elbow_pitch_actuator) in **upper_arm** with its case screws.
4. Set joint `elbow_pitch` to zero (centre the servo first), then screw **forearm** to the actuator output in **upper_arm**; it moves -132° … 132°.
5. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (gripper_actuator) in **forearm** with its case screws.
6. Set joint `gripper` to zero (centre the servo first), then screw **gripper_jaw** to the actuator output in **forearm**; it moves -20° … 27°.
7. Bolt **control_case** to **base_link**.
8. Bolt **control_case_lid** to **control_case**.
9. Mount the **Mean Well LRS-75-12 enclosed PSU, 12 V 6 A (75 W)** (power_supply) in **control_case** with its case screws.
10. Mount the **Waveshare Bus Servo Adapter (A)** (servo_bus) in **control_case** with its case screws.
11. Mount the **IEC C14 panel inlet with fuse drawer and rocker switch, 10 A** (mains_inlet) in **control_case** with its case screws.

## Fasteners

- 4 × M5 x 12 socket head (base to bench)
- 8 × M2 x 6 case screws
- 12 × horn screws
- 2 × M5 x 16 socket head + M5 washer + M5 heat-set insert (clevis bearing axle)
- 4 × M3 x 10 self-tapping (lid to compartment)
- 2 × M3 x 6 self-tapping (Mean Well LRS-75-12 enclosed PSU, 12 V 6 A to standoffs)
- 4 × M2 x 6 self-tapping (Waveshare Bus Servo Adapter to standoffs)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
