# Printability — arm_2dof

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 120 × 120 × 120 | ✅ |
| shoulder | 80 × 80 × 100 | ✅ |
| upper_arm | 80 × 80 × 250 | ❌ |
| gripper_base | 60 × 80 × 30 | ✅ |
| left_finger | 15 × 20 × 60 | ✅ |
| right_finger | 15 × 20 × 60 | ✅ |

## Notes
- ⚠️ **upper_arm**: longest dimension 250 mm exceeds the 220 mm build volume — split the part or print diagonally
