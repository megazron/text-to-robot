# Printability — arm_2dof

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 144 × 144 × 3 | ✅ |
| base_link_service_lid | 144 × 144 × 3 | ✅ |
| base_link_rear_panel | 3 × 144 × 114 | ✅ |
| base_link_right_panel | 138 × 3 × 114 | ✅ |
| base_link_front_panel | 3 × 144 × 114 | ✅ |
| base_link_left_panel | 138 × 3 × 114 | ✅ |
| base_link_standoff_rr | 8 × 8 × 114 | ✅ |
| base_link_standoff_rl | 8 × 8 × 114 | ✅ |
| base_link_standoff_fr | 8 × 8 × 114 | ✅ |
| base_link_standoff_fl | 8 × 8 × 114 | ✅ |
| shoulder | 57.6 × 57.6 × 170 | ✅ |
| shoulder_mount | 40 × 40 × 6 | ✅ |
| shoulder_joint_hub | 68 × 68 × 26 | ✅ |
| upper_arm | 57.6 × 57.6 × 170 | ✅ |
| upper_arm_joint_hub | 68 × 68 × 26 | ✅ |
| gripper_base | 60 × 80 × 30 | ✅ |
| left_finger | 15 × 20 × 60 | ✅ |
| right_finger | 15 × 20 × 60 | ✅ |
| left_finger_pad | 15 × 2 × 36 | ✅ |
| right_finger_pad | 15 × 2 × 36 | ✅ |

## Notes
- ⚠️ **left_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
