# Assembly: underwater_rov

Start from **base_link**.

1. Bolt **skid_fore** to **base_link**.
2. Bolt **frame_tube_rb** to **base_link**.
3. Bolt **frame_tube_rt** to **base_link**.
4. Bolt **frame_tube_lb** to **base_link**.
5. Bolt **frame_tube_lt** to **base_link**.
6. Bolt **bow_frame** to **base_link**.
7. Bolt **stern_frame** to **base_link**.
8. Bolt **saddle_fore** to **base_link**.
9. Bolt **saddle_aft** to **base_link**.
10. Mount the **Blue Robotics 4 in watertight enclosure, 298 mm acrylic tube, aluminium end caps (rated 100 m)** (hull) in **base_link** with its case screws.
11. Bolt **hull_tray_aft** to **hull**.
12. Bolt **hull_tray_fore** to **hull_tray_aft**.
13. Mount the **Raspberry Pi 5 (4 GB)** (controller) in **hull_tray_fore** with its case screws.
14. Mount the **PCA9685 16-channel PWM servo driver board (generic, I2C)** (pwm_driver) in **hull_tray_fore** with its case screws.
15. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator) in **hull_tray_fore** with its case screws.
16. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **hull_tray_fore** with its case screws.
17. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (camera) in **hull_tray_fore** with its case screws.
18. Mount the **LiPo 4S 5000 mAh 60C, XT90 (Gens Ace G-Tech)** (battery) in **hull_tray_aft** with its case screws.
19. Mount the **Blue Robotics Basic ESC 30 A (7-26 V, PWM input)** (esc_1) in **hull_tray_aft** with its case screws.
20. Mount the **Blue Robotics Basic ESC 30 A (7-26 V, PWM input)** (esc_2) in **hull_tray_aft** with its case screws.
21. Mount the **Blue Robotics Basic ESC 30 A (7-26 V, PWM input)** (esc_3) in **hull_tray_aft** with its case screws.
22. Mount the **Blue Robotics Basic ESC 30 A (7-26 V, PWM input)** (esc_4) in **hull_tray_aft** with its case screws.
23. Bolt **thruster_left_post** to **base_link**.
24. Mount the **Blue Robotics T200 underwater thruster (7-20 V)** (thruster_left) in **base_link** with its case screws.
25. Bolt **thruster_right_post** to **base_link**.
26. Mount the **Blue Robotics T200 underwater thruster (7-20 V)** (thruster_right) in **base_link** with its case screws.
27. Bolt **thruster_vert_left_post** to **base_link**.
28. Mount the **Blue Robotics T200 underwater thruster (7-20 V)** (thruster_vert_left) in **base_link** with its case screws.
29. Bolt **thruster_vert_right_post** to **base_link**.
30. Mount the **Blue Robotics T200 underwater thruster (7-20 V)** (thruster_vert_right) in **base_link** with its case screws.
31. Mount the **Subsea buoyancy foam block, R-3318 urethane, about 1 L (cut to shape)** (foam_1) in **base_link** with its case screws.
32. Mount the **Stainless ballast weight 200 g (trim)** (ballast_1) in **base_link** with its case screws.
33. Mount the **Stainless ballast weight 200 g (trim)** (ballast_2) in **base_link** with its case screws.
34. Mount the **Stainless ballast weight 200 g (trim)** (ballast_3) in **base_link** with its case screws.
35. Mount the **Stainless ballast weight 200 g (trim)** (ballast_4) in **base_link** with its case screws.
36. Mount the **Stainless ballast weight 200 g (trim)** (ballast_5) in **base_link** with its case screws.

## Fasteners

- 2 × M3 x 20 + nut (skid halves, through the joining lugs)
- 16 × M4 x 25 + nyloc (tube sockets, through the tube)
- 2 × M3 x 20 + nut (tray halves)
- 16 × M2.5 x 6 self-tapping (boards to tray)
- 8 × M3 x 12 (thruster foot to post)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
