# Print list: underwater_rov

12 parts, about 874 g of PETG and 79.7 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 168 × 186 × 31 | 125 | 11.4 | yes |
| skid_fore | 168 × 186 × 31 | 125 | 11.4 | yes |
| bow_frame | 24 × 190 × 170 | 67 | 6.1 | yes |
| stern_frame | 24 × 190 × 170 | 67 | 6.1 | yes |
| saddle_fore | 16 × 188 × 168 | 86 | 7.8 | yes |
| saddle_aft | 16 × 188 × 168 | 86 | 7.8 | yes |
| hull_tray_aft | 140 × 88 × 24 | 47 | 4.3 | yes |
| hull_tray_fore | 140 × 88 × 29.4 | 50 | 4.5 | yes |
| thruster_left_post | 28 × 28 × 168 | 56 | 5.1 | yes |
| thruster_right_post | 28 × 28 × 168 | 56 | 5.1 | yes |
| thruster_vert_left_post | 28 × 28 × 168 | 56 | 5.1 | yes |
| thruster_vert_right_post | 28 × 28 × 168 | 56 | 5.1 | yes |
