#!/usr/bin/env python3
"""Replay a motion made by Text to Robot.

  ros2 launch baymax display.launch.py motion:=<motion>   (RViz replays motions/<motion>.yaml in a loop)
  python3 scripts/replay_motion.py motions/<motion>.yaml --all-joints urdf/baymax.urdf   (publishes /joint_states yourself)

  python3 scripts/replay_motion.py motions/<motion>.yaml --controller /joint_trajectory_controller
      sends the whole trajectory to a running joint_trajectory_controller (Gazebo or the robot) instead.
Joints the file does not list stay at zero. Needs rclpy and PyYAML (both come with ROS 2).
"""
import argparse, sys, time
import yaml
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration


def main():
    ap = argparse.ArgumentParser(description="Replay a Text to Robot motion")
    ap.add_argument("file")
    ap.add_argument("--controller", help="send to <controller>/joint_trajectory instead of publishing joint states")
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--rate", type=float, default=1.0, help="playback speed")
    ap.add_argument("--all-joints", metavar="URDF", help="also publish 0 for every other moving joint of this URDF (robot_state_publisher needs them all)")
    a = ap.parse_args(rclpy.utilities.remove_ros_args(sys.argv)[1:])
    msg = yaml.safe_load(open(a.file))
    names, pts = msg["joint_names"], msg["points"]
    rest = []
    if a.all_joints:
        import xml.etree.ElementTree as ET
        rest = [j.get("name") for j in ET.parse(a.all_joints).getroot().findall("joint") if j.get("type") != "fixed" and j.find("mimic") is None and j.get("name") not in names]
    rclpy.init()
    node = Node("replay_motion")
    if a.controller:
        pub = node.create_publisher(JointTrajectory, a.controller.rstrip("/") + "/joint_trajectory", 10)
        time.sleep(1.0)
        jt = JointTrajectory(joint_names=names)
        for p in pts:
            t = (p["time_from_start"]["sec"] + p["time_from_start"]["nanosec"] * 1e-9) / a.rate
            jt.points.append(JointTrajectoryPoint(positions=[float(x) for x in p["positions"]], velocities=[float(x) * a.rate for x in p.get("velocities", [])], time_from_start=Duration(sec=int(t), nanosec=int((t % 1) * 1e9))))
        pub.publish(jt); rclpy.spin_once(node, timeout_sec=0.5)
        print(f"sent {len(pts)} points to {a.controller}"); return
    pub = node.create_publisher(JointState, "joint_states", 10)
    while rclpy.ok():
        t0 = time.monotonic()
        for p in pts:
            t = (p["time_from_start"]["sec"] + p["time_from_start"]["nanosec"] * 1e-9) / a.rate
            while time.monotonic() - t0 < t: time.sleep(0.002)
            js = JointState(name=names + rest, position=[float(x) for x in p["positions"]] + [0.0] * len(rest))
            js.header.stamp = node.get_clock().now().to_msg(); pub.publish(js)
        if not a.loop: break
    node.destroy_node(); rclpy.shutdown()


if __name__ == "__main__":
    main()
