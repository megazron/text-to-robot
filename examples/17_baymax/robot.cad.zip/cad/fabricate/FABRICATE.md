# Fabricated parts — baymax

Not printed: made from sheet, tube or fabric (see BOM.md for the exact item and cost). Each STL is the finished shape; plates are 2D-cut from it (export the top face as DXF for laser or waterjet cutting).

| Part | Material | Mass (g) |
|---|---|--:|
| base_link | aluminium | 888 |
| spine | aluminium | 332 |
| shoulder_yoke | aluminium | 272 |
| left_arm_upper_arm_sleeve | fabric | 40 |
| left_arm_forearm_sleeve | fabric | 40 |
| left_arm_mitten | fabric | 90 |
| right_arm_upper_arm_sleeve | fabric | 40 |
| right_arm_forearm_sleeve | fabric | 40 |
| right_arm_mitten | fabric | 90 |
| soft_cover | fabric | 550 |
