# Assembly — baymax

Start from **base_link**.

1. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (left_front_motor) in **base_link** with its case screws.
2. Fit **left_front_wheel** on the output of the motor in **base_link** (driven joint `left_front_wheel_joint`).
3. Bolt **left_front_bracket** to **base_link**.
4. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (left_rear_motor) in **base_link** with its case screws.
5. Fit **left_rear_wheel** on the output of the motor in **base_link** (driven joint `left_rear_wheel_joint`).
6. Bolt **left_rear_bracket** to **base_link**.
7. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (right_front_motor) in **base_link** with its case screws.
8. Fit **right_front_wheel** on the output of the motor in **base_link** (driven joint `right_front_wheel_joint`).
9. Bolt **right_front_bracket** to **base_link**.
10. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (right_rear_motor) in **base_link** with its case screws.
11. Fit **right_rear_wheel** on the output of the motor in **base_link** (driven joint `right_rear_wheel_joint`).
12. Bolt **right_rear_bracket** to **base_link**.
13. Mount the **LiPo 3S 2200 mAh 25C, XT60 (Gens Ace G-Tech)** (battery) in **base_link** with its case screws.
14. Bolt **battery_tray** to **base_link**.
15. Mount the **Raspberry Pi 5 (4 GB)** (computer) in **base_link** with its case screws.
16. Bolt **computer_tray** to **base_link**.
17. Mount the **Cytron MDD10A dual-channel 10 A DC motor driver (5-30 V)** (motor_driver_1) in **base_link** with its case screws.
18. Bolt **motor_driver_1_tray** to **base_link**.
19. Mount the **Cytron MDD10A dual-channel 10 A DC motor driver (5-30 V)** (motor_driver_2) in **base_link** with its case screws.
20. Bolt **motor_driver_2_tray** to **base_link**.
21. Mount the **Waveshare Bus Servo Adapter (A)** (servo_bus) in **base_link** with its case screws.
22. Bolt **servo_bus_tray** to **base_link**.
23. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **base_link** with its case screws.
24. Bolt **imu_tray** to **base_link**.
25. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **base_link** with its case screws.
26. Bolt **regulator_5v_tray** to **base_link**.
27. Mount the **KCD4 double-pole rocker switch, 16 A 250 VAC / 20 A 125 VAC** (main_switch) in **base_link** with its case screws.
28. Bolt **electronics_enclosure_front** to **base_link**.
29. Bolt **electronics_enclosure_rear** to **base_link**.
30. Bolt **electronics_lid_front** to **base_link**.
31. Bolt **electronics_lid_rear** to **base_link**.
32. Bolt **spine_foot** to **base_link**.
33. Bolt **spine** to **base_link**.
34. Bolt **shoulder_yoke** to **spine**.
35. Bolt **left_arm_shoulder_wedge** to **shoulder_yoke**.
36. Bolt **left_arm_base_link** to **shoulder_yoke**.
37. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (left_arm_base_yaw_actuator) in **left_arm_base_link** with its case screws.
38. Set joint `left_arm_base_yaw` to zero (centre the servo first), then screw **left_arm_turret** to the actuator output in **left_arm_base_link**; it moves -170° … 170°.
39. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (left_arm_shoulder_pitch_actuator) in **left_arm_turret** with its case screws.
40. Set joint `left_arm_shoulder_pitch` to zero (centre the servo first), then screw **left_arm_upper_arm** to the actuator output in **left_arm_turret**; it moves -100° … 100°.
41. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (left_arm_elbow_pitch_actuator) in **left_arm_upper_arm** with its case screws.
42. Set joint `left_arm_elbow_pitch` to zero (centre the servo first), then screw **left_arm_forearm** to the actuator output in **left_arm_upper_arm**; it moves -132° … 132°.
43. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (left_arm_wrist_pitch_actuator) in **left_arm_forearm** with its case screws.
44. Set joint `left_arm_wrist_pitch` to zero (centre the servo first), then screw **left_arm_tool_link** to the actuator output in **left_arm_forearm**; it moves -132° … 132°.
45. Bolt **left_arm_mitten** to **left_arm_tool_link**.
46. Bolt **left_arm_forearm_sleeve** to **left_arm_forearm**.
47. Bolt **left_arm_upper_arm_sleeve** to **left_arm_upper_arm**.
48. Bolt **right_arm_shoulder_wedge** to **shoulder_yoke**.
49. Bolt **right_arm_base_link** to **shoulder_yoke**.
50. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (right_arm_base_yaw_actuator) in **right_arm_base_link** with its case screws.
51. Set joint `right_arm_base_yaw` to zero (centre the servo first), then screw **right_arm_turret** to the actuator output in **right_arm_base_link**; it moves -170° … 170°.
52. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (right_arm_shoulder_pitch_actuator) in **right_arm_turret** with its case screws.
53. Set joint `right_arm_shoulder_pitch` to zero (centre the servo first), then screw **right_arm_upper_arm** to the actuator output in **right_arm_turret**; it moves -100° … 100°.
54. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (right_arm_elbow_pitch_actuator) in **right_arm_upper_arm** with its case screws.
55. Set joint `right_arm_elbow_pitch` to zero (centre the servo first), then screw **right_arm_forearm** to the actuator output in **right_arm_upper_arm**; it moves -132° … 132°.
56. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (right_arm_wrist_pitch_actuator) in **right_arm_forearm** with its case screws.
57. Set joint `right_arm_wrist_pitch` to zero (centre the servo first), then screw **right_arm_tool_link** to the actuator output in **right_arm_forearm**; it moves -132° … 132°.
58. Bolt **right_arm_mitten** to **right_arm_tool_link**.
59. Bolt **right_arm_forearm_sleeve** to **right_arm_forearm**.
60. Bolt **right_arm_upper_arm_sleeve** to **right_arm_upper_arm**.
61. Bolt **neck_mount** to **shoulder_yoke**.
62. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (head_pan_actuator) in **shoulder_yoke** with its case screws.
63. Set joint `head_pan` to zero (centre the servo first), then screw **head** to the actuator output in **shoulder_yoke**; it moves -80° … 80°.
64. Bolt **head_dome** to **head**.
65. Bolt **eyes** to **head**.
66. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (head_camera) in **head** with its case screws.
67. Bolt **camera_bracket** to **head**.
68. Bolt **soft_cover** to **spine**.

## Fasteners

- 24 × M3 x 8 socket head (motor face)
- 8 × M3 x 10 socket head + nut (bracket to deck)
- 1 × 20 mm hook-and-loop battery strap
- 14 × M3 x 8 socket head (tray to deck)
- 23 × M2.5 x 6 screws (board to standoffs)
- 8 × M3 x 8 + nut (enclosure pieces lap joint)
- 4 × M3 x 10 self-tapping (enclosure lid)
- 4 × M3 x 8 + nut (enclosure tabs to deck; drill 3.4 mm through the deck at the tabs)
- 8 × M5 x 12 socket head (base to bench)
- 32 × M2 x 6 case screws
- 36 × horn screws
- 6 × M5 x 16 socket head + M5 washer + M5 heat-set insert (clevis bearing axle)
- 4 × M3 x 10 (head dome to head)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
