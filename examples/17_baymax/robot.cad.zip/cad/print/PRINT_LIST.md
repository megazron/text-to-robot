# Print list — baymax

28 parts, about 1246 g of PETG and 113.5 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| left_front_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| left_rear_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| right_front_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| right_rear_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| battery_tray | 110.6 × 40.7 × 16.2 | 17 | 1.5 | yes |
| computer_tray | 85.7 × 55.4 × 7 | 13 | 1.1 | yes |
| motor_driver_1_tray | 84.4 × 61.4 × 7 | 13 | 1.2 | yes |
| motor_driver_2_tray | 84.4 × 61.4 × 7 | 13 | 1.2 | yes |
| servo_bus_tray | 42.4 × 33.4 × 7 | 3 | 0.3 | yes |
| imu_tray | 26.9 × 24 × 7 | 2 | 0.1 | yes |
| regulator_5v_tray | 26.7 × 26.7 × 7 | 2 | 0.1 | yes |
| spine_foot | 56 × 56 × 40 | 26 | 2.3 | yes |
| left_arm_shoulder_wedge | 60 × 60 × 28.7 | 44 | 4.0 | yes |
| left_arm_base_link | 80.3 × 70 × 45.9 | 51 | 4.6 | yes |
| left_arm_turret | 39.5 × 54 × 71.5 | 33 | 3.0 | yes |
| left_arm_upper_arm | 200.6 × 34.5 × 69.2 | 153 | 13.9 | yes |
| left_arm_forearm | 198.4 × 34.5 × 62.1 | 147 | 13.4 | yes |
| left_arm_tool_link | 32.5 × 32.5 × 10 | 7 | 0.6 | yes |
| right_arm_shoulder_wedge | 60 × 60 × 28.7 | 44 | 4.0 | yes |
| right_arm_base_link | 80.3 × 70 × 45.9 | 51 | 4.6 | yes |
| right_arm_turret | 39.5 × 54 × 71.5 | 33 | 3.0 | yes |
| right_arm_upper_arm | 200.6 × 34.5 × 69.2 | 153 | 13.9 | yes |
| right_arm_forearm | 198.4 × 34.5 × 62.1 | 147 | 13.4 | yes |
| right_arm_tool_link | 32.5 × 32.5 × 10 | 7 | 0.6 | yes |
| neck_mount | 64.2 × 48 × 44 | 29 | 2.6 | yes |
| head | 168.3 × 216 × 146 | 188 | 17.1 | yes |
| eyes | 7.2 × 78 × 22 | 3 | 0.3 | yes |
| camera_bracket | 29 × 32 × 40 | 8 | 0.7 | yes |
