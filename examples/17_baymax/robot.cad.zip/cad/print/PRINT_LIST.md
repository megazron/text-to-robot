# Print list: baymax

33 parts, about 1382 g of PETG and 125.9 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| left_front_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| left_rear_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| right_front_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| right_rear_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| battery_tray | 125.6 × 40.7 × 16.2 | 18 | 1.7 | yes |
| computer_tray | 90 × 59.2 × 7 | 15 | 1.4 | yes |
| motor_driver_1_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| motor_driver_2_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| servo_bus_tray | 44 × 35 × 7 | 5 | 0.4 | yes |
| imu_tray | 27.6 × 24.7 × 7 | 2 | 0.2 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| electronics_enclosure_front | 203.9 × 153.3 × 45.1 | 52 | 4.7 | yes |
| electronics_enclosure_rear | 203.9 × 166.3 × 45.1 | 51 | 4.6 | yes |
| electronics_lid_front | 190.9 × 148.2 × 5.4 | 44 | 4.0 | yes |
| electronics_lid_rear | 190.9 × 156.1 × 5.4 | 44 | 4.0 | yes |
| spine_foot | 56 × 56 × 40 | 26 | 2.3 | yes |
| left_arm_shoulder_wedge | 60 × 60 × 28.7 | 38 | 3.5 | yes |
| left_arm_base_link | 79.2 × 70 × 46.1 | 41 | 3.8 | yes |
| left_arm_turret | 30.8 × 44.1 × 57.4 | 18 | 1.7 | yes |
| left_arm_upper_arm | 197.1 × 43.2 × 63.8 | 141 | 12.8 | yes |
| left_arm_forearm | 197.1 × 30.8 × 62.3 | 141 | 12.8 | yes |
| left_arm_tool_link | 40 × 40 × 10 | 9 | 0.8 | yes |
| right_arm_shoulder_wedge | 60 × 60 × 28.7 | 38 | 3.5 | yes |
| right_arm_base_link | 79.2 × 70 × 46.1 | 41 | 3.8 | yes |
| right_arm_turret | 30.8 × 44.1 × 57.4 | 18 | 1.7 | yes |
| right_arm_upper_arm | 197.1 × 30.8 × 62.3 | 141 | 12.8 | yes |
| right_arm_forearm | 197.1 × 30.8 × 62.3 | 141 | 12.8 | yes |
| right_arm_tool_link | 40 × 40 × 10 | 9 | 0.8 | yes |
| neck_mount | 64.2 × 48 × 44 | 26 | 2.3 | yes |
| head | 168.3 × 216 × 98 | 137 | 12.4 | yes |
| head_dome | 164.2 × 210.5 × 52.1 | 82 | 7.5 | yes |
| eyes | 7.2 × 78 × 22 | 3 | 0.3 | yes |
| camera_bracket | 29 × 46.3 × 41.1 | 8 | 0.7 | yes |
