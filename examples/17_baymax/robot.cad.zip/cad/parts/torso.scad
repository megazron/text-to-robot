// concept part: torso (base)
// units: mm. Mesh with: openscad -o torso.stl torso.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 673.2], [0, 0, 0, 1]])
  hull() { translate([0,0,81]) sphere(r=154, $fn=32); translate([0,0,-81]) sphere(r=154, $fn=32); }
