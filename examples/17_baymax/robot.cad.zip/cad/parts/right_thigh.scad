// concept part: right_thigh (link)
// units: mm. Mesh with: openscad -o right_thigh.stl right_thigh.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -100], [0, 0, 0, 1]])
  hull() { translate([0,0,19]) sphere(r=81, $fn=32); translate([0,0,-19]) sphere(r=81, $fn=32); }
