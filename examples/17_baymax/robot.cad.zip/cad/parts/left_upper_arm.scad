// concept part: left_upper_arm (upper_arm)
// units: mm. Mesh with: openscad -o left_upper_arm.stl left_upper_arm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -110], [0, 0, 0, 1]])
  hull() { translate([0,0,47]) sphere(r=63, $fn=32); translate([0,0,-47]) sphere(r=63, $fn=32); }
