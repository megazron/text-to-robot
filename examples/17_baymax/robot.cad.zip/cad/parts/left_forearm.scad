// concept part: left_forearm (forearm)
// units: mm. Mesh with: openscad -o left_forearm.stl left_forearm.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -110], [0, 0, 0, 1]])
  hull() { translate([0,0,47]) sphere(r=63, $fn=32); translate([0,0,-47]) sphere(r=63, $fn=32); }
