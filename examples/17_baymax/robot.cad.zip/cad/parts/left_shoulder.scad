// concept part: left_shoulder (shoulder)
// units: mm. Mesh with: openscad -o left_shoulder.stl left_shoulder.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -30], [0, 0, 0, 1]])
  hull() { translate([0,0,2.5]) sphere(r=63, $fn=32); translate([0,0,-2.5]) sphere(r=63, $fn=32); }
