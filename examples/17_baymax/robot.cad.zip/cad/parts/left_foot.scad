// concept part: left_foot (link)
// units: mm. Mesh with: openscad -o left_foot.stl left_foot.scad
multmatrix([[1, 0, 0, 50], [0, 1, 0, 0], [0, 0, 1, -25], [0, 0, 0, 1]])
  cube([260, 160, 50], center=true);
