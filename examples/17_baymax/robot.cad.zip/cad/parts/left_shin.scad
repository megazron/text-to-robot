// concept part: left_shin (link)
// units: mm. Mesh with: openscad -o left_shin.stl left_shin.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -98.5], [0, 0, 0, 1]])
  hull() { translate([0,0,26.5]) sphere(r=72, $fn=32); translate([0,0,-26.5]) sphere(r=72, $fn=32); }
