// concept part: left_shin (link)
// units: mm. Mesh with: openscad -o left_shin.stl left_shin.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -100], [0, 0, 0, 1]])
  hull() { translate([0,0,28]) sphere(r=72, $fn=32); translate([0,0,-28]) sphere(r=72, $fn=32); }
