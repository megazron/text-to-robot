// concept part: right_elbow (elbow)
// units: mm. Mesh with: openscad -o right_elbow.stl right_elbow.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -30], [0, 0, 0, 1]])
  hull() { translate([0,0,2.5]) sphere(r=63, $fn=32); translate([0,0,-2.5]) sphere(r=63, $fn=32); }
