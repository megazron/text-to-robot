// concept part: head (link)
// units: mm. Mesh with: openscad -o head.stl head.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  sphere(r=72, $fn=48);
