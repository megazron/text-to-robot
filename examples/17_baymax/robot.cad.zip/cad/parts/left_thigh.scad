// concept part: left_thigh (link)
// units: mm. Mesh with: openscad -o left_thigh.stl left_thigh.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -100], [0, 0, 0, 1]])
  hull() { translate([0,0,19]) sphere(r=81, $fn=32); translate([0,0,-19]) sphere(r=81, $fn=32); }
