# Build package — baymax

Baymax-style service robot: 5.571 kg, 1.01 m tall, 4WD hidden base, two 4-servo arms, pan head with camera

1. **Buy** everything in `BOM.md` (supplier links included).
2. **Print** every STL in `print/` (see `print/PRINT_LIST.md`).
3. **Assemble** in the order of `ASSEMBLY.md`.
   **Wire** from `WIRING.md` (pin-to-pin table, cut list, power budget) and `wiring.svg`.
4. **Check** against `design.json`: each actuator's required vs rated torque, the speed it reaches loaded, battery runtime, stability and every other check the design passed.

`reference/` holds the bought parts' models (from their datasheet drawings) for your own CAD; `baymax_assembly.stl` is the whole robot in its build pose.

## Assumptions

- Baymax's inflatable vinyl body is a sewn ripstop cover with a foam-lined zip, bought or sewn, with negligible structural role; it hangs on the shoulder yoke and hides a 4WD skid-steer base. It is not inflated, so it does not cushion like the film's.
- Structure: 2020 aluminium extrusion spine and a 6 mm aluminium shoulder yoke; arms are four servos each (shoulder yaw, shoulder pitch, elbow, wrist) splayed 25 deg so they clear the belly; the hands are printed mittens covered with the same fabric.
- Each arm is sized as mounted to lift 0.1 kg in the mitten at full reach; the tipping check includes both arms stretched forward with that payload.
- The head turns on one pan servo; a camera looks out between the eyes through a 12 mm hole.
