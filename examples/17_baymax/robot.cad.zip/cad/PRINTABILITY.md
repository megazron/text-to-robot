# Printability — baymax

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| torso | 308 × 308 × 470 | ❌ |
| head | 144 × 144 × 144 | ✅ |
| left_shoulder | 126 × 126 × 131 | ✅ |
| left_upper_arm | 126 × 126 × 220 | ✅ |
| left_elbow | 126 × 126 × 131 | ✅ |
| left_forearm | 126 × 126 × 220 | ✅ |
| right_shoulder | 126 × 126 × 131 | ✅ |
| right_upper_arm | 126 × 126 × 220 | ✅ |
| right_elbow | 126 × 126 × 131 | ✅ |
| right_forearm | 126 × 126 × 220 | ✅ |
| left_hip_yaw_carrier | 46 × 46 × 16 | ✅ |
| left_hip_roll_carrier | 40 × 40 × 18 | ✅ |
| left_thigh | 162 × 162 × 200 | ✅ |
| left_shin | 144 × 144 × 200 | ✅ |
| left_foot | 260 × 160 × 50 | ❌ |
| left_ankle_pitch_carrier | 30 × 30 × 22 | ✅ |
| right_hip_yaw_carrier | 46 × 46 × 16 | ✅ |
| right_hip_roll_carrier | 40 × 40 × 18 | ✅ |
| right_thigh | 162 × 162 × 200 | ✅ |
| right_shin | 144 × 144 × 200 | ✅ |
| right_foot | 260 × 160 × 50 | ❌ |
| right_ankle_pitch_carrier | 30 × 30 × 22 | ✅ |

## Notes
- ⚠️ **torso**: longest dimension 470 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **head**: sphere needs supports or a flat-cut base to print
- ⚠️ **left_foot**: longest dimension 260 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_foot**: longest dimension 260 mm exceeds the 220 mm build volume — split the part or print diagonally
