# baymax in MuJoCo

Test, render and train this exact robot in MuJoCo with the text-to-robot Python layer:

```bash
pip install -r requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cpu    # CPU torch on GPU-less machines

python -m ttr_mujoco test   ../baymax.urdf --self-collision                       # settle / hold / actuator sweep / disturbance
python -m ttr_mujoco render ../baymax.urdf --self-collision -o baymax.gif --motion sweep
python -m ttr_mujoco train  ../baymax.urdf --self-collision --task stand --steps 400000
```

Mesh-based exports first prepare approximate convex collision hulls. This preserves
hollow regions better than bounding boxes; inspect the generated collision report.
Simulation and training do not validate hardware fit or a learned policy.

Or from Python:

```python
from ttr_mujoco import urdf_to_mjcf, run_tests, render_gif
from ttr_mujoco.env import MujocoRobotEnv
report = run_tests(urdf_to_mjcf("../baymax.urdf", self_collision=True))              # dict with per-test pass/fail + metrics
env = MujocoRobotEnv("../baymax.urdf", self_collision=True, task="stand")
```
