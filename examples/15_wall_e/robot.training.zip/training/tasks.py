"""Task catalogue (auto-generated). Each task returns (reward, terminated)."""
import numpy as np
import pybullet as p

def forward(self, action):
    vel, _ = self.p.getBaseVelocity(self.robot)
    pos, _ = self.p.getBasePositionAndOrientation(self.robot)
    reward = float(vel[0]) - 0.5 * abs(float(vel[1]))
    terminated = pos[2] < 0.02
    return float(reward), bool(terminated)

def goto(self, action):
    pos, _ = self.p.getBasePositionAndOrientation(self.robot)
    dist = float(np.linalg.norm(np.array(pos[:2]) - self.target[:2]))
    reward = -dist
    terminated = dist < 0.15
    return float(reward), bool(terminated)

TASKS = {
    "forward": ("Drive forward as fast as possible", forward),
    "goto": ("Navigate to a goal point", goto),
}
DEFAULT_TASK = "forward"
