# Print list: wall_e

21 parts, about 582 g of PETG and 53.0 h of printing.

Exact solids of these parts are in `cad/step/` (STEP AP214, millimetres): open them in Fusion, FreeCAD or Onshape to edit.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| body | 172.5 × 128 × 130 | 196 | 17.9 | yes |
| front_band | 2 × 124 × 34 | 8 | 0.7 | yes |
| charge_gauge | 2 × 32 × 20 | 1 | 0.1 | yes |
| name_plate | 1.6 × 80 × 13 | 2 | 0.1 | yes |
| track_left | 205 × 27 × 106.5 | 31 | 2.8 | yes |
| left_idler | 32 × 32 × 22 | 13 | 1.2 | yes |
| track_right | 205 × 27 × 106.5 | 31 | 2.8 | yes |
| right_idler | 32 × 32 × 22 | 13 | 1.2 | yes |
| lid | 170 × 128 × 30.2 | 78 | 7.1 | yes |
| neck | 41 × 41 × 101.9 | 29 | 2.6 | yes |
| head | 94 × 50.5 × 127 | 93 | 8.4 | yes |
| left_lens | 38.6 × 5.4 × 38.6 | 4 | 0.4 | yes |
| right_lens | 38.6 × 5.4 × 38.6 | 4 | 0.4 | yes |
| left_arm | 41 × 96.5 × 29.2 | 13 | 1.2 | yes |
| left_forearm | 142.5 × 41 × 22 | 18 | 1.6 | yes |
| left_arm_stripes | 24 × 22 × 2 | 1 | 0.1 | yes |
| left_thumb | 69.5 × 41 × 33.1 | 8 | 0.7 | yes |
| right_arm | 41 × 96.5 × 29.2 | 13 | 1.2 | yes |
| right_forearm | 142.5 × 41 × 22 | 18 | 1.6 | yes |
| right_arm_stripes | 24 × 22 × 2 | 1 | 0.1 | yes |
| right_thumb | 69.5 × 41 × 33.1 | 8 | 0.7 | yes |
