# Print list — wall_e

11 parts, about 490 g of PETG and 44.6 h of printing.

Exact solids of these parts are in `cad/step/` (STEP AP214, millimetres): open them in Fusion, FreeCAD or Onshape to edit.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| body | 172.5 × 128 × 130 | 201 | 18.3 | yes |
| charge_gauge | 2 × 30 × 36 | 1 | 0.1 | yes |
| track_left | 201 × 27 × 71 | 30 | 2.7 | yes |
| track_right | 201 × 27 × 71 | 30 | 2.7 | yes |
| lid | 170 × 128 × 30.2 | 78 | 7.1 | yes |
| neck | 41 × 41 × 101.9 | 29 | 2.6 | yes |
| head | 86 × 53.5 × 93 | 91 | 8.3 | yes |
| left_lens | 26.6 × 2.9 × 26.6 | 1 | 0.1 | yes |
| right_lens | 26.6 × 2.9 × 26.6 | 1 | 0.1 | yes |
| left_arm | 41 × 114.5 × 12 | 14 | 1.3 | yes |
| right_arm | 41 × 114.5 × 12 | 14 | 1.3 | yes |
