# Print list — wall_e

29 parts, about 2347 g of PETG and 213.9 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 220 × 200 × 6 | 239 | 21.8 | yes |
| left_track_frame | 244 × 44 × 48 | 83 | 7.5 | yes |
| right_track_frame | 244 × 44 × 48 | 83 | 7.5 | yes |
| body_left | 220 × 4 × 200 | 160 | 14.6 | yes |
| body_right | 220 × 4 × 200 | 160 | 14.6 | yes |
| body_back | 4 × 192 × 200 | 140 | 12.7 | yes |
| body_front | 7 × 192 × 200 | 179 | 16.3 | yes |
| body_top | 220 × 200 × 4 | 160 | 14.6 | yes |
| battery_tray | 40.7 × 110.6 × 16.2 | 17 | 1.5 | yes |
| motor_driver_1_tray | 61.4 × 84.4 × 7 | 13 | 1.2 | yes |
| regulator_5v_tray | 26.7 × 26.7 × 7 | 2 | 0.1 | yes |
| shelf | 211 × 191 × 4 | 147 | 13.4 | yes |
| computer_tray | 85.7 × 55.4 × 7 | 13 | 1.1 | yes |
| servo_bus_tray | 42.4 × 33.4 × 7 | 3 | 0.3 | yes |
| neck_base_link | 70 × 70 × 58.4 | 46 | 4.2 | yes |
| neck_upper_arm | 96.4 × 53.2 × 59.3 | 63 | 5.7 | yes |
| neck_turret | 30.8 × 44.1 × 57.4 | 19 | 1.7 | yes |
| neck_tool_link | 74 × 40 × 44.5 | 17 | 1.6 | yes |
| head | 126 × 84.4 × 128 | 370 | 33.7 | yes |
| left_arm_base_link | 60 × 60 × 58.4 | 39 | 3.5 | yes |
| left_arm_upper_arm | 109.7 × 30.8 × 62.3 | 36 | 3.3 | yes |
| left_arm_forearm | 166.5 × 49.6 × 60.3 | 82 | 7.5 | yes |
| left_arm_gripper_jaw | 84 × 39 × 8.5 | 10 | 0.9 | yes |
| left_arm_shoulder | 12 × 78 × 60 | 51 | 4.6 | yes |
| right_arm_base_link | 60 × 60 × 58.4 | 39 | 3.5 | yes |
| right_arm_upper_arm | 109.7 × 30.8 × 62.3 | 36 | 3.3 | yes |
| right_arm_forearm | 166.5 × 49.6 × 60.3 | 82 | 7.5 | yes |
| right_arm_gripper_jaw | 84 × 39 × 8.5 | 10 | 0.9 | yes |
| right_arm_shoulder | 12 × 78 × 60 | 51 | 4.6 | yes |
