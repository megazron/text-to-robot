# Print list — wall_e

8 parts, about 458 g of PETG and 41.8 h of printing.

Exact solids of these parts are in `cad/step/` (STEP AP214, millimetres): open them in Fusion, FreeCAD or Onshape to edit.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| body | 170 × 128 × 130 | 185 | 16.9 | yes |
| track_left | 201 × 27 × 71 | 30 | 2.7 | yes |
| track_right | 201 × 27 × 71 | 30 | 2.7 | yes |
| lid | 170 × 128 × 30.2 | 87 | 7.9 | yes |
| neck | 41 × 41 × 101.9 | 28 | 2.5 | yes |
| head | 83.5 × 50.5 × 88 | 82 | 7.5 | yes |
| left_arm | 41 × 104.5 × 4 | 9 | 0.8 | yes |
| right_arm | 41 × 104.5 × 4 | 9 | 0.8 | yes |
