# Build package: wall_e

Arduino WALL-E: TPU tracks on 4 TT motors, pan/tilt binocular head, two-joint arms with gripping hands, 1.14 kg, $98 of parts

1. **Buy** everything in `BOM.md` (supplier links included).
2. **Print** every STL in `print/` (see `print/PRINT_LIST.md`).
3. **Assemble** in the order of `ASSEMBLY.md`.
   **Wire** from `WIRING.md` (pin-to-pin table, cut list, power budget, battery runtime, regulator heat, logic levels), `schematic.svg` / `schematic.pdf` and the picture view `breadboard.svg`.
4. **Check** against `design.json`: each actuator's required vs rated torque, the speed it reaches loaded, battery runtime, stability and every other check the design passed.

`reference/` holds the bought parts' models (from their datasheet drawings) for your own CAD; `wall_e_assembly.stl` is the whole robot in its build pose.

## Assumptions

- Joint limits trimmed to the collision-free range found by exact solid sweeps: left_arm_lift [-1.00, 1.00] -> [-1.00, 0.48]; right_arm_lift [-1.00, 1.00] -> [-0.48, 1.00]; left_elbow [-1.50, 1.50] -> [-1.50, 1.27]; right_elbow [-1.50, 1.50] -> [-1.27, 1.50]; left_hand [-0.60, 0.60] -> [-0.01, 0.60]; right_hand [-0.60, 0.60] -> [-0.60, 0.01].
- tracks print in TPU 95A (flexible), everything else in PETG/PLA+; the body prints open side up without supports
- TT motor continuous torque taken as 30 % of the 0.8 kg.cm stall; a turn on the spot is a short transient above that (the tracks slide sideways), so spin in bursts on carpet or rubber floors
- prices are typical single-unit marketplace prices and vary by seller
