# Printability — wall_e

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 300 × 300 × 280 | ❌ |
| left_track | 380 × 80 × 120 | ❌ |
| left_front_wheel | 120 × 120 × 60 | ✅ |
| left_rear_wheel | 120 × 120 × 60 | ✅ |
| right_track | 380 × 80 × 120 | ❌ |
| right_front_wheel | 120 × 120 × 60 | ✅ |
| right_rear_wheel | 120 × 120 × 60 | ✅ |
| neck | 50 × 50 × 140 | ✅ |
| head | 100 × 200 × 80 | ✅ |
| left_eye | 70 × 70 × 60 | ✅ |
| right_eye | 70 × 70 × 60 | ✅ |
| left_shoulder | 40 × 40 × 50 | ✅ |
| left_upper_arm | 40 × 40 × 140 | ✅ |
| left_forearm | 40 × 40 × 140 | ✅ |
| left_gripper_base | 60 × 80 × 30 | ✅ |
| left_left_finger | 15 × 20 × 60 | ✅ |
| left_right_finger | 15 × 20 × 60 | ✅ |
| right_shoulder | 40 × 40 × 50 | ✅ |
| right_upper_arm | 40 × 40 × 140 | ✅ |
| right_forearm | 40 × 40 × 140 | ✅ |
| right_gripper_base | 60 × 80 × 30 | ✅ |
| right_left_finger | 15 × 20 × 60 | ✅ |
| right_right_finger | 15 × 20 × 60 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_track**: longest dimension 380 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_track**: longest dimension 380 mm exceeds the 220 mm build volume — split the part or print diagonally
