# Printability — wall_e

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 300 × 300 × 3 | ❌ |
| base_link_service_lid | 300 × 300 × 3 | ❌ |
| base_link_rear_panel | 3 × 300 × 274 | ❌ |
| base_link_right_panel | 294 × 3 × 274 | ❌ |
| base_link_front_panel | 3 × 300 × 274 | ❌ |
| base_link_left_panel | 294 × 3 × 274 | ❌ |
| base_link_standoff_rr | 8 × 8 × 274 | ❌ |
| base_link_standoff_rl | 8 × 8 × 274 | ❌ |
| base_link_standoff_fr | 8 × 8 × 274 | ❌ |
| base_link_standoff_fl | 8 × 8 × 274 | ❌ |
| left_track | 380 × 25 × 25 | ❌ |
| left_front_wheel | 120 × 120 × 60 | ✅ |
| left_rear_wheel | 120 × 120 × 60 | ✅ |
| right_track | 380 × 25 × 25 | ❌ |
| right_front_wheel | 120 × 120 × 60 | ✅ |
| right_rear_wheel | 120 × 120 × 60 | ✅ |
| neck | 50 × 50 × 140 | ✅ |
| head | 100 × 200 × 80 | ✅ |
| left_eye | 70 × 70 × 60 | ✅ |
| right_eye | 70 × 70 × 60 | ✅ |
| left_shoulder | 40 × 40 × 50 | ✅ |
| left_upper_arm | 40 × 40 × 140 | ✅ |
| left_forearm | 40 × 40 × 140 | ✅ |
| left_gripper_base | 60 × 80 × 30 | ✅ |
| left_left_finger | 15 × 20 × 60 | ✅ |
| left_right_finger | 15 × 20 × 60 | ✅ |
| left_left_finger_pad | 15 × 2 × 36 | ✅ |
| left_right_finger_pad | 15 × 2 × 36 | ✅ |
| right_shoulder | 40 × 40 × 50 | ✅ |
| right_upper_arm | 40 × 40 × 140 | ✅ |
| right_forearm | 40 × 40 × 140 | ✅ |
| right_gripper_base | 60 × 80 × 30 | ✅ |
| right_left_finger | 15 × 20 × 60 | ✅ |
| right_right_finger | 15 × 20 × 60 | ✅ |
| right_left_finger_pad | 15 × 2 × 36 | ✅ |
| right_right_finger_pad | 15 × 2 × 36 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_service_lid**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_rear_panel**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_right_panel**: longest dimension 294 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_front_panel**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_left_panel**: longest dimension 294 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_standoff_rr**: longest dimension 274 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_standoff_rl**: longest dimension 274 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_standoff_fr**: longest dimension 274 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_standoff_fl**: longest dimension 274 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_track**: longest dimension 380 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **right_track**: longest dimension 380 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **left_left_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **left_right_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_left_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
- ⚠️ **right_right_finger_pad**: thinnest dimension 2 mm is below 3 mm — fragile on FDM; thicken or print in resin/metal
