# Assembly: wall_e

Start from **body**.

1. Bolt **front_band** to **body**.
2. Bolt **charge_gauge** to **body**.
3. Bolt **name_plate** to **body**.
4. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (front_left_motor) in **body** with its case screws.
5. Fit **front_left_wheel** on the output of the motor in **body** (driven joint `front_left_wheel_joint`).
6. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (front_right_motor) in **body** with its case screws.
7. Fit **front_right_wheel** on the output of the motor in **body** (driven joint `front_right_wheel_joint`).
8. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (rear_left_motor) in **body** with its case screws.
9. Fit **rear_left_wheel** on the output of the motor in **body** (driven joint `rear_left_wheel_joint`).
10. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (rear_right_motor) in **body** with its case screws.
11. Fit **rear_right_wheel** on the output of the motor in **body** (driven joint `rear_right_wheel_joint`).
12. Bolt **track_left** to **body**.
13. Fit **left_idler** on the output of the motor in **body** (free-running joint `left_idler_joint`).
14. Bolt **track_right** to **body**.
15. Fit **right_idler** on the output of the motor in **body** (free-running joint `right_idler_joint`).
16. Mount the **HC-SR04 ultrasonic distance sensor (2-400 cm)** (ultrasonic) in **body** with its case screws.
17. Mount the **2S 18650 pack: two 2500 mAh 20 A cells (Samsung 25R class) in a plain two-cell holder** (battery) in **body** with its case screws.
18. Mount the **Half-size solderless breadboard, 400 points, adhesive back** (breadboard) in **body** with its case screws.
19. Mount the **Arduino Nano compatible board (ATmega328P, CH340, USB-C)** (controller) in **breadboard** with its case screws.
20. Mount the **TB6612FNG dual DC motor driver module (1.2 A per channel)** (motor_driver_1) in **breadboard** with its case screws.
21. Mount the **Half-size solderless breadboard, 400 points, adhesive back** (breadboard_2) in **body** with its case screws.
22. Mount the **TB6612FNG dual DC motor driver module (1.2 A per channel)** (motor_driver_2) in **breadboard_2** with its case screws.
23. Mount the **PCA9685 16-channel PWM servo driver board (generic, I2C)** (servo_driver) in **body** with its case screws.
24. Mount the **LM2596S adjustable buck module (3 A, 43 x 21 mm)** (servo_regulator) in **body** with its case screws.
25. Mount the **LM2596S adjustable buck module (3 A, 43 x 21 mm)** (arm_regulator) in **body** with its case screws.
26. Mount the **KCD1 rocker switch, SPST, 6 A 250 VAC / 10 A 125 VAC** (main_switch) in **body** with its case screws.
27. Bolt **lid** to **body**.
28. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (neck_pan_servo) in **lid** with its case screws.
29. Set joint `neck_pan` to zero (centre the servo first), then screw **neck** to the actuator output in **lid**; it moves -80° … 80°.
30. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (neck_tilt_servo) in **neck** with its case screws.
31. Set joint `neck_tilt` to zero (centre the servo first), then screw **head** to the actuator output in **neck**; it moves -40° … 40°.
32. Bolt **left_lens** to **head**.
33. Bolt **right_lens** to **head**.
34. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (left_arm_servo) in **body** with its case screws.
35. Set joint `left_arm_lift` to zero (centre the servo first), then screw **left_arm** to the actuator output in **body**; it moves -57° … 28°.
36. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (left_elbow_servo) in **left_arm** with its case screws.
37. Set joint `left_elbow` to zero (centre the servo first), then screw **left_forearm** to the actuator output in **left_arm**; it moves -86° … 72°.
38. Bolt **left_arm_stripes** to **left_forearm**.
39. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (left_hand_servo) in **left_forearm** with its case screws.
40. Set joint `left_hand` to zero (centre the servo first), then screw **left_thumb** to the actuator output in **left_forearm**; it moves -1° … 34°.
41. Mount the **TowerPro MG90S micro servo (metal gears) + cross horn** (right_arm_servo) in **body** with its case screws.
42. Set joint `right_arm_lift` to zero (centre the servo first), then screw **right_arm** to the actuator output in **body**; it moves -28° … 57°.
43. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (right_elbow_servo) in **right_arm** with its case screws.
44. Set joint `right_elbow` to zero (centre the servo first), then screw **right_forearm** to the actuator output in **right_arm**; it moves -72° … 86°.
45. Bolt **right_arm_stripes** to **right_forearm**.
46. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (right_hand_servo) in **right_forearm** with its case screws.
47. Set joint `right_hand` to zero (centre the servo first), then screw **right_thumb** to the actuator output in **right_forearm**; it moves -34° … 1°.

## Fasteners

- 8 × M3x25 socket head + nut (motor through-bolt)
- 2 × M4 x 45 shoulder bolt (idler pin)
- 4 × M2x6 self-tapping (sensor)
- 2 × M3x8 countersunk + nut (pack)
- 6 × M2.5x6 + nut (PCA9685) / M3x6 (LM2596)
- 4 × M3x10 self-tapping (lid)
- 16 × M2 self-tapping (servo tabs, from the servo kits)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
