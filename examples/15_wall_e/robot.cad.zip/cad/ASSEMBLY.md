# Assembly — wall_e

Start from **body**.

1. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (front_left_motor) in **body** with its case screws.
2. Fit **front_left_wheel** on the output of the motor in **body** (driven joint `front_left_wheel_joint`).
3. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (front_right_motor) in **body** with its case screws.
4. Fit **front_right_wheel** on the output of the motor in **body** (driven joint `front_right_wheel_joint`).
5. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (rear_left_motor) in **body** with its case screws.
6. Fit **rear_left_wheel** on the output of the motor in **body** (driven joint `rear_left_wheel_joint`).
7. Mount the **TT gear motor 3-6 V, 1:48, 200 rpm (yellow, double-D shaft)** (rear_right_motor) in **body** with its case screws.
8. Fit **rear_right_wheel** on the output of the motor in **body** (driven joint `rear_right_wheel_joint`).
9. Bolt **track_left** to **body**.
10. Bolt **track_right** to **body**.
11. Mount the **HC-SR04 ultrasonic distance sensor (2-400 cm)** (ultrasonic) in **body** with its case screws.
12. Mount the **2S 18650 pack: two 2500 mAh 20 A cells (Samsung 25R class) in a holder with switch** (battery) in **body** with its case screws.
13. Mount the **Half-size solderless breadboard, 400 points, adhesive back** (breadboard) in **body** with its case screws.
14. Mount the **Arduino Nano compatible board (ATmega328P, CH340, USB-C)** (controller) in **breadboard** with its case screws.
15. Mount the **TB6612FNG dual DC motor driver module (1.2 A per channel)** (motor_driver_1) in **breadboard** with its case screws.
16. Mount the **TB6612FNG dual DC motor driver module (1.2 A per channel)** (motor_driver_2) in **breadboard** with its case screws.
17. Mount the **PCA9685 16-channel PWM servo driver board (generic, I2C)** (servo_driver) in **body** with its case screws.
18. Mount the **LM2596S adjustable buck module (3 A, 43 x 21 mm)** (servo_regulator) in **body** with its case screws.
19. Bolt **lid** to **body**.
20. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (neck_pan_servo) in **lid** with its case screws.
21. Set joint `neck_pan` to zero (centre the servo first), then screw **neck** to the actuator output in **lid**; it moves -80° … 80°.
22. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (neck_tilt_servo) in **neck** with its case screws.
23. Set joint `neck_tilt` to zero (centre the servo first), then screw **head** to the actuator output in **neck**; it moves -40° … 40°.
24. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (left_arm_servo) in **body** with its case screws.
25. Set joint `left_arm_lift` to zero (centre the servo first), then screw **left_arm** to the actuator output in **body**; it moves -57° … 20°.
26. Mount the **TowerPro SG90 micro servo (nylon gears) + cross horn** (right_arm_servo) in **body** with its case screws.
27. Set joint `right_arm_lift` to zero (centre the servo first), then screw **right_arm** to the actuator output in **body**; it moves -20° … 57°.

## Fasteners

- 8 × M3x25 socket head + nut (motor through-bolt)
- 4 × M2x6 self-tapping (sensor)
- 2 × M3x8 countersunk + nut (pack)
- 6 × M2.5x6 + nut (PCA9685) / M3x6 (LM2596)
- 4 × M3x10 self-tapping (lid)
- 8 × M2 self-tapping (servo tabs, from the servo kits)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
