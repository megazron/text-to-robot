# Assembly — wall_e

Start from **base_link**.

1. Fit **left_front_wheel** on the output of the motor in **base_link** (free-running joint `left_front_wheel_joint`).
2. Mount the **Pololu 70:1 Metal Gearmotor 37Dx70L 12 V with 64 CPR encoder (#4754)** (left_middle_motor) in **base_link** with its case screws.
3. Fit **left_middle_wheel** on the output of the motor in **base_link** (driven joint `left_middle_wheel_joint`).
4. Fit **left_rear_wheel** on the output of the motor in **base_link** (free-running joint `left_rear_wheel_joint`).
5. Bolt **left_track_frame** to **base_link**.
6. Fit **right_front_wheel** on the output of the motor in **base_link** (free-running joint `right_front_wheel_joint`).
7. Mount the **Pololu 70:1 Metal Gearmotor 37Dx70L 12 V with 64 CPR encoder (#4754)** (right_middle_motor) in **base_link** with its case screws.
8. Fit **right_middle_wheel** on the output of the motor in **base_link** (driven joint `right_middle_wheel_joint`).
9. Fit **right_rear_wheel** on the output of the motor in **base_link** (free-running joint `right_rear_wheel_joint`).
10. Bolt **right_track_frame** to **base_link**.
11. Bolt **body_left** to **base_link**.
12. Bolt **left_arm_base_link** to **body_left**.
13. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (left_arm_shoulder_pitch_actuator) in **left_arm_base_link** with its case screws.
14. Set joint `left_arm_shoulder_pitch` to zero (centre the servo first), then screw **left_arm_upper_arm** to the actuator output in **left_arm_base_link**; it moves -100° … 100°.
15. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (left_arm_elbow_pitch_actuator) in **left_arm_upper_arm** with its case screws.
16. Set joint `left_arm_elbow_pitch` to zero (centre the servo first), then screw **left_arm_forearm** to the actuator output in **left_arm_upper_arm**; it moves -132° … 132°.
17. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (left_arm_gripper_actuator) in **left_arm_forearm** with its case screws.
18. Set joint `left_arm_gripper` to zero (centre the servo first), then screw **left_arm_gripper_jaw** to the actuator output in **left_arm_forearm**; it moves -20° … 27°.
19. Bolt **left_arm_shoulder** to **body_left**.
20. Bolt **body_right** to **base_link**.
21. Bolt **right_arm_base_link** to **body_right**.
22. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (right_arm_shoulder_pitch_actuator) in **right_arm_base_link** with its case screws.
23. Set joint `right_arm_shoulder_pitch` to zero (centre the servo first), then screw **right_arm_upper_arm** to the actuator output in **right_arm_base_link**; it moves -100° … 100°.
24. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (right_arm_elbow_pitch_actuator) in **right_arm_upper_arm** with its case screws.
25. Set joint `right_arm_elbow_pitch` to zero (centre the servo first), then screw **right_arm_forearm** to the actuator output in **right_arm_upper_arm**; it moves -132° … 132°.
26. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (right_arm_gripper_actuator) in **right_arm_forearm** with its case screws.
27. Set joint `right_arm_gripper` to zero (centre the servo first), then screw **right_arm_gripper_jaw** to the actuator output in **right_arm_forearm**; it moves -20° … 27°.
28. Bolt **right_arm_shoulder** to **body_right**.
29. Bolt **body_back** to **base_link**.
30. Bolt **body_front** to **base_link**.
31. Bolt **body_top** to **base_link**.
32. Bolt **neck_base_link** to **body_top**.
33. Mount the **Feetech STS3250 C002 12 V 50 kg.cm (1:345)** (neck_shoulder_pitch_actuator) in **neck_base_link** with its case screws.
34. Set joint `neck_shoulder_pitch` to zero (centre the servo first), then screw **neck_upper_arm** to the actuator output in **neck_base_link**; it moves -26° … 17°.
35. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (neck_base_yaw_actuator) in **neck_upper_arm** with its case screws.
36. Set joint `neck_base_yaw` to zero (centre the servo first), then screw **neck_turret** to the actuator output in **neck_upper_arm**; it moves -170° … 170°.
37. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (neck_elbow_pitch_actuator) in **neck_turret** with its case screws.
38. Set joint `neck_elbow_pitch` to zero (centre the servo first), then screw **neck_tool_link** to the actuator output in **neck_turret**; it moves -132° … 132°.
39. Bolt **head** to **neck_tool_link**.
40. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (left_eye_camera) in **head** with its case screws.
41. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (right_eye_camera) in **head** with its case screws.
42. Mount the **LiPo 3S 2200 mAh 25C, XT60 (Gens Ace G-Tech)** (battery) in **base_link** with its case screws.
43. Bolt **battery_tray** to **base_link**.
44. Mount the **Cytron MDD10A dual-channel 10 A DC motor driver (5-30 V)** (motor_driver_1) in **base_link** with its case screws.
45. Bolt **motor_driver_1_tray** to **base_link**.
46. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **base_link** with its case screws.
47. Bolt **regulator_5v_tray** to **base_link**.
48. Bolt **shelf** to **base_link**.
49. Mount the **Raspberry Pi 5 (4 GB)** (computer) in **base_link** with its case screws.
50. Bolt **computer_tray** to **base_link**.
51. Mount the **Waveshare Bus Servo Adapter (A)** (servo_bus) in **base_link** with its case screws.
52. Bolt **servo_bus_tray** to **base_link**.

## Fasteners

- 4 × M5 x 30 shoulder bolt (idler axle)
- 12 × M3 x 8 socket head (motor face)
- 24 × M3 x 10 + printed corner cleats (body panels)
- 1 × 20 mm hook-and-loop battery strap
- 10 × M3 x 8 socket head (tray to deck)
- 15 × M2.5 x 6 screws (board to standoffs)
- 4 × M3 x 10 + printed cleats (shelf to side panels)
- 12 × M5 x 12 socket head (base to bench)
- 28 × M2 x 6 case screws
- 36 × horn screws
- 6 × M5 x 16 socket head + M5 washer + M5 heat-set insert (clevis bearing axle)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
