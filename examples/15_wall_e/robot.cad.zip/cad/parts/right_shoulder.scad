// concept part: right_shoulder (shoulder)
// units: mm. Mesh with: openscad -o right_shoulder.stl right_shoulder.scad
multmatrix([[0, 0, 1, 25], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=50, r=20, center=true, $fn=48);
