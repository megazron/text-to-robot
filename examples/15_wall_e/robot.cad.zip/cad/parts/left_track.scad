// concept part: left_track (wheel)
// units: mm. Mesh with: openscad -o left_track.stl left_track.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 140], [0, 0, 0, 1]])
  cube([380, 25, 25], center=true);
