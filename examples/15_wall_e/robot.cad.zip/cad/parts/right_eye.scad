// concept part: right_eye (sensor)
// units: mm. Mesh with: openscad -o right_eye.stl right_eye.scad
multmatrix([[0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=60, r=35, center=true, $fn=48);
