// concept part: left_eye (sensor)
// units: mm. Mesh with: openscad -o left_eye.stl left_eye.scad
multmatrix([[0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=60, r=35, center=true, $fn=48);
