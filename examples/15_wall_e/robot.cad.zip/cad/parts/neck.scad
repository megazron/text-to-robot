// concept part: neck (link)
// units: mm. Mesh with: openscad -o neck.stl neck.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 70], [0, 0, 0, 1]])
  cylinder(h=140, r=25, center=true, $fn=48);
