// concept part: head (link)
// units: mm. Mesh with: openscad -o head.stl head.scad
multmatrix([[1, 0, 0, 30], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  cube([100, 200, 80], center=true);
