// concept part: left_front_wheel (wheel)
// units: mm. Mesh with: openscad -o left_front_wheel.stl left_front_wheel.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=60, r=60, center=true, $fn=48);
