// concept part: left_rear_wheel (wheel)
// units: mm. Mesh with: openscad -o left_rear_wheel.stl left_rear_wheel.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=60, r=60, center=true, $fn=48);
