// concept part: right_track (wheel)
// units: mm. Mesh with: openscad -o right_track.stl right_track.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 60], [0, 0, 0, 1]])
  cube([380, 80, 120], center=true);
