// concept part: left_upper_arm (upper_arm)
// units: mm. Mesh with: openscad -o left_upper_arm.stl left_upper_arm.scad
multmatrix([[0, 0, 1, 70], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=140, r=20, center=true, $fn=48);
