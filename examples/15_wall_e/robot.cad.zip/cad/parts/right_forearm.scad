// concept part: right_forearm (forearm)
// units: mm. Mesh with: openscad -o right_forearm.stl right_forearm.scad
multmatrix([[0, 0, 1, 70], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]])
  cylinder(h=140, r=20, center=true, $fn=48);
