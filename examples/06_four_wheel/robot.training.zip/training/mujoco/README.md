# four_wheel_robot in MuJoCo

Test, render and train this exact robot in MuJoCo with the text-to-robot Python layer:

```bash
pip install -r requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cpu    # CPU torch on GPU-less machines

python -m ttr_mujoco test   ../four_wheel_robot.urdf --self-collision                       # settle / hold / actuator sweep / disturbance
python -m ttr_mujoco render ../four_wheel_robot.urdf -o four_wheel_robot.gif --motion sweep
python -m ttr_mujoco train  ../four_wheel_robot.urdf --self-collision --task stand --steps 400000
```

Or from Python:

```python
from ttr_mujoco import urdf_to_mjcf, run_tests, render_gif
from ttr_mujoco.env import MujocoRobotEnv
report = run_tests("../four_wheel_robot.urdf")              # dict with per-test pass/fail + metrics
env = MujocoRobotEnv("../four_wheel_robot.urdf", task="stand")
```
