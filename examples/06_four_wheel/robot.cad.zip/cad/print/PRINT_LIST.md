# Print list: four_wheel_robot

16 parts, about 375 g of PETG and 34.2 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| front_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| battery_tray | 125.6 × 40.7 × 16.2 | 18 | 1.7 | yes |
| computer_tray | 90 × 59.2 × 7 | 15 | 1.4 | yes |
| motor_driver_1_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| motor_driver_2_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| imu_tray | 27.6 × 24.7 × 7 | 2 | 0.2 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| electronics_enclosure_front | 172 × 191 × 45.1 | 46 | 4.2 | yes |
| electronics_enclosure_rear | 172 × 191 × 45.1 | 60 | 5.4 | yes |
| electronics_lid_front | 159 × 172.9 × 5.4 | 45 | 4.1 | yes |
| electronics_lid_rear | 159 × 180.8 × 5.4 | 37 | 3.4 | yes |
| lidar_mast | 62 × 62 × 24.7 | 41 | 3.7 | yes |
| front_camera_bracket | 15.3 × 36 × 45 | 16 | 1.5 | yes |
