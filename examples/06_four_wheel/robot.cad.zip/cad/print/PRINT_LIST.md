# Print list — four_wheel_robot

16 parts, about 306 g of PETG and 27.9 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| front_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| battery_tray | 110.6 × 40.7 × 16.2 | 17 | 1.5 | yes |
| computer_tray | 85.7 × 55.4 × 7 | 13 | 1.1 | yes |
| motor_driver_1_tray | 84.4 × 61.4 × 7 | 13 | 1.2 | yes |
| motor_driver_2_tray | 84.4 × 61.4 × 7 | 13 | 1.2 | yes |
| imu_tray | 26.9 × 24 × 7 | 2 | 0.1 | yes |
| regulator_5v_tray | 26.7 × 26.7 × 7 | 2 | 0.1 | yes |
| electronics_enclosure_front | 157.7 × 189.7 × 33 | 27 | 2.4 | yes |
| electronics_enclosure_rear | 157.7 × 189.7 × 33 | 24 | 2.2 | yes |
| electronics_lid_front | 144.7 × 163.7 × 5.4 | 50 | 4.5 | yes |
| electronics_lid_rear | 144.7 × 163.7 × 5.4 | 41 | 3.7 | yes |
| lidar_mast | 62 × 62 × 12.6 | 30 | 2.7 | yes |
| front_camera_bracket | 15.3 × 32 × 45 | 14 | 1.2 | yes |
