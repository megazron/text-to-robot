# Print list — four_wheel_robot

21 parts, about 539 g of PETG and 49.1 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| front_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| rear_right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| battery_tray | 110.6 × 40.7 × 16.2 | 17 | 1.5 | yes |
| motor_driver_1_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| motor_driver_2_tray | 87 × 64 × 7 | 16 | 1.4 | yes |
| power_bay | 222.8 × 156.3 × 33 | 54 | 4.9 | yes |
| power_bay_lid | 196.8 × 146.1 × 5.4 | 46 | 4.2 | yes |
| upper_deck | 236 × 188 × 4 | 161 | 14.7 | yes |
| pillar_1 | 14 × 14 × 50 | 7 | 0.6 | yes |
| pillar_2 | 14 × 14 × 50 | 7 | 0.6 | yes |
| pillar_3 | 14 × 14 × 50 | 7 | 0.6 | yes |
| pillar_4 | 14 × 14 × 50 | 7 | 0.6 | yes |
| computer_tray | 90 × 59.2 × 7 | 15 | 1.4 | yes |
| imu_tray | 27.6 × 24.7 × 7 | 2 | 0.2 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| electronics_enclosure | 196.8 × 138.4 × 32.6 | 43 | 3.9 | yes |
| electronics_lid | 183.8 × 128.2 × 5.4 | 33 | 3.0 | yes |
| lidar_mast | 62 × 62 × 12.2 | 29 | 2.7 | yes |
| front_camera_bracket | 15.3 × 36 × 45 | 16 | 1.5 | yes |
