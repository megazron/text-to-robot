// concept part: front_left_wheel (wheel)
// units: mm. Mesh with: openscad -o front_left_wheel.stl front_left_wheel.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=40, r=60, center=true, $fn=48);
