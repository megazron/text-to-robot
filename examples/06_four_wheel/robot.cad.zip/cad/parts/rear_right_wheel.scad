// concept part: rear_right_wheel (wheel)
// units: mm. Mesh with: openscad -o rear_right_wheel.stl rear_right_wheel.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=40, r=60, center=true, $fn=48);
