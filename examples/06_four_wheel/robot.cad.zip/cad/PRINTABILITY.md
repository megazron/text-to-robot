# Printability — four_wheel_robot

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 400 × 300 × 3 | ❌ |
| base_link_service_lid | 400 × 300 × 3 | ❌ |
| base_link_rear_panel | 3 × 300 × 114 | ❌ |
| base_link_right_panel | 394 × 3 × 114 | ❌ |
| base_link_front_panel | 3 × 300 × 114 | ❌ |
| base_link_left_panel | 394 × 3 × 114 | ❌ |
| base_link_standoff_rr | 8 × 8 × 114 | ✅ |
| base_link_standoff_rl | 8 × 8 × 114 | ✅ |
| base_link_standoff_fr | 8 × 8 × 114 | ✅ |
| base_link_standoff_fl | 8 × 8 × 114 | ✅ |
| front_left_wheel | 120 × 120 × 40 | ✅ |
| front_right_wheel | 120 × 120 × 40 | ✅ |
| rear_left_wheel | 120 × 120 × 40 | ✅ |
| rear_right_wheel | 120 × 120 × 40 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_service_lid**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_rear_panel**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_right_panel**: longest dimension 394 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_front_panel**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_left_panel**: longest dimension 394 mm exceeds the 220 mm build volume — split the part or print diagonally
