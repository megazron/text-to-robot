# Assembly: four_wheel_robot

Start from **base_link**.

1. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (front_left_motor) in **base_link** with its case screws.
2. Fit **front_left_wheel** on the output of the motor in **base_link** (driven joint `front_left_wheel_joint`).
3. Bolt **front_left_bracket** to **base_link**.
4. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (front_right_motor) in **base_link** with its case screws.
5. Fit **front_right_wheel** on the output of the motor in **base_link** (driven joint `front_right_wheel_joint`).
6. Bolt **front_right_bracket** to **base_link**.
7. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (rear_left_motor) in **base_link** with its case screws.
8. Fit **rear_left_wheel** on the output of the motor in **base_link** (driven joint `rear_left_wheel_joint`).
9. Bolt **rear_left_bracket** to **base_link**.
10. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (rear_right_motor) in **base_link** with its case screws.
11. Fit **rear_right_wheel** on the output of the motor in **base_link** (driven joint `rear_right_wheel_joint`).
12. Bolt **rear_right_bracket** to **base_link**.
13. Mount the **LiPo 3S 2200 mAh 25C, XT60 (Gens Ace G-Tech)** (battery) in **base_link** with its case screws.
14. Bolt **battery_tray** to **base_link**.
15. Mount the **Cytron MDD10A dual-channel 10 A DC motor driver (5-30 V)** (motor_driver_1) in **base_link** with its case screws.
16. Bolt **motor_driver_1_tray** to **base_link**.
17. Mount the **Cytron MDD10A dual-channel 10 A DC motor driver (5-30 V)** (motor_driver_2) in **base_link** with its case screws.
18. Bolt **motor_driver_2_tray** to **base_link**.
19. Bolt **power_bay** to **base_link**.
20. Bolt **power_bay_lid** to **base_link**.
21. Bolt **upper_deck** to **base_link**.
22. Mount the **Raspberry Pi 5 (4 GB)** (computer) in **upper_deck** with its case screws.
23. Bolt **computer_tray** to **upper_deck**.
24. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **upper_deck** with its case screws.
25. Bolt **imu_tray** to **upper_deck**.
26. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **upper_deck** with its case screws.
27. Bolt **regulator_5v_tray** to **upper_deck**.
28. Mount the **KCD4 double-pole rocker switch, 16 A 250 VAC / 20 A 125 VAC** (main_switch) in **upper_deck** with its case screws.
29. Bolt **electronics_enclosure** to **upper_deck**.
30. Bolt **electronics_lid** to **upper_deck**.
31. Bolt **lidar_mast** to **upper_deck**.
32. Mount the **Slamtec RPLIDAR C1 (DTOF 360 deg, 12 m)** (lidar) in **upper_deck** with its case screws.
33. Bolt **pillar_1** to **base_link**.
34. Bolt **pillar_2** to **base_link**.
35. Bolt **pillar_3** to **base_link**.
36. Bolt **pillar_4** to **base_link**.
37. Mount the **Raspberry Pi Camera Module 3 (standard lens)** (front_camera) in **base_link** with its case screws.
38. Bolt **front_camera_bracket** to **base_link**.

## Fasteners

- 24 × M3 x 8 socket head (motor face)
- 8 × M3 x 10 socket head + nut (bracket to deck)
- 1 × 20 mm hook-and-loop battery strap
- 12 × M3 x 8 socket head (tray to deck)
- 19 × M2.5 x 6 screws (board to standoffs)
- 8 × M3 x 10 self-tapping (enclosure lid)
- 8 × M3 x 8 + nut (enclosure tabs to deck; drill 3.4 mm through the deck at the tabs)
- 8 × M3 x 10 (pillars)
- 4 × M2.5 x 6 (lidar)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
