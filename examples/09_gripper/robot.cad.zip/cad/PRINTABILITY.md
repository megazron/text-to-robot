# Printability — parallel_gripper

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 120 × 120 × 120 | ✅ |
| gripper_base | 60 × 80 × 30 | ✅ |
| left_finger | 15 × 20 × 60 | ✅ |
| right_finger | 15 × 20 × 60 | ✅ |

## Notes
- ℹ️ *****: all parts fit the build volume with no thin features
