# Assembly — parallel_gripper

Start from **base_link**.

1. Bolt **gripper_body** to **base_link**.
2. Mount the **Feetech STS3215 C047 12 V 30 kg.cm (1:345)** (gripper_servo) in **gripper_body** with its case screws.
3. Set joint `gripper_pinion` to zero (centre the servo first), then screw **pinion** to the actuator output in **gripper_body**; it moves 0° … 164°.
4. Set joint `finger_a` to zero (centre the servo first), then screw **finger_a** to the actuator output in **gripper_body**; it moves 0° … 2°.
5. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (finger_a_bushing_lower) in **finger_a** with its case screws.
6. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (finger_a_bushing_upper) in **finger_a** with its case screws.
7. Set joint `finger_b` to zero (centre the servo first), then screw **finger_b** to the actuator output in **gripper_body**; it moves 0° … 2°.
8. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (finger_b_bushing_lower) in **finger_b** with its case screws.
9. Mount the **Linear ball bushing LM8UU (8 x 15 x 24 mm)** (finger_b_bushing_upper) in **finger_b** with its case screws.
10. Mount the **Hardened chromed linear rod 8 mm h6, 130 mm** (gripper_rod_lower) in **gripper_body** with its case screws.
11. Mount the **Hardened chromed linear rod 8 mm h6, 130 mm** (gripper_rod_upper) in **gripper_body** with its case screws.
12. Bolt **control_case** to **base_link**.
13. Bolt **control_case_lid** to **control_case**.
14. Mount the **Mean Well LRS-75-12 enclosed PSU, 12 V 6 A (75 W)** (power_supply) in **control_case** with its case screws.
15. Mount the **Waveshare Bus Servo Adapter (A)** (servo_bus) in **control_case** with its case screws.
16. Mount the **IEC C14 panel inlet with fuse drawer and rocker switch, 10 A** (mains_inlet) in **control_case** with its case screws.

## Fasteners

- 4 × M6 x 16 socket head (adapter to robot flange)
- 4 × M4 x 10 socket head + M4 heat-set insert (housing to adapter, radial)
- 4 × M3 x 6 set screw (rod retention)
- 4 × servo case screws (M2 x 6)
- 4 × horn screws
- 4 × M3 x 10 self-tapping (lid to compartment)
- 2 × M3 x 6 self-tapping (Mean Well LRS-75-12 enclosed PSU, 12 V 6 A to standoffs)
- 4 × M2 x 6 self-tapping (Waveshare Bus Servo Adapter to standoffs)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
