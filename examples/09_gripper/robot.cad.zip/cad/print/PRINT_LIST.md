# Print list: parallel_gripper

7 parts, about 582 g of PETG and 53.1 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 63 × 63 × 10 | 22 | 2.0 | yes |
| gripper_body | 142 × 72 × 144.6 | 239 | 21.8 | yes |
| pinion | 28 × 28 × 12 | 4 | 0.4 | yes |
| finger_a | 68 × 36.8 × 128 | 71 | 6.4 | yes |
| finger_b | 68 × 36.8 × 128 | 71 | 6.4 | yes |
| control_case | 204.7 × 154.7 × 44.4 | 125 | 11.4 | yes |
| control_case_lid | 204.7 × 154.7 × 5.8 | 51 | 4.6 | yes |
