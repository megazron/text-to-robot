# Print list: parallel_gripper

7 parts, about 530 g of PETG and 48.3 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 63 × 63 × 10 | 22 | 2.0 | yes |
| gripper_body | 142 × 72 × 138.6 | 225 | 20.5 | yes |
| pinion | 28 × 28 × 12 | 4 | 0.4 | yes |
| finger_a | 68 × 36.8 × 128 | 71 | 6.4 | yes |
| finger_b | 68 × 36.8 × 128 | 71 | 6.4 | yes |
| control_case | 151.7 × 154.7 × 44.4 | 100 | 9.1 | yes |
| control_case_lid | 151.7 × 154.7 × 5.8 | 38 | 3.5 | yes |
