"""Task catalogue (auto-generated). Each task returns (reward, terminated)."""
import numpy as np
import pybullet as p

def aperture(self, action):
    travel = sum(self.p.getJointState(self.robot,j)[0] for j in self.joints)
    error = abs(travel - float(self.target[0]))
    reward = -error - 0.001 * float(np.square(action).sum())
    terminated = error < 0.002
    return float(reward), bool(terminated)

TASKS = {
    "aperture": ("Control additional finger opening from home", aperture),
}
DEFAULT_TASK = "aperture"
