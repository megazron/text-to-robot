# Train parallel_gripper

Auto-generated training suite. Robot class: **gripper**. Physics: PyBullet (loads the URDF directly with a motor per joint). No ROS required.

```bash
cd training
pip install -r requirements.txt
```

## Tasks available
  - `aperture` — Control additional finger opening from home

## MuJoCo (recommended)
See `mujoco/README.md` — the same URDF converted to an actuated MuJoCo scene, with a test battery, renderer and PPO trainer.

## Reinforcement learning in PyBullet (PPO / SAC)
```bash
python train_rl.py --task aperture --algo ppo --steps 200000
python train_rl.py --task aperture --play          # watch it
```

## Imitation learning (behaviour cloning)
```bash
python collect_demos.py --task aperture --episodes 50   # scripted expert -> demos.npz
python train_bc.py --epochs 50                                     # clone the expert
```

## Evaluate
```bash
python evaluate.py --task aperture --rl parallel_gripper_ppo_aperture
python evaluate.py --task aperture --bc bc_parallel_gripper.pt
```

Add your own task by dropping a reward function into `tasks.py`; it is picked up automatically.
Classical motion planning is available via the exported ROS 2 / MoveIt 2 package.
