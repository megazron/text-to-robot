# Gazebo — parallel_gripper

```bash
sudo apt install ros-${ROS_DISTRO}-ros-gz
ros2 launch parallel_gripper gazebo.launch.py
```

Spawns the robot from `robot_description` into `worlds/parallel_gripper.sdf` (ground plane + sun) with a /clock bridge.
Add `gz_ros2_control` to drive the joints from ros2_control.
