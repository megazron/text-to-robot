"""Evaluate a trained policy (RL .zip or BC .pt) and report success rate.

    python evaluate.py --task reach --rl diff_drive_robot_ppo_reach
    python evaluate.py --task reach --bc bc_diff_drive_robot.pt
"""
import argparse
import numpy as np
import gymnasium as gym
import torch
import robot_env, tasks as T


def main(task, rl, bc, episodes):
    env = gym.make(f"DiffDriveRobot-{task}-v0")
    policy = None
    if rl:
        from stable_baselines3 import PPO, SAC
        policy = (SAC if "sac" in rl else PPO).load(rl)
        act = lambda o: policy.predict(o, deterministic=True)[0]
    elif bc:
        from train_bc import Policy
        obs_dim = env.observation_space.shape[0]; act_dim = env.action_space.shape[0]
        net = Policy(obs_dim, act_dim); net.load_state_dict(torch.load(bc)); net.eval()
        act = lambda o: net(torch.tensor(o, dtype=torch.float32)).detach().numpy()
    else:
        act = lambda o: env.action_space.sample()
    succ, rets = 0, []
    for _ in range(episodes):
        obs, _ = env.reset(); total = 0.0; done = False
        while not done:
            obs, r, term, trunc, info = env.step(act(obs)); total += r; done = term or trunc
            if info.get("is_success", False): succ += 1
        rets.append(total)
    print(f"episodes={episodes} success={succ}/{episodes} mean_return={np.mean(rets):.2f}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", default=T.DEFAULT_TASK)
    ap.add_argument("--rl"); ap.add_argument("--bc"); ap.add_argument("--episodes", type=int, default=20)
    a = ap.parse_args(); main(a.task, a.rl, a.bc, a.episodes)
