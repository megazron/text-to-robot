# Printability — diff_drive_robot

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 400 × 300 × 120 | ❌ |
| left_wheel | 120 × 120 × 40 | ✅ |
| right_wheel | 120 × 120 × 40 | ✅ |
| caster | 72 × 72 × 72 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **caster**: sphere needs supports or a flat-cut base to print
