# Printability — diff_drive_robot

Build volume assumed: 220 mm cube (typical desktop FDM).

| Part | Bounding box (mm) | Fits |
|---|---|:-:|
| base_link | 400 × 300 × 3 | ❌ |
| base_link_service_lid | 400 × 300 × 3 | ❌ |
| base_link_rear_panel | 3 × 300 × 114 | ❌ |
| base_link_right_panel | 394 × 3 × 114 | ❌ |
| base_link_front_panel | 3 × 300 × 114 | ❌ |
| base_link_left_panel | 394 × 3 × 114 | ❌ |
| base_link_standoff_rr | 8 × 8 × 114 | ✅ |
| base_link_standoff_rl | 8 × 8 × 114 | ✅ |
| base_link_standoff_fr | 8 × 8 × 114 | ✅ |
| base_link_standoff_fl | 8 × 8 × 114 | ✅ |
| left_wheel | 120 × 120 × 40 | ✅ |
| right_wheel | 120 × 120 × 40 | ✅ |
| caster | 72 × 72 × 72 | ✅ |
| rear_caster | 72 × 72 × 72 | ✅ |

## Notes
- ⚠️ **base_link**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_service_lid**: longest dimension 400 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_rear_panel**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_right_panel**: longest dimension 394 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_front_panel**: longest dimension 300 mm exceeds the 220 mm build volume — split the part or print diagonally
- ⚠️ **base_link_left_panel**: longest dimension 394 mm exceeds the 220 mm build volume — split the part or print diagonally
- ℹ️ **caster**: sphere needs supports or a flat-cut base to print
- ℹ️ **rear_caster**: sphere needs supports or a flat-cut base to print
