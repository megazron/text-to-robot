// concept part: rear_caster (support)
// units: mm. Mesh with: openscad -o rear_caster.stl rear_caster.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  sphere(r=36, $fn=48);
