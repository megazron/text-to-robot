// concept part: front_caster_fork (support)
// units: mm. Mesh with: openscad -o front_caster_fork.stl front_caster_fork.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, -20], [0, 0, 0, 1]])
  cylinder(h=40, r=8, center=true, $fn=48);
