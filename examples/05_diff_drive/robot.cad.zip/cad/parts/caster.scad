// concept part: caster (wheel)
// units: mm. Mesh with: openscad -o caster.stl caster.scad
multmatrix([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
  sphere(r=36, $fn=48);
