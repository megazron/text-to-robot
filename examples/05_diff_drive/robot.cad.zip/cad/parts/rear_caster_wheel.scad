// concept part: rear_caster_wheel (support)
// units: mm. Mesh with: openscad -o rear_caster_wheel.stl rear_caster_wheel.scad
multmatrix([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
  cylinder(h=18, r=30, center=true, $fn=48);
