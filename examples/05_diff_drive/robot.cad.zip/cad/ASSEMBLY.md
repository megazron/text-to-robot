# Assembly — diff_drive_robot

Start from **base_link**.

1. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (left_motor) in **base_link** with its case screws.
2. Fit **left_wheel** on the output of the motor in **base_link** (driven joint `left_wheel_joint`).
3. Bolt **left_bracket** to **base_link**.
4. Mount the **Pololu 30:1 Metal Gearmotor 37Dx68L 12 V with 64 CPR encoder (#4752)** (right_motor) in **base_link** with its case screws.
5. Fit **right_wheel** on the output of the motor in **base_link** (driven joint `right_wheel_joint`).
6. Bolt **right_bracket** to **base_link**.
7. Bolt **front_caster_post** to **base_link**.
8. Mount the **Pololu ball caster, 1" POM ball on ball bearings (#2692)** (front_caster) in **base_link** with its case screws.
9. Fit **front_caster_gimbal** on the output of the motor in **base_link** (free-running joint `front_caster_roll`).
10. Fit **front_caster_ball** on the output of the motor in **front_caster_gimbal** (free-running joint `front_caster_spin`).
11. Bolt **rear_caster_post** to **base_link**.
12. Mount the **Pololu ball caster, 1" POM ball on ball bearings (#2692)** (rear_caster) in **base_link** with its case screws.
13. Fit **rear_caster_gimbal** on the output of the motor in **base_link** (free-running joint `rear_caster_roll`).
14. Fit **rear_caster_ball** on the output of the motor in **rear_caster_gimbal** (free-running joint `rear_caster_spin`).
15. Mount the **Raspberry Pi 5 (4 GB)** (computer) in **base_link** with its case screws.
16. Bolt **computer_tray** to **base_link**.
17. Mount the **Cytron MDD10A dual-channel 10 A DC motor driver (5-30 V)** (motor_driver_1) in **base_link** with its case screws.
18. Bolt **motor_driver_1_tray** to **base_link**.
19. Mount the **LiPo 3S 2200 mAh 25C, XT60 (Gens Ace G-Tech)** (battery) in **base_link** with its case screws.
20. Bolt **battery_tray** to **base_link**.
21. Mount the **Pololu D36V50F5 5 V 5.5 A step-down regulator (#4091)** (regulator_5v) in **base_link** with its case screws.
22. Bolt **regulator_5v_tray** to **base_link**.
23. Mount the **Adafruit BNO085 9-DoF IMU breakout (STEMMA QT, #4754)** (imu) in **base_link** with its case screws.
24. Bolt **imu_tray** to **base_link**.
25. Bolt **electronics_enclosure** to **base_link**.
26. Bolt **electronics_lid** to **base_link**.
27. Bolt **lidar_mast** to **base_link**.
28. Mount the **Slamtec RPLIDAR C1 (DTOF 360 deg, 12 m)** (lidar) in **base_link** with its case screws.

## Fasteners

- 12 × M3 x 8 socket head (motor face)
- 4 × M3 x 10 socket head + nut (bracket to deck)
- 6 × M3 x 6 socket head (caster)
- 15 × M2.5 x 6 screws (board to standoffs)
- 10 × M3 x 8 socket head (tray to deck)
- 1 × 20 mm hook-and-loop battery strap
- 4 × M3 x 10 self-tapping (enclosure lid)
- 4 × M3 x 8 + nut (enclosure tabs to deck; drill 3.4 mm through the deck at the tabs)
- 4 × M2.5 x 6 (lidar)

## Before powering up

- Set every serial-bus servo to a unique ID and centre it before fitting its horn.
- Check each joint's range by hand against the limits above; the design's limits keep links clear of each other.
