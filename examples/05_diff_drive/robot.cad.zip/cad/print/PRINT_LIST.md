# Print list — diff_drive_robot

15 parts, about 574 g of PETG and 52.4 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 244 × 200 × 6 | 249 | 22.7 | yes |
| left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| rear_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| computer_tray | 59.2 × 90 × 7 | 15 | 1.4 | yes |
| motor_driver_1_tray | 64 × 87 × 7 | 16 | 1.4 | yes |
| battery_tray | 110.6 × 40.7 × 16.2 | 17 | 1.5 | yes |
| regulator_5v_tray | 27.4 × 27.4 × 7 | 2 | 0.2 | yes |
| imu_tray | 24.7 × 27.6 × 7 | 2 | 0.2 | yes |
| electronics_enclosure_front | 127.4 × 204.3 × 33 | 30 | 2.7 | yes |
| electronics_enclosure_rear | 127.4 × 204.3 × 33 | 37 | 3.4 | yes |
| electronics_lid_front | 114.4 × 178.3 × 5.4 | 44 | 4.0 | yes |
| electronics_lid_rear | 114.4 × 178.3 × 5.4 | 33 | 3.0 | yes |
| lidar_mast | 62 × 62 × 12.6 | 30 | 2.7 | yes |
