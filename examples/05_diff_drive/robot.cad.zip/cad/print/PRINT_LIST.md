# Print list — diff_drive_robot

11 parts, about 413 g of PETG and 37.7 h of printing.

Settings the masses assume: PETG, 0.4 mm nozzle, 0.2 mm layers, 4 perimeters, 30 % gyroid infill. Print each part flat on its largest face; holes are sized for M2/M2.5/M3 screws (clearance +0.4 mm).

| Part | Size (mm) | Mass (g) | Time (h) | Fits a 250 × 210 × 220 bed |
|---|---|--:|--:|:-:|
| base_link | 244 × 200 × 6 | 249 | 22.7 | yes |
| left_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| right_bracket | 44 × 41 × 48 | 16 | 1.4 | yes |
| front_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| rear_caster_post | 40 × 40 × 49 | 34 | 3.1 | yes |
| battery_tray | 110.6 × 40.7 × 16.2 | 17 | 1.5 | yes |
| computer_tray | 85.7 × 55.4 × 7 | 13 | 1.1 | yes |
| motor_driver_1_tray | 84.4 × 61.4 × 7 | 13 | 1.2 | yes |
| imu_tray | 26.9 × 24 × 7 | 2 | 0.1 | yes |
| regulator_5v_tray | 26.7 × 26.7 × 7 | 2 | 0.1 | yes |
| lidar_mast | 62 × 62 × 6 | 19 | 1.7 | yes |
